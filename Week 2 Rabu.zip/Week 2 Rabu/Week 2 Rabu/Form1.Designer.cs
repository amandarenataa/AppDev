﻿namespace Week_2_Rabu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdb_Men = new System.Windows.Forms.RadioButton();
            this.rdB_Women = new System.Windows.Forms.RadioButton();
            this.rdB_tiger = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cB_Bold = new System.Windows.Forms.CheckBox();
            this.cB_Italic = new System.Windows.Forms.CheckBox();
            this.cB_Underline = new System.Windows.Forms.CheckBox();
            this.rdB_duabelas = new System.Windows.Forms.RadioButton();
            this.rdB_dualima = new System.Windows.Forms.RadioButton();
            this.rdB_duaenam = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdB_hilangkan = new System.Windows.Forms.RadioButton();
            this.rdB_Muncul = new System.Windows.Forms.RadioButton();
            this.txtBox_kata = new System.Windows.Forms.TextBox();
            this.lbl_berhasil = new System.Windows.Forms.Label();
            this.lbl_nama = new System.Windows.Forms.Label();
            this.btn_change = new System.Windows.Forms.Button();
            this.lbl_kata = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_jumlahHuruf = new System.Windows.Forms.Label();
            this.lbl_brpHuruf = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // rdb_Men
            // 
            this.rdb_Men.AutoSize = true;
            this.rdb_Men.Location = new System.Drawing.Point(30, 16);
            this.rdb_Men.Name = "rdb_Men";
            this.rdb_Men.Size = new System.Drawing.Size(85, 29);
            this.rdb_Men.TabIndex = 0;
            this.rdb_Men.Text = "Men";
            this.rdb_Men.UseVisualStyleBackColor = true;
            // 
            // rdB_Women
            // 
            this.rdB_Women.AutoSize = true;
            this.rdB_Women.Location = new System.Drawing.Point(30, 72);
            this.rdB_Women.Name = "rdB_Women";
            this.rdB_Women.Size = new System.Drawing.Size(116, 29);
            this.rdB_Women.TabIndex = 1;
            this.rdB_Women.TabStop = true;
            this.rdB_Women.Text = "Women";
            this.rdB_Women.UseVisualStyleBackColor = true;
            // 
            // rdB_tiger
            // 
            this.rdB_tiger.AutoSize = true;
            this.rdB_tiger.Location = new System.Drawing.Point(30, 122);
            this.rdB_tiger.Name = "rdB_tiger";
            this.rdB_tiger.Size = new System.Drawing.Size(92, 29);
            this.rdB_tiger.TabIndex = 2;
            this.rdB_tiger.TabStop = true;
            this.rdB_tiger.Text = "Tiger";
            this.rdB_tiger.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdB_Women);
            this.panel1.Controls.Add(this.rdB_tiger);
            this.panel1.Controls.Add(this.rdb_Men);
            this.panel1.Location = new System.Drawing.Point(69, 58);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(229, 168);
            this.panel1.TabIndex = 3;
            // 
            // cB_Bold
            // 
            this.cB_Bold.AutoSize = true;
            this.cB_Bold.Location = new System.Drawing.Point(484, 33);
            this.cB_Bold.Name = "cB_Bold";
            this.cB_Bold.Size = new System.Drawing.Size(87, 29);
            this.cB_Bold.TabIndex = 4;
            this.cB_Bold.Text = "Bold";
            this.cB_Bold.UseVisualStyleBackColor = true;
            // 
            // cB_Italic
            // 
            this.cB_Italic.AutoSize = true;
            this.cB_Italic.Location = new System.Drawing.Point(484, 68);
            this.cB_Italic.Name = "cB_Italic";
            this.cB_Italic.Size = new System.Drawing.Size(88, 29);
            this.cB_Italic.TabIndex = 5;
            this.cB_Italic.Text = "Italic";
            this.cB_Italic.UseVisualStyleBackColor = true;
            // 
            // cB_Underline
            // 
            this.cB_Underline.AutoSize = true;
            this.cB_Underline.Location = new System.Drawing.Point(484, 103);
            this.cB_Underline.Name = "cB_Underline";
            this.cB_Underline.Size = new System.Drawing.Size(136, 29);
            this.cB_Underline.TabIndex = 6;
            this.cB_Underline.Text = "Underline";
            this.cB_Underline.UseVisualStyleBackColor = true;
            // 
            // rdB_duabelas
            // 
            this.rdB_duabelas.AutoSize = true;
            this.rdB_duabelas.Location = new System.Drawing.Point(30, 49);
            this.rdB_duabelas.Name = "rdB_duabelas";
            this.rdB_duabelas.Size = new System.Drawing.Size(86, 29);
            this.rdB_duabelas.TabIndex = 7;
            this.rdB_duabelas.TabStop = true;
            this.rdB_duabelas.Text = "0-12";
            this.rdB_duabelas.UseVisualStyleBackColor = true;
            // 
            // rdB_dualima
            // 
            this.rdB_dualima.AutoSize = true;
            this.rdB_dualima.Location = new System.Drawing.Point(30, 103);
            this.rdB_dualima.Name = "rdB_dualima";
            this.rdB_dualima.Size = new System.Drawing.Size(98, 29);
            this.rdB_dualima.TabIndex = 8;
            this.rdB_dualima.TabStop = true;
            this.rdB_dualima.Text = "13-25";
            this.rdB_dualima.UseVisualStyleBackColor = true;
            // 
            // rdB_duaenam
            // 
            this.rdB_duaenam.AutoSize = true;
            this.rdB_duaenam.Location = new System.Drawing.Point(30, 152);
            this.rdB_duaenam.Name = "rdB_duaenam";
            this.rdB_duaenam.Size = new System.Drawing.Size(79, 29);
            this.rdB_duaenam.TabIndex = 9;
            this.rdB_duaenam.TabStop = true;
            this.rdB_duaenam.Text = ">25";
            this.rdB_duaenam.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdB_dualima);
            this.groupBox1.Controls.Add(this.rdB_duaenam);
            this.groupBox1.Controls.Add(this.rdB_duabelas);
            this.groupBox1.Location = new System.Drawing.Point(69, 272);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(261, 205);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Umur Berapa?";
            // 
            // rdB_hilangkan
            // 
            this.rdB_hilangkan.AutoSize = true;
            this.rdB_hilangkan.Location = new System.Drawing.Point(424, 61);
            this.rdB_hilangkan.Name = "rdB_hilangkan";
            this.rdB_hilangkan.Size = new System.Drawing.Size(104, 29);
            this.rdB_hilangkan.TabIndex = 11;
            this.rdB_hilangkan.TabStop = true;
            this.rdB_hilangkan.Text = "Hilang";
            this.rdB_hilangkan.UseVisualStyleBackColor = true;
            this.rdB_hilangkan.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // rdB_Muncul
            // 
            this.rdB_Muncul.AutoSize = true;
            this.rdB_Muncul.Location = new System.Drawing.Point(424, 96);
            this.rdB_Muncul.Name = "rdB_Muncul";
            this.rdB_Muncul.Size = new System.Drawing.Size(113, 29);
            this.rdB_Muncul.TabIndex = 12;
            this.rdB_Muncul.TabStop = true;
            this.rdB_Muncul.Text = "Muncul";
            this.rdB_Muncul.UseVisualStyleBackColor = true;
            // 
            // txtBox_kata
            // 
            this.txtBox_kata.Location = new System.Drawing.Point(108, 33);
            this.txtBox_kata.Name = "txtBox_kata";
            this.txtBox_kata.Size = new System.Drawing.Size(179, 31);
            this.txtBox_kata.TabIndex = 13;
            // 
            // lbl_berhasil
            // 
            this.lbl_berhasil.AutoSize = true;
            this.lbl_berhasil.Location = new System.Drawing.Point(588, 76);
            this.lbl_berhasil.Name = "lbl_berhasil";
            this.lbl_berhasil.Size = new System.Drawing.Size(115, 25);
            this.lbl_berhasil.TabIndex = 14;
            this.lbl_berhasil.Text = "BERHASIL";
            // 
            // lbl_nama
            // 
            this.lbl_nama.AutoSize = true;
            this.lbl_nama.Location = new System.Drawing.Point(8, 36);
            this.lbl_nama.Name = "lbl_nama";
            this.lbl_nama.Size = new System.Drawing.Size(68, 25);
            this.lbl_nama.TabIndex = 15;
            this.lbl_nama.Text = "Nama";
            // 
            // btn_change
            // 
            this.btn_change.Location = new System.Drawing.Point(334, 26);
            this.btn_change.Name = "btn_change";
            this.btn_change.Size = new System.Drawing.Size(110, 45);
            this.btn_change.TabIndex = 16;
            this.btn_change.Text = "Change";
            this.btn_change.UseVisualStyleBackColor = true;
            this.btn_change.Click += new System.EventHandler(this.btn_change_Click);
            // 
            // lbl_kata
            // 
            this.lbl_kata.AutoSize = true;
            this.lbl_kata.Location = new System.Drawing.Point(103, 85);
            this.lbl_kata.Name = "lbl_kata";
            this.lbl_kata.Size = new System.Drawing.Size(70, 25);
            this.lbl_kata.TabIndex = 17;
            this.lbl_kata.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 18;
            this.label1.Text = "label1";
            // 
            // lbl_jumlahHuruf
            // 
            this.lbl_jumlahHuruf.AutoSize = true;
            this.lbl_jumlahHuruf.Location = new System.Drawing.Point(8, 158);
            this.lbl_jumlahHuruf.Name = "lbl_jumlahHuruf";
            this.lbl_jumlahHuruf.Size = new System.Drawing.Size(139, 25);
            this.lbl_jumlahHuruf.TabIndex = 19;
            this.lbl_jumlahHuruf.Text = "Jumlah Huruf";
            // 
            // lbl_brpHuruf
            // 
            this.lbl_brpHuruf.AutoSize = true;
            this.lbl_brpHuruf.Location = new System.Drawing.Point(217, 158);
            this.lbl_brpHuruf.Name = "lbl_brpHuruf";
            this.lbl_brpHuruf.Size = new System.Drawing.Size(24, 25);
            this.lbl_brpHuruf.TabIndex = 20;
            this.lbl_brpHuruf.Text = "0";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl_brpHuruf);
            this.panel2.Controls.Add(this.txtBox_kata);
            this.panel2.Controls.Add(this.lbl_jumlahHuruf);
            this.panel2.Controls.Add(this.lbl_nama);
            this.panel2.Controls.Add(this.btn_change);
            this.panel2.Controls.Add(this.lbl_kata);
            this.panel2.Controls.Add(this.cB_Underline);
            this.panel2.Controls.Add(this.cB_Italic);
            this.panel2.Controls.Add(this.cB_Bold);
            this.panel2.Location = new System.Drawing.Point(424, 190);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(742, 229);
            this.panel2.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1322, 809);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_berhasil);
            this.Controls.Add(this.rdB_Muncul);
            this.Controls.Add(this.rdB_hilangkan);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdb_Men;
        private System.Windows.Forms.RadioButton rdB_Women;
        private System.Windows.Forms.RadioButton rdB_tiger;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cB_Bold;
        private System.Windows.Forms.CheckBox cB_Italic;
        private System.Windows.Forms.CheckBox cB_Underline;
        private System.Windows.Forms.RadioButton rdB_duabelas;
        private System.Windows.Forms.RadioButton rdB_dualima;
        private System.Windows.Forms.RadioButton rdB_duaenam;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdB_hilangkan;
        private System.Windows.Forms.RadioButton rdB_Muncul;
        private System.Windows.Forms.TextBox txtBox_kata;
        private System.Windows.Forms.Label lbl_berhasil;
        private System.Windows.Forms.Label lbl_nama;
        private System.Windows.Forms.Button btn_change;
        private System.Windows.Forms.Label lbl_kata;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_jumlahHuruf;
        private System.Windows.Forms.Label lbl_brpHuruf;
        private System.Windows.Forms.Panel panel2;
    }
}

