﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_2_Rabu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (rdB_Muncul.Checked)
            {
                lbl_berhasil.Visible = true;
            }
            else
            {
                lbl_berhasil.Visible = false;
            }
        }
        private void btn_change_Click(object sender, EventArgs e)
        {
            if (txtBox_kata.Text == "")
            {
                MessageBox.Show("Error!");
            }
            else
            {
                lbl_kata.Text = txtBox_kata.Text;
                int count = 0;
                foreach (char k in txtBox_kata.Text)
                {
                    count++;
                }
                lbl_brpHuruf.Text = count.ToString();
            }

            FontStyle newStyle = FontStyle.Regular; // nyimpen font e

            if (cB_Bold.Checked)
            {
                newStyle |= FontStyle.Bold;
            }
            if (cB_Italic.Checked)
            {
                newStyle |= FontStyle.Italic;
            }
            if (cB_Underline.Checked)
            {
                newStyle |= FontStyle.Underline;
            }

            lbl_kata.Font = new Font(lbl_kata.Font, newStyle); // ganti font e

            /*
            if (cB_Bold.Checked)
            {
                lbl_kata.Font = new Font(lbl_kata.Font,  FontStyle.Bold);
            }
            if (cB_Italic.Checked)
            {
                lbl_kata.Font = new Font(lbl_kata.Font, FontStyle.Italic);
            }
            if (cB_Underline.Checked)
            {
                lbl_kata.Font = new Font(lbl_kata.Font, FontStyle.Underline);
            }
            */
        }
    }
}
