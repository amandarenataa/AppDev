﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Rabu_Week_12
{
    public partial class F1 : Form
    {
        public F1()
        {
            InitializeComponent();
        }
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable data;
        string query;

        private void F1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            /* DQL perlu ada connection open dan close di load (select)
             * DML tidak perlu ada connection open dan close di load (insert dll)
            conn.Open();
            conn.Close();
            */
            query = "select * from student;";
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);

            data = new DataTable();
            adapter.Fill(data);
            DGV_DATA.DataSource = data;
        }

        private void bt_insert_Click(object sender, EventArgs e)
        {
            bool adaDua = false;
            foreach (DataRow row in data.Rows)
            {
                if (row[3].ToString() == tb_nim.Text)
                {
                    adaDua = true;
                }
            }
            if (adaDua)
            {
                MessageBox.Show("ID Sudah Ada");
                tb_nim.Clear();
            }
            else
            {

                DateTime dt = DateTime.Now;
                string date = dt.ToString();

                query = $"insert into student values ('{tb_ID.Text}','{tb_name.Text}','{date.Substring(5, 4) + '-' + date.Substring(0, 1) + '-' + date.Substring(2, 2)} ', '{tb_nim.Text}')";
                //or

                /* 
                 cmd = conn.CreateCommand();
                 query = "insert into student values (@id, @name, @birthday, @nim);";
                 cmd.CommandText = query;
                 cmd.Parameters.AddWithValue("@id",tb_ID.Text);
                 cmd.Parameters.AddWithValue("@name", tb_name.Text);
                 cmd.Parameters.AddWithValue("@birthday", date.Substring(5, 4) + '-' + date.Substring(0, 1) + '-' + date.Substring(2, 2));
                 cmd.Parameters.AddWithValue("@nim", tb_nim.Text);
                 */

                // connection open close buat DML perlunya di sini
                conn.Open();
                cmd = new MySqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                conn.Close();

                query = "select * from student;";
                cmd = new MySqlCommand(query, conn);
                adapter = new MySqlDataAdapter(cmd);
                data.Clear();
                adapter.Fill(data);
                DGV_DATA.DataSource = data;

                tb_ID.Clear();
                tb_name.Clear();
                tb_nim.Clear();
            }
        }

        private void bt_update_Click(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            string date = dt.ToString();

            query = $"update student set student_name = '{tb_nameUp.Text}', student_birthday = '{date.Substring(5, 4) + '-' + date.Substring(0, 1) + '-' + date.Substring(2, 2)} ', student_nim = '{tb_nimUp.Text}' where id_student = {tb_idUp.Text}";
            
            conn.Open();
            cmd = new MySqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();

            query = "select * from student;";
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            data.Clear();
            adapter.Fill(data);
            DGV_DATA.DataSource = data;
        }

        private void DGV_DATA_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            tb_idUp.Text = data.Rows[DGV_DATA.CurrentRow.Index][0].ToString();
            tb_nameUp.Text = data.Rows[DGV_DATA.CurrentRow.Index][1].ToString();
            tb_nimUp.Text = data.Rows[DGV_DATA.CurrentRow.Index][3].ToString();

            /*
            int rowKe = e.RowIndex;
            int count = 0;
            foreach (DataRow dr in data.Rows)
            {
                if (count == rowKe)
                {
                    tb_idUp.Text = dr[0].ToString();
                    tb_nameUp.Text = dr[1].ToString();
                    tb_nimUp.Text = dr[3].ToString();
                }
                    count++;
            }
            */
        }
    }
}
