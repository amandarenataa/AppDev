﻿namespace Rabu_Week_12
{
    partial class F1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.tb_nim = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_insert = new System.Windows.Forms.Button();
            this.DGV_DATA = new System.Windows.Forms.DataGridView();
            this.bt_update = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_nimUp = new System.Windows.Forms.TextBox();
            this.tb_nameUp = new System.Windows.Forms.TextBox();
            this.tb_idUp = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_DATA)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_ID
            // 
            this.tb_ID.Location = new System.Drawing.Point(162, 103);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(269, 31);
            this.tb_ID.TabIndex = 0;
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(162, 165);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(269, 31);
            this.tb_name.TabIndex = 1;
            // 
            // tb_nim
            // 
            this.tb_nim.Location = new System.Drawing.Point(162, 228);
            this.tb_nim.Name = "tb_nim";
            this.tb_nim.Size = new System.Drawing.Size(269, 31);
            this.tb_nim.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(93, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(75, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "NIM:";
            // 
            // bt_insert
            // 
            this.bt_insert.Location = new System.Drawing.Point(183, 322);
            this.bt_insert.Name = "bt_insert";
            this.bt_insert.Size = new System.Drawing.Size(125, 41);
            this.bt_insert.TabIndex = 6;
            this.bt_insert.Text = "INSERT";
            this.bt_insert.UseVisualStyleBackColor = true;
            this.bt_insert.Click += new System.EventHandler(this.bt_insert_Click);
            // 
            // DGV_DATA
            // 
            this.DGV_DATA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DGV_DATA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_DATA.Location = new System.Drawing.Point(480, 70);
            this.DGV_DATA.Name = "DGV_DATA";
            this.DGV_DATA.RowHeadersWidth = 82;
            this.DGV_DATA.RowTemplate.Height = 33;
            this.DGV_DATA.Size = new System.Drawing.Size(1130, 512);
            this.DGV_DATA.TabIndex = 7;
            this.DGV_DATA.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DGV_DATA_CellMouseDoubleClick);
            // 
            // bt_update
            // 
            this.bt_update.Location = new System.Drawing.Point(183, 632);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(125, 41);
            this.bt_update.TabIndex = 14;
            this.bt_update.Text = "UPDATE";
            this.bt_update.UseVisualStyleBackColor = true;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(75, 544);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 25);
            this.label4.TabIndex = 13;
            this.label4.Text = "NIM:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 481);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(93, 416);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 25);
            this.label6.TabIndex = 11;
            this.label6.Text = "ID:";
            // 
            // tb_nimUp
            // 
            this.tb_nimUp.Location = new System.Drawing.Point(162, 538);
            this.tb_nimUp.Name = "tb_nimUp";
            this.tb_nimUp.Size = new System.Drawing.Size(269, 31);
            this.tb_nimUp.TabIndex = 10;
            // 
            // tb_nameUp
            // 
            this.tb_nameUp.Location = new System.Drawing.Point(162, 475);
            this.tb_nameUp.Name = "tb_nameUp";
            this.tb_nameUp.Size = new System.Drawing.Size(269, 31);
            this.tb_nameUp.TabIndex = 9;
            // 
            // tb_idUp
            // 
            this.tb_idUp.Enabled = false;
            this.tb_idUp.Location = new System.Drawing.Point(162, 413);
            this.tb_idUp.Name = "tb_idUp";
            this.tb_idUp.Size = new System.Drawing.Size(269, 31);
            this.tb_idUp.TabIndex = 8;
            // 
            // F1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1647, 750);
            this.Controls.Add(this.bt_update);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_nimUp);
            this.Controls.Add(this.tb_nameUp);
            this.Controls.Add(this.tb_idUp);
            this.Controls.Add(this.DGV_DATA);
            this.Controls.Add(this.bt_insert);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_nim);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.tb_ID);
            this.Name = "F1";
            this.Text = "F1";
            this.Load += new System.EventHandler(this.F1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_DATA)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_ID;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.TextBox tb_nim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_insert;
        private System.Windows.Forms.DataGridView DGV_DATA;
        private System.Windows.Forms.Button bt_update;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_nimUp;
        private System.Windows.Forms.TextBox tb_nameUp;
        private System.Windows.Forms.TextBox tb_idUp;
    }
}

