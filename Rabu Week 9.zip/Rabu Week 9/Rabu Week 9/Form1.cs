﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; // harus dimasukin setiap kali pake database

namespace Rabu_Week_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection MySqlConnection;// membantu membuat koneksi ke dalam mysqlnya, menyimpan user untuk dikonek
        MySqlCommand MySqlCommand;// mejalankan querry yang ditulis di database
        MySqlDataAdapter MySqlDataAdapter; //menampung hasil querry mu

        private void bt_login_Click(object sender, EventArgs e)
        {
            if (tb_database.Text == "" || tb_password.Text == "" || tb_username.Text == "")
            {
                MessageBox.Show("Isi Dulu");
            }
            else
            {
                MySqlConnection = new MySqlConnection($"server=10.10.10.136;uid={tb_username.Text};pwd={tb_password.Text};;database={tb_database.Text};");
                MySqlConnection.Open();
                MySqlConnection.Close();
                string sqlQuery = $"select * from player";
                DataTable dtPlayer = new DataTable();
                MySqlCommand = new MySqlCommand(sqlQuery, MySqlConnection);
                MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                MySqlDataAdapter.Fill(dtPlayer);
                dgv_player.DataSource = dtPlayer;
            }
        }

        private void bt_refresh_Click(object sender, EventArgs e)
        {
            if (tb_database.Text == "" || tb_password.Text == "" || tb_username.Text == "")
            {
                MessageBox.Show("Isi Dulu");
            }
            else
            {
                MySqlConnection = new MySqlConnection($"server=10.10.10.136;uid={tb_username.Text};pwd={tb_password.Text};;database={tb_database.Text};;");
                MySqlConnection.Open();
                MySqlConnection.Close();
                string sqlQuery = $"select * from mahasiswa";
                DataTable dtMahasiswa = new DataTable();
                MySqlCommand = new MySqlCommand(sqlQuery, MySqlConnection);
                MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                MySqlDataAdapter.Fill(dtMahasiswa);
                dgv_mahasiswa.DataSource = dtMahasiswa;
            }
            tb_username.Clear();
            tb_password.Clear();
            tb_database.Clear();
        }

        private void bt_submit_Click(object sender, EventArgs e)
        {
            if (tb_kota.Text == "" || tb_nama.Text == "" || tb_nim.Text == "")
            {
                MessageBox.Show("Isi Dulu");
            }
            else
            {
                /*
                 * nama tabel = mahasiswa
                 * 1. nim_mahasiswa varchar(13)
                 * 2. nama_mahasiswa varchar(50)
                 * 3. kota_asal varchar(50)
                */
                /*
                 * update 
                 * set
                 * where
                 * 
                 * delete
                 * where
                 * 
                 * biar tidak error bang
                 */
                string sqlQuery = $"insert into mahasiswa (nim_mahasiswa, nama_mahasiswa, kota_asal) values ('{tb_nim.Text}','{tb_nama.Text}','{tb_kota.Text}');";
                MySqlCommand = new MySqlCommand(sqlQuery, MySqlConnection);
                MySqlConnection.Open();
                MySqlCommand.ExecuteNonQuery();//untuk menjalankan dml
                MySqlConnection.Close();
            }
            tb_nim.Clear();
            tb_kota.Clear();
            tb_nama.Clear();
        }
    }
}
