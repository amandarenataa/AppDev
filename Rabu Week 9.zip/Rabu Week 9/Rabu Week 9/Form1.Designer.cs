﻿namespace Rabu_Week_9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_username = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.lb_database = new System.Windows.Forms.Label();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_database = new System.Windows.Forms.TextBox();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.bt_login = new System.Windows.Forms.Button();
            this.dgv_player = new System.Windows.Forms.DataGridView();
            this.dgv_mahasiswa = new System.Windows.Forms.DataGridView();
            this.bt_refresh = new System.Windows.Forms.Button();
            this.tb_nim = new System.Windows.Forms.TextBox();
            this.tb_kota = new System.Windows.Forms.TextBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.lb_kota = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_nim = new System.Windows.Forms.Label();
            this.bt_submit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mahasiswa)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_username
            // 
            this.lb_username.AutoSize = true;
            this.lb_username.Location = new System.Drawing.Point(84, 107);
            this.lb_username.Name = "lb_username";
            this.lb_username.Size = new System.Drawing.Size(110, 25);
            this.lb_username.TabIndex = 0;
            this.lb_username.Text = "Username";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(84, 149);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(106, 25);
            this.lb_password.TabIndex = 1;
            this.lb_password.Text = "Password";
            // 
            // lb_database
            // 
            this.lb_database.AutoSize = true;
            this.lb_database.Location = new System.Drawing.Point(84, 191);
            this.lb_database.Name = "lb_database";
            this.lb_database.Size = new System.Drawing.Size(104, 25);
            this.lb_database.TabIndex = 2;
            this.lb_database.Text = "Database";
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(201, 149);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(184, 31);
            this.tb_password.TabIndex = 3;
            // 
            // tb_database
            // 
            this.tb_database.Location = new System.Drawing.Point(201, 191);
            this.tb_database.Name = "tb_database";
            this.tb_database.Size = new System.Drawing.Size(184, 31);
            this.tb_database.TabIndex = 4;
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(201, 107);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(184, 31);
            this.tb_username.TabIndex = 5;
            // 
            // bt_login
            // 
            this.bt_login.Location = new System.Drawing.Point(181, 254);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(106, 41);
            this.bt_login.TabIndex = 6;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // dgv_player
            // 
            this.dgv_player.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_player.Location = new System.Drawing.Point(89, 337);
            this.dgv_player.Name = "dgv_player";
            this.dgv_player.RowHeadersWidth = 82;
            this.dgv_player.RowTemplate.Height = 33;
            this.dgv_player.Size = new System.Drawing.Size(1747, 209);
            this.dgv_player.TabIndex = 7;
            // 
            // dgv_mahasiswa
            // 
            this.dgv_mahasiswa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_mahasiswa.Location = new System.Drawing.Point(89, 552);
            this.dgv_mahasiswa.Name = "dgv_mahasiswa";
            this.dgv_mahasiswa.RowHeadersWidth = 82;
            this.dgv_mahasiswa.RowTemplate.Height = 33;
            this.dgv_mahasiswa.Size = new System.Drawing.Size(1747, 209);
            this.dgv_mahasiswa.TabIndex = 8;
            // 
            // bt_refresh
            // 
            this.bt_refresh.Location = new System.Drawing.Point(495, 254);
            this.bt_refresh.Name = "bt_refresh";
            this.bt_refresh.Size = new System.Drawing.Size(106, 41);
            this.bt_refresh.TabIndex = 9;
            this.bt_refresh.Text = "Refresh";
            this.bt_refresh.UseVisualStyleBackColor = true;
            this.bt_refresh.Click += new System.EventHandler(this.bt_refresh_Click);
            // 
            // tb_nim
            // 
            this.tb_nim.Location = new System.Drawing.Point(1349, 107);
            this.tb_nim.Name = "tb_nim";
            this.tb_nim.Size = new System.Drawing.Size(184, 31);
            this.tb_nim.TabIndex = 15;
            // 
            // tb_kota
            // 
            this.tb_kota.Location = new System.Drawing.Point(1349, 191);
            this.tb_kota.Name = "tb_kota";
            this.tb_kota.Size = new System.Drawing.Size(184, 31);
            this.tb_kota.TabIndex = 14;
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(1349, 149);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(184, 31);
            this.tb_nama.TabIndex = 13;
            // 
            // lb_kota
            // 
            this.lb_kota.AutoSize = true;
            this.lb_kota.Location = new System.Drawing.Point(1232, 191);
            this.lb_kota.Name = "lb_kota";
            this.lb_kota.Size = new System.Drawing.Size(104, 25);
            this.lb_kota.TabIndex = 12;
            this.lb_kota.Text = "Kota Asal";
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(1232, 149);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(68, 25);
            this.lb_nama.TabIndex = 11;
            this.lb_nama.Text = "Nama";
            // 
            // lb_nim
            // 
            this.lb_nim.AutoSize = true;
            this.lb_nim.Location = new System.Drawing.Point(1232, 107);
            this.lb_nim.Name = "lb_nim";
            this.lb_nim.Size = new System.Drawing.Size(50, 25);
            this.lb_nim.TabIndex = 10;
            this.lb_nim.Text = "NIM";
            // 
            // bt_submit
            // 
            this.bt_submit.Location = new System.Drawing.Point(1320, 254);
            this.bt_submit.Name = "bt_submit";
            this.bt_submit.Size = new System.Drawing.Size(106, 41);
            this.bt_submit.TabIndex = 16;
            this.bt_submit.Text = "Submit";
            this.bt_submit.UseVisualStyleBackColor = true;
            this.bt_submit.Click += new System.EventHandler(this.bt_submit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1943, 954);
            this.Controls.Add(this.bt_submit);
            this.Controls.Add(this.tb_nim);
            this.Controls.Add(this.tb_kota);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.lb_kota);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.lb_nim);
            this.Controls.Add(this.bt_refresh);
            this.Controls.Add(this.dgv_mahasiswa);
            this.Controls.Add(this.dgv_player);
            this.Controls.Add(this.bt_login);
            this.Controls.Add(this.tb_username);
            this.Controls.Add(this.tb_database);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.lb_database);
            this.Controls.Add(this.lb_password);
            this.Controls.Add(this.lb_username);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mahasiswa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_username;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.Label lb_database;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_database;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.DataGridView dgv_player;
        private System.Windows.Forms.DataGridView dgv_mahasiswa;
        private System.Windows.Forms.Button bt_refresh;
        private System.Windows.Forms.TextBox tb_nim;
        private System.Windows.Forms.TextBox tb_kota;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.Label lb_kota;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_nim;
        private System.Windows.Forms.Button bt_submit;
    }
}

