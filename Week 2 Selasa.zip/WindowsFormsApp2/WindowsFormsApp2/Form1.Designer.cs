﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Ganti = new System.Windows.Forms.Button();
            this.txtBox_Ganti = new System.Windows.Forms.TextBox();
            this.lbl_Pertama = new System.Windows.Forms.Label();
            this.lb_Ganti = new System.Windows.Forms.Label();
            this.lb_GantikeDua = new System.Windows.Forms.Label();
            this.rb_Merah = new System.Windows.Forms.RadioButton();
            this.rb_Kuning = new System.Windows.Forms.RadioButton();
            this.rb_Hijau = new System.Windows.Forms.RadioButton();
            this.txtBox_AngkaPertama = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lb_AngkaPertama = new System.Windows.Forms.Label();
            this.lb_AngkaKedua = new System.Windows.Forms.Label();
            this.txtBox_AngkaKedua = new System.Windows.Forms.TextBox();
            this.rb_Penjumlahan = new System.Windows.Forms.RadioButton();
            this.rb_Pengurangan = new System.Windows.Forms.RadioButton();
            this.rb_Perkalian = new System.Windows.Forms.RadioButton();
            this.rb_Pembagian = new System.Windows.Forms.RadioButton();
            this.lb_hasil = new System.Windows.Forms.Label();
            this.lb_Hasilperhitungan = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Ganti
            // 
            this.btn_Ganti.Location = new System.Drawing.Point(122, 108);
            this.btn_Ganti.Name = "btn_Ganti";
            this.btn_Ganti.Size = new System.Drawing.Size(75, 23);
            this.btn_Ganti.TabIndex = 0;
            this.btn_Ganti.Text = "Ganti";
            this.btn_Ganti.UseVisualStyleBackColor = true;
            this.btn_Ganti.Click += new System.EventHandler(this.btn_Ganti_Click);
            // 
            // txtBox_Ganti
            // 
            this.txtBox_Ganti.Location = new System.Drawing.Point(108, 67);
            this.txtBox_Ganti.Name = "txtBox_Ganti";
            this.txtBox_Ganti.Size = new System.Drawing.Size(100, 20);
            this.txtBox_Ganti.TabIndex = 1;
            // 
            // lbl_Pertama
            // 
            this.lbl_Pertama.AutoSize = true;
            this.lbl_Pertama.Location = new System.Drawing.Point(24, 70);
            this.lbl_Pertama.Name = "lbl_Pertama";
            this.lbl_Pertama.Size = new System.Drawing.Size(78, 13);
            this.lbl_Pertama.TabIndex = 2;
            this.lbl_Pertama.Text = "ngomong apa?";
            // 
            // lb_Ganti
            // 
            this.lb_Ganti.AutoSize = true;
            this.lb_Ganti.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Ganti.Location = new System.Drawing.Point(32, 153);
            this.lb_Ganti.Name = "lb_Ganti";
            this.lb_Ganti.Size = new System.Drawing.Size(56, 25);
            this.lb_Ganti.TabIndex = 3;
            this.lb_Ganti.Text = "label2";
            this.lb_Ganti.Click += new System.EventHandler(this.lb_Ganti_Click);
            // 
            // lb_GantikeDua
            // 
            this.lb_GantikeDua.AutoSize = true;
            this.lb_GantikeDua.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_GantikeDua.Location = new System.Drawing.Point(103, 153);
            this.lb_GantikeDua.Name = "lb_GantikeDua";
            this.lb_GantikeDua.Size = new System.Drawing.Size(56, 25);
            this.lb_GantikeDua.TabIndex = 4;
            this.lb_GantikeDua.Text = "label3";
            this.lb_GantikeDua.Click += new System.EventHandler(this.lb_GantikeDua_Click);
            // 
            // rb_Merah
            // 
            this.rb_Merah.AutoSize = true;
            this.rb_Merah.Location = new System.Drawing.Point(259, 47);
            this.rb_Merah.Name = "rb_Merah";
            this.rb_Merah.Size = new System.Drawing.Size(55, 17);
            this.rb_Merah.TabIndex = 5;
            this.rb_Merah.TabStop = true;
            this.rb_Merah.Text = "Merah";
            this.rb_Merah.UseVisualStyleBackColor = true;
            this.rb_Merah.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rb_Kuning
            // 
            this.rb_Kuning.AutoSize = true;
            this.rb_Kuning.Location = new System.Drawing.Point(259, 70);
            this.rb_Kuning.Name = "rb_Kuning";
            this.rb_Kuning.Size = new System.Drawing.Size(58, 17);
            this.rb_Kuning.TabIndex = 6;
            this.rb_Kuning.TabStop = true;
            this.rb_Kuning.Text = "Kuning";
            this.rb_Kuning.UseVisualStyleBackColor = true;
            this.rb_Kuning.CheckedChanged += new System.EventHandler(this.rb_Kuning_CheckedChanged);
            // 
            // rb_Hijau
            // 
            this.rb_Hijau.AutoSize = true;
            this.rb_Hijau.Location = new System.Drawing.Point(259, 94);
            this.rb_Hijau.Name = "rb_Hijau";
            this.rb_Hijau.Size = new System.Drawing.Size(49, 17);
            this.rb_Hijau.TabIndex = 7;
            this.rb_Hijau.TabStop = true;
            this.rb_Hijau.Text = "Hijau";
            this.rb_Hijau.UseVisualStyleBackColor = true;
            this.rb_Hijau.CheckedChanged += new System.EventHandler(this.rb_Hijau_CheckedChanged);
            // 
            // txtBox_AngkaPertama
            // 
            this.txtBox_AngkaPertama.Location = new System.Drawing.Point(476, 131);
            this.txtBox_AngkaPertama.Name = "txtBox_AngkaPertama";
            this.txtBox_AngkaPertama.Size = new System.Drawing.Size(59, 20);
            this.txtBox_AngkaPertama.TabIndex = 8;
            this.txtBox_AngkaPertama.TextChanged += new System.EventHandler(this.txtBox_radioButton_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(440, 200);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Hitung";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lb_AngkaPertama
            // 
            this.lb_AngkaPertama.AutoSize = true;
            this.lb_AngkaPertama.Location = new System.Drawing.Point(422, 134);
            this.lb_AngkaPertama.Name = "lb_AngkaPertama";
            this.lb_AngkaPertama.Size = new System.Drawing.Size(47, 13);
            this.lb_AngkaPertama.TabIndex = 10;
            this.lb_AngkaPertama.Text = "Angka 1";
            this.lb_AngkaPertama.Click += new System.EventHandler(this.label1_Click);
            // 
            // lb_AngkaKedua
            // 
            this.lb_AngkaKedua.AutoSize = true;
            this.lb_AngkaKedua.Location = new System.Drawing.Point(422, 161);
            this.lb_AngkaKedua.Name = "lb_AngkaKedua";
            this.lb_AngkaKedua.Size = new System.Drawing.Size(47, 13);
            this.lb_AngkaKedua.TabIndex = 11;
            this.lb_AngkaKedua.Text = "Angka 2";
            this.lb_AngkaKedua.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtBox_AngkaKedua
            // 
            this.txtBox_AngkaKedua.Location = new System.Drawing.Point(476, 161);
            this.txtBox_AngkaKedua.Name = "txtBox_AngkaKedua";
            this.txtBox_AngkaKedua.Size = new System.Drawing.Size(59, 20);
            this.txtBox_AngkaKedua.TabIndex = 12;
            // 
            // rb_Penjumlahan
            // 
            this.rb_Penjumlahan.AutoSize = true;
            this.rb_Penjumlahan.Location = new System.Drawing.Point(556, 114);
            this.rb_Penjumlahan.Name = "rb_Penjumlahan";
            this.rb_Penjumlahan.Size = new System.Drawing.Size(86, 17);
            this.rb_Penjumlahan.TabIndex = 13;
            this.rb_Penjumlahan.TabStop = true;
            this.rb_Penjumlahan.Text = "Penjumlahan";
            this.rb_Penjumlahan.UseVisualStyleBackColor = true;
            this.rb_Penjumlahan.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // rb_Pengurangan
            // 
            this.rb_Pengurangan.AutoSize = true;
            this.rb_Pengurangan.Location = new System.Drawing.Point(556, 137);
            this.rb_Pengurangan.Name = "rb_Pengurangan";
            this.rb_Pengurangan.Size = new System.Drawing.Size(89, 17);
            this.rb_Pengurangan.TabIndex = 14;
            this.rb_Pengurangan.TabStop = true;
            this.rb_Pengurangan.Text = "Pengurangan";
            this.rb_Pengurangan.UseVisualStyleBackColor = true;
            // 
            // rb_Perkalian
            // 
            this.rb_Perkalian.AutoSize = true;
            this.rb_Perkalian.Location = new System.Drawing.Point(556, 159);
            this.rb_Perkalian.Name = "rb_Perkalian";
            this.rb_Perkalian.Size = new System.Drawing.Size(69, 17);
            this.rb_Perkalian.TabIndex = 15;
            this.rb_Perkalian.TabStop = true;
            this.rb_Perkalian.Text = "Perkalian";
            this.rb_Perkalian.UseVisualStyleBackColor = true;
            // 
            // rb_Pembagian
            // 
            this.rb_Pembagian.AutoSize = true;
            this.rb_Pembagian.Location = new System.Drawing.Point(556, 182);
            this.rb_Pembagian.Name = "rb_Pembagian";
            this.rb_Pembagian.Size = new System.Drawing.Size(78, 17);
            this.rb_Pembagian.TabIndex = 16;
            this.rb_Pembagian.TabStop = true;
            this.rb_Pembagian.Text = "Pembagian";
            this.rb_Pembagian.UseVisualStyleBackColor = true;
            // 
            // lb_hasil
            // 
            this.lb_hasil.AutoSize = true;
            this.lb_hasil.Location = new System.Drawing.Point(373, 244);
            this.lb_hasil.Name = "lb_hasil";
            this.lb_hasil.Size = new System.Drawing.Size(30, 13);
            this.lb_hasil.TabIndex = 17;
            this.lb_hasil.Text = "Hasil";
            // 
            // lb_Hasilperhitungan
            // 
            this.lb_Hasilperhitungan.AutoSize = true;
            this.lb_Hasilperhitungan.Location = new System.Drawing.Point(437, 244);
            this.lb_Hasilperhitungan.Name = "lb_Hasilperhitungan";
            this.lb_Hasilperhitungan.Size = new System.Drawing.Size(13, 13);
            this.lb_Hasilperhitungan.TabIndex = 18;
            this.lb_Hasilperhitungan.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb_Hasilperhitungan);
            this.Controls.Add(this.lb_hasil);
            this.Controls.Add(this.rb_Pembagian);
            this.Controls.Add(this.rb_Perkalian);
            this.Controls.Add(this.rb_Pengurangan);
            this.Controls.Add(this.rb_Penjumlahan);
            this.Controls.Add(this.txtBox_AngkaKedua);
            this.Controls.Add(this.lb_AngkaKedua);
            this.Controls.Add(this.lb_AngkaPertama);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtBox_AngkaPertama);
            this.Controls.Add(this.rb_Hijau);
            this.Controls.Add(this.rb_Kuning);
            this.Controls.Add(this.rb_Merah);
            this.Controls.Add(this.lb_GantikeDua);
            this.Controls.Add(this.lb_Ganti);
            this.Controls.Add(this.lbl_Pertama);
            this.Controls.Add(this.txtBox_Ganti);
            this.Controls.Add(this.btn_Ganti);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Ganti;
        private System.Windows.Forms.TextBox txtBox_Ganti;
        private System.Windows.Forms.Label lbl_Pertama;
        private System.Windows.Forms.Label lb_Ganti;
        private System.Windows.Forms.Label lb_GantikeDua;
        private System.Windows.Forms.RadioButton rb_Merah;
        private System.Windows.Forms.RadioButton rb_Kuning;
        private System.Windows.Forms.RadioButton rb_Hijau;
        private System.Windows.Forms.TextBox txtBox_AngkaPertama;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lb_AngkaPertama;
        private System.Windows.Forms.Label lb_AngkaKedua;
        private System.Windows.Forms.TextBox txtBox_AngkaKedua;
        private System.Windows.Forms.RadioButton rb_Penjumlahan;
        private System.Windows.Forms.RadioButton rb_Pengurangan;
        private System.Windows.Forms.RadioButton rb_Perkalian;
        private System.Windows.Forms.RadioButton rb_Pembagian;
        private System.Windows.Forms.Label lb_hasil;
        private System.Windows.Forms.Label lb_Hasilperhitungan;
    }
}

