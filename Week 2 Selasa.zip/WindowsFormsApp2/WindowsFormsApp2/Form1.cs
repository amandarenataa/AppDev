﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public int count;
        public bool red;
        public bool green;
        public bool yellow;
        public Form1()
        {
            InitializeComponent();
            green = false;
            yellow = false;
            red = false;
        }

        private void btn_Ganti_Click(object sender, EventArgs e)
        {
            // cara pertama
            /* 
            if (green == true)
            {
                lb_Ganti.ForeColor = Color.Green;
            }
            else if (red == true)
            {
                lb_Ganti.ForeColor = Color.Red;
            }
            else if (yellow == true)
            {
                lb_Ganti.ForeColor = Color.Yellow;
            }
            */

            // cara kedua
            if (rb_Kuning.Checked)
            {
                lb_Ganti.ForeColor = Color.Yellow;
            }
            else if (rb_Merah.Checked)
            {
                lb_Ganti.ForeColor = Color.Red;
            }
            else if (rb_Hijau.Checked)
            {
                lb_Ganti.ForeColor = Color.Green;
            }
            //if (count == 0)
           // {
                lb_Ganti.Text = txtBox_Ganti.Text;
              //  count++;
            //}
            /*
            else if (count == 1)
            {
                lb_GantikeDua.Text = txtBox_Ganti.Text;
                count++;
            }
            */
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            /*
            if (count == 0)
            {
                lb_Ganti.ForeColor = Color.Red;
            }
            else if (count == 1)
            {
                lb_GantikeDua.ForeColor = Color.Red;
            }
            */
            red = true;
        }

        private void lb_Ganti_Click(object sender, EventArgs e)
        {

        }

        private void lb_GantikeDua_Click(object sender, EventArgs e)
        {

        }

        private void rb_Kuning_CheckedChanged(object sender, EventArgs e)
        {
            /*
            if (count == 0)
            {
                lb_Ganti.ForeColor = Color.Yellow;
            }
            else if (count == 1)
            {
                lb_GantikeDua.ForeColor = Color.Yellow;
            }
            */
            yellow = true;
        }

        private void rb_Hijau_CheckedChanged(object sender, EventArgs e)
        {
            /*
            if (count == 0)
            {
                lb_Ganti.ForeColor = Color.Green;
            }
            else if (count == 1)
            {
                lb_GantikeDua.ForeColor = Color.Green;
            }
            */
            green = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void txtBox_radioButton_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double angkaPertama = Convert.ToDouble(txtBox_AngkaPertama.Text);
            double angkaKedua = Convert.ToDouble(txtBox_AngkaKedua.Text);
            if (angkaPertama>angkaKedua)
            {
                MessageBox.Show("angka 1 harus lebih kecil dari angka 2");
            }
            else
            {
                if (rb_Pembagian.Checked )
                {
                    double hasil = angkaPertama / angkaKedua;
                    lb_Hasilperhitungan.Text = hasil.ToString();
                }
                else if (rb_Penjumlahan.Checked)
                {
                    double hasil = angkaPertama + angkaKedua;
                    lb_Hasilperhitungan.Text = hasil.ToString();
                }
                else if (rb_Pengurangan.Checked)
                {
                    double hasil = angkaPertama - angkaKedua;
                    lb_Hasilperhitungan.Text = hasil.ToString();
                }
                else if (rb_Perkalian.Checked)
                {
                    double hasil = angkaPertama * angkaKedua;
                    lb_Hasilperhitungan.Text = hasil.ToString();
                }
                else
                {
                    MessageBox.Show("Tolong pilih cara pengoprasiannya");
                }
            }
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }
    }
}
