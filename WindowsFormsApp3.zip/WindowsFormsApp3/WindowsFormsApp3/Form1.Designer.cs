﻿namespace WindowsFormsApp3
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_timID = new System.Windows.Forms.Label();
            this.tb_timID = new System.Windows.Forms.TextBox();
            this.bt_input = new System.Windows.Forms.Button();
            this.tb_NamaTim = new System.Windows.Forms.TextBox();
            this.lb_NamaTim = new System.Windows.Forms.Label();
            this.tb_kapasitas = new System.Windows.Forms.TextBox();
            this.lb_Kapasitas = new System.Windows.Forms.Label();
            this.tb_stadium = new System.Windows.Forms.TextBox();
            this.lb_Stadium = new System.Windows.Forms.Label();
            this.tb_kota = new System.Windows.Forms.TextBox();
            this.lb_Kota = new System.Windows.Forms.Label();
            this.tb_Manager = new System.Windows.Forms.TextBox();
            this.lb_manager = new System.Windows.Forms.Label();
            this.dgv_datatim = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_datatim)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_timID
            // 
            this.lb_timID.AutoSize = true;
            this.lb_timID.Location = new System.Drawing.Point(96, 166);
            this.lb_timID.Name = "lb_timID";
            this.lb_timID.Size = new System.Drawing.Size(73, 25);
            this.lb_timID.TabIndex = 0;
            this.lb_timID.Text = "Tim ID";
            // 
            // tb_timID
            // 
            this.tb_timID.Enabled = false;
            this.tb_timID.Location = new System.Drawing.Point(282, 166);
            this.tb_timID.Name = "tb_timID";
            this.tb_timID.Size = new System.Drawing.Size(144, 31);
            this.tb_timID.TabIndex = 1;
            // 
            // bt_input
            // 
            this.bt_input.Location = new System.Drawing.Point(203, 508);
            this.bt_input.Name = "bt_input";
            this.bt_input.Size = new System.Drawing.Size(110, 42);
            this.bt_input.TabIndex = 2;
            this.bt_input.Text = "Input";
            this.bt_input.UseVisualStyleBackColor = true;
            this.bt_input.Click += new System.EventHandler(this.bt_input_Click);
            // 
            // tb_NamaTim
            // 
            this.tb_NamaTim.Location = new System.Drawing.Point(282, 216);
            this.tb_NamaTim.Name = "tb_NamaTim";
            this.tb_NamaTim.Size = new System.Drawing.Size(144, 31);
            this.tb_NamaTim.TabIndex = 4;
            this.tb_NamaTim.TextChanged += new System.EventHandler(this.tb_NamaTim_TextChanged);
            // 
            // lb_NamaTim
            // 
            this.lb_NamaTim.AutoSize = true;
            this.lb_NamaTim.Location = new System.Drawing.Point(96, 216);
            this.lb_NamaTim.Name = "lb_NamaTim";
            this.lb_NamaTim.Size = new System.Drawing.Size(109, 25);
            this.lb_NamaTim.TabIndex = 3;
            this.lb_NamaTim.Text = "Nama Tim";
            // 
            // tb_kapasitas
            // 
            this.tb_kapasitas.Location = new System.Drawing.Point(282, 318);
            this.tb_kapasitas.Name = "tb_kapasitas";
            this.tb_kapasitas.Size = new System.Drawing.Size(144, 31);
            this.tb_kapasitas.TabIndex = 8;
            // 
            // lb_Kapasitas
            // 
            this.lb_Kapasitas.AutoSize = true;
            this.lb_Kapasitas.Location = new System.Drawing.Point(96, 318);
            this.lb_Kapasitas.Name = "lb_Kapasitas";
            this.lb_Kapasitas.Size = new System.Drawing.Size(107, 25);
            this.lb_Kapasitas.TabIndex = 7;
            this.lb_Kapasitas.Text = "Kapasitas";
            // 
            // tb_stadium
            // 
            this.tb_stadium.Location = new System.Drawing.Point(282, 268);
            this.tb_stadium.Name = "tb_stadium";
            this.tb_stadium.Size = new System.Drawing.Size(144, 31);
            this.tb_stadium.TabIndex = 6;
            // 
            // lb_Stadium
            // 
            this.lb_Stadium.AutoSize = true;
            this.lb_Stadium.Location = new System.Drawing.Point(96, 268);
            this.lb_Stadium.Name = "lb_Stadium";
            this.lb_Stadium.Size = new System.Drawing.Size(152, 25);
            this.lb_Stadium.TabIndex = 5;
            this.lb_Stadium.Text = "Nama Stadium";
            // 
            // tb_kota
            // 
            this.tb_kota.Location = new System.Drawing.Point(282, 369);
            this.tb_kota.Name = "tb_kota";
            this.tb_kota.Size = new System.Drawing.Size(144, 31);
            this.tb_kota.TabIndex = 10;
            // 
            // lb_Kota
            // 
            this.lb_Kota.AutoSize = true;
            this.lb_Kota.Location = new System.Drawing.Point(96, 369);
            this.lb_Kota.Name = "lb_Kota";
            this.lb_Kota.Size = new System.Drawing.Size(56, 25);
            this.lb_Kota.TabIndex = 9;
            this.lb_Kota.Text = "Kota";
            // 
            // tb_Manager
            // 
            this.tb_Manager.Location = new System.Drawing.Point(282, 419);
            this.tb_Manager.Name = "tb_Manager";
            this.tb_Manager.Size = new System.Drawing.Size(144, 31);
            this.tb_Manager.TabIndex = 12;
            // 
            // lb_manager
            // 
            this.lb_manager.AutoSize = true;
            this.lb_manager.Location = new System.Drawing.Point(96, 419);
            this.lb_manager.Name = "lb_manager";
            this.lb_manager.Size = new System.Drawing.Size(159, 25);
            this.lb_manager.TabIndex = 11;
            this.lb_manager.Text = "Nama Manager";
            // 
            // dgv_datatim
            // 
            this.dgv_datatim.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_datatim.Location = new System.Drawing.Point(588, 147);
            this.dgv_datatim.Name = "dgv_datatim";
            this.dgv_datatim.RowHeadersWidth = 82;
            this.dgv_datatim.RowTemplate.Height = 33;
            this.dgv_datatim.Size = new System.Drawing.Size(1604, 437);
            this.dgv_datatim.TabIndex = 13;
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2884, 1464);
            this.Controls.Add(this.dgv_datatim);
            this.Controls.Add(this.tb_Manager);
            this.Controls.Add(this.lb_manager);
            this.Controls.Add(this.tb_kota);
            this.Controls.Add(this.lb_Kota);
            this.Controls.Add(this.tb_kapasitas);
            this.Controls.Add(this.lb_Kapasitas);
            this.Controls.Add(this.tb_stadium);
            this.Controls.Add(this.lb_Stadium);
            this.Controls.Add(this.tb_NamaTim);
            this.Controls.Add(this.lb_NamaTim);
            this.Controls.Add(this.bt_input);
            this.Controls.Add(this.tb_timID);
            this.Controls.Add(this.lb_timID);
            this.Name = "form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_datatim)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_timID;
        private System.Windows.Forms.TextBox tb_timID;
        private System.Windows.Forms.Button bt_input;
        private System.Windows.Forms.TextBox tb_NamaTim;
        private System.Windows.Forms.Label lb_NamaTim;
        private System.Windows.Forms.TextBox tb_kapasitas;
        private System.Windows.Forms.Label lb_Kapasitas;
        private System.Windows.Forms.TextBox tb_stadium;
        private System.Windows.Forms.Label lb_Stadium;
        private System.Windows.Forms.TextBox tb_kota;
        private System.Windows.Forms.Label lb_Kota;
        private System.Windows.Forms.TextBox tb_Manager;
        private System.Windows.Forms.Label lb_manager;
        private System.Windows.Forms.DataGridView dgv_datatim;
    }
}

