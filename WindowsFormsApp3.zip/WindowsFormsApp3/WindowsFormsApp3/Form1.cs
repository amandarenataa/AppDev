﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class form1 : Form
    {
        DataTable Tim = new DataTable();
        List<char> alphabet = new List<char>();
        public form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Tim.Columns.Add("ID Tim");
            Tim.Columns.Add("Nama Tim");
            Tim.Columns.Add("Nama Stadium");
            Tim.Columns.Add("Kapasitas");
            Tim.Columns.Add("Kota");
            Tim.Columns.Add("Nama Manager");

            dgv_datatim.DataSource = Tim;
        }

        private void tb_NamaTim_TextChanged(object sender, EventArgs e)
        {
            string nama = tb_NamaTim.Text.ToUpper();
            int count = 1;
            if (tb_NamaTim.Text == "")
            {

            }
            else
            {
                foreach (DataRow row in Tim.Rows)
                {
                    string id = row["ID Tim"].ToString().ToUpper();
                    if (id[0] == nama[0])
                    {
                        count++;
                    }
                }
                if (count <= 9)
                {
                    tb_timID.Text = $"{nama[0]}0{count}";
                }
                else
                {
                    tb_timID.Text = $"{nama[0]}{count}";
                }
            }
        }

        private void bt_input_Click(object sender, EventArgs e)
        {
            if (tb_NamaTim.Text == "" || tb_Manager.Text == "" || tb_kota.Text == "" || tb_kapasitas.Text == "" || tb_stadium.Text == "")
            {
                MessageBox.Show("Tolong isi semua terlebih dahulu","Warning",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                bool adadouble = false;
                foreach (DataRow row in Tim.Rows)
                {
                    if (row["Nama Tim"].ToString() == tb_NamaTim.Text || row["Nama Stadium"].ToString() == tb_stadium.Text || row["Nama Manager"].ToString() == tb_Manager.Text)
                    {
                        adadouble = true;
                    }
                }
                if (adadouble == true)
                {
                    MessageBox.Show("Nama Tim / Nama Stadium / Nama Manager Tidak Boleh Double", "Disclaimer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    tb_timID.Clear();
                    tb_NamaTim.Clear();
                    tb_stadium.Clear();
                    tb_kapasitas.Clear();
                    tb_kota.Clear();
                    tb_Manager.Clear();
                }
                else
                {
                    Tim.Rows.Add(tb_timID.Text, tb_NamaTim.Text, tb_stadium.Text, tb_kapasitas.Text, tb_kota.Text, tb_Manager.Text);
                    tb_timID.Clear();
                    tb_NamaTim.Clear();
                    tb_stadium.Clear();
                    tb_kapasitas.Clear();
                    tb_kota.Clear();
                    tb_Manager.Clear();
                }
            }
        }
    }
}
