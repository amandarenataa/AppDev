﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Selasa_Week_15
{
    public partial class F1 : Form
    {
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dtTeam;
        DataTable dtTeam2;
        DataTable dtMatch;

        public F1()
        {
            InitializeComponent();
        }

        private void F1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            conn.Open();
            conn.Close();

            string sql = "select team.team_id, team.team_name, team.home_stadium, team.capacity, manager.manager_name, player.player_id, team.city from team left join manager on team.manager_id = manager.manager_id left join player on team.captain_id = player.player_id";
            cmd = new MySqlCommand(sql, conn);

            dtTeam = new DataTable();
            dtTeam2 = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtTeam);
            adapter.Fill(dtTeam2);

            cb_TeamHome.DataSource = dtTeam;
            cb_TeamHome.ValueMember = "team_id";
            cb_TeamHome.DisplayMember = "team_name";
            cb_TeamHome.SelectedIndex = -1;

            cb_TeamAway.DataSource = dtTeam2;
            cb_TeamAway.ValueMember = "team_id";
            cb_TeamAway.DisplayMember = "team_name";
            cb_TeamAway.SelectedIndex = -1;
        }
        string TeamHome;
        private void cb_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (cb_TeamHome.SelectedIndex == -1)
            {

            }
            else
            {
                TeamHome = cb_TeamHome.SelectedValue.ToString();

                foreach (DataRow dr in dtTeam.Rows)
                {
                    if (dr[0].ToString() == TeamHome)
                    {
                        lb_MHome.Text = dr[4].ToString();
                        lb_CHome.Text = dr[5].ToString();
                    }
                }

                foreach (DataRow dr in dtTeam.Rows)
                {
                    if (dr[0].ToString() == TeamHome)
                    {
                        lb_StadiumHome.Text = $"{dr[2]}, {dr[6]}";
                        lb_CapacityHome.Text = dr[3].ToString();
                    }
                }
            }
        }
        string TeamAway;
        private void cb_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cb_TeamAway.SelectedIndex == -1)
            {

            }
            else
            {
                if (TeamHome == cb_TeamAway.SelectedValue.ToString() && cb_TeamAway.SelectedIndex != -1 && cb_TeamHome.SelectedIndex != -1)
                {
                    MessageBox.Show("ERROR");
                    cb_TeamAway.SelectedIndex = -1;
                }
                else
                {
                    TeamAway = cb_TeamAway.SelectedValue.ToString();

                    foreach (DataRow dr in dtTeam2.Rows)
                    {
                        if (dr[0].ToString() == TeamAway)
                        {
                            lb_MAway.Text = dr[4].ToString();
                            lb_CAway.Text = dr[5].ToString();
                        }
                    }

                    
                }
            }

        }
        DataTable dtDMatch;
        string match;
        private void bt_check_Click(object sender, EventArgs e)
        {
            string sql = $"select match_id, concat(day(match_date),' ', monthname(match_date),' ', year(match_date)), team_home, team_away, goal_home, goal_away from `match` where team_home = '{TeamHome}' and team_away = '{TeamAway}'";
            cmd = new MySqlCommand(sql, conn);

            dtMatch = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtMatch);

            dgv_match.DataSource = dtMatch;

            foreach (DataRow dr in dtMatch.Rows)
            {
                lb_TanggalMatch.Text = dr[1].ToString();
                lb_SkorMatch.Text = $"{dr[4]} - {dr[5]}";
                match = dr[0].ToString();
            }

            sql = $"select dmatch.minute as minute, if( dmatch.team_id = '{TeamHome}' ,player.player_name,'') as 'Player Name 1', if( dmatch.team_id = '{TeamHome}' ,if(dmatch.type = 'CY', 'YELLOW CARD',if(dmatch.type = 'CR', 'RED CARD',if(dmatch.type = 'GO', 'GOAL',if(dmatch.type = 'GP', 'PENALTY GOAL',if(dmatch.type = 'GW', 'OWN GOAL',if(dmatch.type = 'PM', 'PENALTY MISS','')))))), '') as 'Tipe 1', if( dmatch.team_id = '{TeamAway}' ,player.player_name,'') as 'Player Name 2', if( dmatch.team_id = '{TeamAway}' ,if(dmatch.type = 'CY', 'YELLOW CARD',if(dmatch.type = 'CR', 'RED CARD',if(dmatch.type = 'GO', 'GOAL',if(dmatch.type = 'GP', 'PENALTY GOAL',if(dmatch.type = 'GW', 'OWN GOAL',if(dmatch.type = 'PM', 'PENALTY MISS','')))))), '') as 'Tipe 2' from dmatch left join player on player.player_id = dmatch.player_id where dmatch.match_id = '{match}'";
            cmd = new MySqlCommand(sql, conn);

            dtDMatch = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDMatch);

            dgv_data.DataSource = dtDMatch;
        }
    }
}
