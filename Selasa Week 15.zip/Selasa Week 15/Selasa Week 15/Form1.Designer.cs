﻿namespace Selasa_Week_15
{
    partial class F1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_TeamHome = new System.Windows.Forms.ComboBox();
            this.cb_TeamAway = new System.Windows.Forms.ComboBox();
            this.lb_vs = new System.Windows.Forms.Label();
            this.lb_manager = new System.Windows.Forms.Label();
            this.lb_captain = new System.Windows.Forms.Label();
            this.lb_captain2 = new System.Windows.Forms.Label();
            this.lb_manager2 = new System.Windows.Forms.Label();
            this.lb_CHome = new System.Windows.Forms.Label();
            this.lb_MHome = new System.Windows.Forms.Label();
            this.lb_CAway = new System.Windows.Forms.Label();
            this.lb_MAway = new System.Windows.Forms.Label();
            this.lb_CapacityHome = new System.Windows.Forms.Label();
            this.lb_StadiumHome = new System.Windows.Forms.Label();
            this.lb_capacity = new System.Windows.Forms.Label();
            this.lb_stadium = new System.Windows.Forms.Label();
            this.dgv_data = new System.Windows.Forms.DataGridView();
            this.bt_check = new System.Windows.Forms.Button();
            this.lb_SkorMatch = new System.Windows.Forms.Label();
            this.lb_TanggalMatch = new System.Windows.Forms.Label();
            this.lb_skor = new System.Windows.Forms.Label();
            this.lb_tanggal = new System.Windows.Forms.Label();
            this.dgv_match = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_TeamHome
            // 
            this.cb_TeamHome.FormattingEnabled = true;
            this.cb_TeamHome.Location = new System.Drawing.Point(93, 71);
            this.cb_TeamHome.Name = "cb_TeamHome";
            this.cb_TeamHome.Size = new System.Drawing.Size(353, 33);
            this.cb_TeamHome.TabIndex = 0;
            this.cb_TeamHome.SelectedIndexChanged += new System.EventHandler(this.cb_TeamHome_SelectedIndexChanged);
            // 
            // cb_TeamAway
            // 
            this.cb_TeamAway.FormattingEnabled = true;
            this.cb_TeamAway.Location = new System.Drawing.Point(953, 71);
            this.cb_TeamAway.Name = "cb_TeamAway";
            this.cb_TeamAway.Size = new System.Drawing.Size(353, 33);
            this.cb_TeamAway.TabIndex = 1;
            this.cb_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cb_TeamAway_SelectedIndexChanged);
            // 
            // lb_vs
            // 
            this.lb_vs.AutoSize = true;
            this.lb_vs.Location = new System.Drawing.Point(656, 79);
            this.lb_vs.Name = "lb_vs";
            this.lb_vs.Size = new System.Drawing.Size(40, 25);
            this.lb_vs.TabIndex = 2;
            this.lb_vs.Text = "VS";
            // 
            // lb_manager
            // 
            this.lb_manager.AutoSize = true;
            this.lb_manager.Location = new System.Drawing.Point(88, 152);
            this.lb_manager.Name = "lb_manager";
            this.lb_manager.Size = new System.Drawing.Size(109, 25);
            this.lb_manager.TabIndex = 3;
            this.lb_manager.Text = "Manager :";
            // 
            // lb_captain
            // 
            this.lb_captain.AutoSize = true;
            this.lb_captain.Location = new System.Drawing.Point(88, 206);
            this.lb_captain.Name = "lb_captain";
            this.lb_captain.Size = new System.Drawing.Size(98, 25);
            this.lb_captain.TabIndex = 4;
            this.lb_captain.Text = "Captain :";
            // 
            // lb_captain2
            // 
            this.lb_captain2.AutoSize = true;
            this.lb_captain2.Location = new System.Drawing.Point(948, 206);
            this.lb_captain2.Name = "lb_captain2";
            this.lb_captain2.Size = new System.Drawing.Size(98, 25);
            this.lb_captain2.TabIndex = 6;
            this.lb_captain2.Text = "Captain :";
            // 
            // lb_manager2
            // 
            this.lb_manager2.AutoSize = true;
            this.lb_manager2.Location = new System.Drawing.Point(948, 152);
            this.lb_manager2.Name = "lb_manager2";
            this.lb_manager2.Size = new System.Drawing.Size(109, 25);
            this.lb_manager2.TabIndex = 5;
            this.lb_manager2.Text = "Manager :";
            // 
            // lb_CHome
            // 
            this.lb_CHome.AutoSize = true;
            this.lb_CHome.Location = new System.Drawing.Point(247, 206);
            this.lb_CHome.Name = "lb_CHome";
            this.lb_CHome.Size = new System.Drawing.Size(19, 25);
            this.lb_CHome.TabIndex = 8;
            this.lb_CHome.Text = "-";
            // 
            // lb_MHome
            // 
            this.lb_MHome.AutoSize = true;
            this.lb_MHome.Location = new System.Drawing.Point(247, 152);
            this.lb_MHome.Name = "lb_MHome";
            this.lb_MHome.Size = new System.Drawing.Size(19, 25);
            this.lb_MHome.TabIndex = 7;
            this.lb_MHome.Text = "-";
            // 
            // lb_CAway
            // 
            this.lb_CAway.AutoSize = true;
            this.lb_CAway.Location = new System.Drawing.Point(1105, 206);
            this.lb_CAway.Name = "lb_CAway";
            this.lb_CAway.Size = new System.Drawing.Size(19, 25);
            this.lb_CAway.TabIndex = 10;
            this.lb_CAway.Text = "-";
            // 
            // lb_MAway
            // 
            this.lb_MAway.AutoSize = true;
            this.lb_MAway.Location = new System.Drawing.Point(1105, 152);
            this.lb_MAway.Name = "lb_MAway";
            this.lb_MAway.Size = new System.Drawing.Size(19, 25);
            this.lb_MAway.TabIndex = 9;
            this.lb_MAway.Text = "-";
            // 
            // lb_CapacityHome
            // 
            this.lb_CapacityHome.AutoSize = true;
            this.lb_CapacityHome.Location = new System.Drawing.Point(781, 330);
            this.lb_CapacityHome.Name = "lb_CapacityHome";
            this.lb_CapacityHome.Size = new System.Drawing.Size(19, 25);
            this.lb_CapacityHome.TabIndex = 14;
            this.lb_CapacityHome.Text = "-";
            // 
            // lb_StadiumHome
            // 
            this.lb_StadiumHome.AutoSize = true;
            this.lb_StadiumHome.Location = new System.Drawing.Point(781, 276);
            this.lb_StadiumHome.Name = "lb_StadiumHome";
            this.lb_StadiumHome.Size = new System.Drawing.Size(19, 25);
            this.lb_StadiumHome.TabIndex = 13;
            this.lb_StadiumHome.Text = "-";
            // 
            // lb_capacity
            // 
            this.lb_capacity.AutoSize = true;
            this.lb_capacity.Location = new System.Drawing.Point(622, 330);
            this.lb_capacity.Name = "lb_capacity";
            this.lb_capacity.Size = new System.Drawing.Size(108, 25);
            this.lb_capacity.TabIndex = 12;
            this.lb_capacity.Text = "Capacity :";
            // 
            // lb_stadium
            // 
            this.lb_stadium.AutoSize = true;
            this.lb_stadium.Location = new System.Drawing.Point(622, 276);
            this.lb_stadium.Name = "lb_stadium";
            this.lb_stadium.Size = new System.Drawing.Size(102, 25);
            this.lb_stadium.TabIndex = 11;
            this.lb_stadium.Text = "Stadium :";
            // 
            // dgv_data
            // 
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(18, 542);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 82;
            this.dgv_data.RowTemplate.Height = 33;
            this.dgv_data.Size = new System.Drawing.Size(1459, 265);
            this.dgv_data.TabIndex = 15;
            // 
            // bt_check
            // 
            this.bt_check.Location = new System.Drawing.Point(29, 484);
            this.bt_check.Name = "bt_check";
            this.bt_check.Size = new System.Drawing.Size(185, 36);
            this.bt_check.TabIndex = 16;
            this.bt_check.Text = "Check";
            this.bt_check.UseVisualStyleBackColor = true;
            this.bt_check.Click += new System.EventHandler(this.bt_check_Click);
            // 
            // lb_SkorMatch
            // 
            this.lb_SkorMatch.AutoSize = true;
            this.lb_SkorMatch.Location = new System.Drawing.Point(781, 489);
            this.lb_SkorMatch.Name = "lb_SkorMatch";
            this.lb_SkorMatch.Size = new System.Drawing.Size(19, 25);
            this.lb_SkorMatch.TabIndex = 20;
            this.lb_SkorMatch.Text = "-";
            // 
            // lb_TanggalMatch
            // 
            this.lb_TanggalMatch.AutoSize = true;
            this.lb_TanggalMatch.Location = new System.Drawing.Point(781, 435);
            this.lb_TanggalMatch.Name = "lb_TanggalMatch";
            this.lb_TanggalMatch.Size = new System.Drawing.Size(19, 25);
            this.lb_TanggalMatch.TabIndex = 19;
            this.lb_TanggalMatch.Text = "-";
            // 
            // lb_skor
            // 
            this.lb_skor.AutoSize = true;
            this.lb_skor.Location = new System.Drawing.Point(622, 489);
            this.lb_skor.Name = "lb_skor";
            this.lb_skor.Size = new System.Drawing.Size(68, 25);
            this.lb_skor.TabIndex = 18;
            this.lb_skor.Text = "Skor :";
            // 
            // lb_tanggal
            // 
            this.lb_tanggal.AutoSize = true;
            this.lb_tanggal.Location = new System.Drawing.Point(622, 435);
            this.lb_tanggal.Name = "lb_tanggal";
            this.lb_tanggal.Size = new System.Drawing.Size(102, 25);
            this.lb_tanggal.TabIndex = 17;
            this.lb_tanggal.Text = "Tanggal :";
            // 
            // dgv_match
            // 
            this.dgv_match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_match.Location = new System.Drawing.Point(18, 824);
            this.dgv_match.Name = "dgv_match";
            this.dgv_match.RowHeadersWidth = 82;
            this.dgv_match.RowTemplate.Height = 33;
            this.dgv_match.Size = new System.Drawing.Size(1459, 265);
            this.dgv_match.TabIndex = 21;
            // 
            // F1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1496, 1114);
            this.Controls.Add(this.dgv_match);
            this.Controls.Add(this.lb_SkorMatch);
            this.Controls.Add(this.lb_TanggalMatch);
            this.Controls.Add(this.lb_skor);
            this.Controls.Add(this.lb_tanggal);
            this.Controls.Add(this.bt_check);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.lb_CapacityHome);
            this.Controls.Add(this.lb_StadiumHome);
            this.Controls.Add(this.lb_capacity);
            this.Controls.Add(this.lb_stadium);
            this.Controls.Add(this.lb_CAway);
            this.Controls.Add(this.lb_MAway);
            this.Controls.Add(this.lb_CHome);
            this.Controls.Add(this.lb_MHome);
            this.Controls.Add(this.lb_captain2);
            this.Controls.Add(this.lb_manager2);
            this.Controls.Add(this.lb_captain);
            this.Controls.Add(this.lb_manager);
            this.Controls.Add(this.lb_vs);
            this.Controls.Add(this.cb_TeamAway);
            this.Controls.Add(this.cb_TeamHome);
            this.Name = "F1";
            this.Text = "F1";
            this.Load += new System.EventHandler(this.F1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_TeamHome;
        private System.Windows.Forms.ComboBox cb_TeamAway;
        private System.Windows.Forms.Label lb_vs;
        private System.Windows.Forms.Label lb_manager;
        private System.Windows.Forms.Label lb_captain;
        private System.Windows.Forms.Label lb_captain2;
        private System.Windows.Forms.Label lb_manager2;
        private System.Windows.Forms.Label lb_CHome;
        private System.Windows.Forms.Label lb_MHome;
        private System.Windows.Forms.Label lb_CAway;
        private System.Windows.Forms.Label lb_MAway;
        private System.Windows.Forms.Label lb_CapacityHome;
        private System.Windows.Forms.Label lb_StadiumHome;
        private System.Windows.Forms.Label lb_capacity;
        private System.Windows.Forms.Label lb_stadium;
        private System.Windows.Forms.DataGridView dgv_data;
        private System.Windows.Forms.Button bt_check;
        private System.Windows.Forms.Label lb_SkorMatch;
        private System.Windows.Forms.Label lb_TanggalMatch;
        private System.Windows.Forms.Label lb_skor;
        private System.Windows.Forms.Label lb_tanggal;
        private System.Windows.Forms.DataGridView dgv_match;
    }
}

