﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rabu_week_8
{
    public partial class Form1 : Form
    {
        // menu strip itu yang file edit dll yang diatas
        // tool strip sama bedanya cuman tampilannya, satu gambar satu tulisan
        public Form1()
        {
            InitializeComponent();
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are You Sure?", "Exit",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void ts_eskrim_Click(object sender, EventArgs e)
        {
            Form2 ts = new Form2();
            //ts.ShowDialog(); //harus selesaikan apa yang dilakukan diform itu sebelum ke form lain
            ts.MdiParent = this; // this adalah form 1
            ts.Show(); 
        }
    }
}
