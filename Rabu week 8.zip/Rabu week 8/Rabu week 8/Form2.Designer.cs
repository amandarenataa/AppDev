﻿namespace Rabu_week_8
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_form2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_form2
            // 
            this.bt_form2.Location = new System.Drawing.Point(411, 220);
            this.bt_form2.Name = "bt_form2";
            this.bt_form2.Size = new System.Drawing.Size(568, 236);
            this.bt_form2.TabIndex = 0;
            this.bt_form2.Text = "HIHIHIHHI";
            this.bt_form2.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1467, 739);
            this.Controls.Add(this.bt_form2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_form2;
    }
}