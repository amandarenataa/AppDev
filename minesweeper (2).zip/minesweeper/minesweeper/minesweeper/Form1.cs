﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minesweeper
{
    public partial class F1 : Form
    {
        List<Button> buttons;
        public Button btn2;
        public F1()
        {
            InitializeComponent();
        }
        Random random = new Random();
        List<string> boms = new List<string>();
        private void F1_Load(object sender, EventArgs e)
        {
            int locationY = 50;
            int locationX = 50;
            buttons = new List<Button>();
            int bom = 0;
            int count = 10;
            for (int i = 0; i < 10; i++)// untuk bomnya dirandomdi button apa
            {
                bom = random.Next(10, 80);
                boms.Add(bom.ToString());
            }
            for (int j = 1; j < 9; j++) // untuk ngeprint buttonnya
            {
                for (int i = 1; i < 11; i++)
                {
                    btn2 = new Button();
                    btn2.Text = "";
                    btn2.Tag = $"{count}";
                    btn2.Size = new Size(50, 50);
                    btn2.Location = new Point(locationX, locationY);
                    locationX += 50;
                    btn2.BackColor = Color.LightGreen;
                    btn2.ForeColor = Color.Green;
                    buttons.Add(btn2);
                    this.Controls.Add(btn2);
                    count++;
                }
                locationX = 50;
                locationY += 60;
            }
            foreach (Button button in buttons) //untuk button bisa diclick and for the isi (bom or no or deket bom)
            {
                button.Click += new EventHandler(btnClick);
                int adaBrp = 0;
                int koordinat = Convert.ToInt32(button.Tag);
                if (boms.Contains(button.Tag))
                {
                    button.BackColor = Color.Red;
                    button.Tag = $"*{koordinat}";
                }
                else
                {
                    if (boms.Contains($"{koordinat + 1}") && koordinat % 10 != 0)
                    {
                        adaBrp++;
                    }
                    if (boms.Contains($"{koordinat + 10}") && koordinat > 10)
                    {
                        adaBrp++;
                    }
                    if (boms.Contains($"{koordinat - 10}") && koordinat < 90)
                    {
                        adaBrp++;
                    }
                    if (boms.Contains($"{koordinat - 1}") && koordinat % 10 != 9)
                    {
                        adaBrp++;
                    }
                    if (boms.Contains($"{koordinat - 10 - 1}") && koordinat % 10 != 9 && koordinat < 90)
                    {
                        adaBrp++;
                    }
                    if (boms.Contains($"{koordinat - 10 + 1}") && koordinat % 10 != 9 && koordinat > 10)
                    {
                        adaBrp++;
                    }
                    if (boms.Contains($"{koordinat + 10 - 1}") && koordinat % 10 != 0)
                    {
                        adaBrp++;
                    }
                    if (boms.Contains($"{koordinat + 10 + 1}") && koordinat % 10 != 0 && koordinat > 10)
                    {
                        adaBrp++;
                    }
                    if (adaBrp > 0)
                    {
                        button.Tag = $"{adaBrp}{koordinat}";
                    }
                    else
                    {
                        button.Tag = $" {koordinat}";
                    }
                }

            }
        }
        public void btnClick(object sender, EventArgs e) // nich yang muncul
        {
            Button sebuahbutton = (Button)sender;
            if (sebuahbutton.Tag.ToString() == "*")
            {
                MessageBox.Show("YOU LOST");
                this.Close();
            }
            else if (sebuahbutton.Tag.ToString().Substring(0, 1) != "")
            {
                sebuahbutton.BackColor = Color.Beige;
                sebuahbutton.Text = sebuahbutton.Tag.ToString().Substring(0, 1);
            }
            else
            {
                sebuahbutton.BackColor = Color.Beige;
                sebuahbutton.Text = sebuahbutton.Tag.ToString().Substring(0, 1);
                if (sebuahbutton.Text == " ")
                {
                    int koordinat = Convert.ToInt32(sebuahbutton.Tag.ToString().Substring(1));
                    RevealEmptyCells(koordinat);
                }
            }

        }
        public void RevealEmptyCells(int koordinat)
        {
            int x = koordinat % 10;
            int y = koordinat / 10;
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    int x2 = x + j;
                    int y2 = y + i;
                    if (x2 >= 0 && x2 < 10 && y2 >= 0 && y2 < 8)
                    {
                        int index = y2 * 10 + x2;
                        Button surroundingButton = buttons[index];
                        if (surroundingButton.Text == "")
                        {
                            surroundingButton.BackColor = Color.Beige;
                            surroundingButton.Text = surroundingButton.Tag.ToString().Substring(0, 1);
                            if (surroundingButton.Text == " ")
                            {
                                int newKoordinat = Convert.ToInt32(surroundingButton.Tag.ToString().Substring(1));
                                RevealEmptyCells(newKoordinat);
                            }
                        }
                    }
                }
            }
        }

    }
}
