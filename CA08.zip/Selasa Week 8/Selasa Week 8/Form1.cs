﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Selasa_Week_8
{
    public partial class F1 : Form
    {
        OpenFileDialog OpenFile = new OpenFileDialog();
        StreamReader streamReader;
        List<string> lines = new List<string>();
        public string NamaFile;
        public int count;
        public F1()
        {
            InitializeComponent();
        }

        private void bt_bacaFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog OpenFile = new OpenFileDialog();
            OpenFile.Filter = "Text File (*txt)|*txt|All Files(*.*)|*.*"; // sebelum "|" tuh ya penampilan aja yang penting setelah "|" untuk tau filter e
            OpenFile.InitialDirectory = "Y:\\"; // meleh buka yang mana
            OpenFile.FilterIndex = 2; // meleh index awal 
            OpenFile.ShowDialog();
            //MessageBox.Show(OpenFile.FileName); // openfile.filename isa masuk ke string

            StreamReader streamReader = new StreamReader(OpenFile.FileName); // buka file, spesifik txt untuk saat ini
            string line = streamReader.ReadLine(); // mbaca 1 line di file text mu
            while (line != null)
            {
                MessageBox.Show(line);
                line = streamReader.ReadLine();
            }
            streamReader.Close();

            StreamWriter sw = new StreamWriter(OpenFile.FileName);
            sw.WriteLine("HIHIHIHIHI");
            sw.Close();
        }

        private void bt_simpan_Click(object sender, EventArgs e)
        {
            streamReader.Close();
            lines.Add($"{tb_nama.Text};{tb_alamat.Text};{tb_notelp.Text}");

            tb_alamat.Clear();
            tb_nama.Clear();
            tb_notelp.Clear();
        }
        private void bt_pilihfile_Click(object sender, EventArgs e)
        {
            OpenFile.ShowDialog();
            NamaFile = OpenFile.FileName;
            streamReader = new StreamReader(NamaFile);
            string line = streamReader.ReadLine(); 
            while (line != null)
            {
                lines.Add(line);
                line = streamReader.ReadLine();
            }
            streamReader.Close();
        }

        private void bt_lihat_Click(object sender, EventArgs e)
        {
            bt_back.Visible = true;
            bt_lihat.Visible = false;
            bt_next.Visible = true;
            bt_prev.Visible = true;
            bt_simpan.Visible = false;
            tb_notelp.Enabled = false;
            tb_alamat.Enabled = false;
            tb_nama.Enabled = false;
            StreamWriter sw = new StreamWriter(NamaFile);
            foreach (string l in lines)
            {
                sw.WriteLine(l);
            }
            sw.Close();
            count = 0;
            string[] nama = lines[count].Split(';');
            tb_nama.Text = nama[0];
            tb_alamat.Text = nama[1];
            tb_notelp.Text = nama[2];

        }

        private void bt_next_Click(object sender, EventArgs e)
        {
            if (count < lines.Count - 1)
            {
                count++;
                string[] nama = lines[count].Split(';');
                tb_nama.Text = nama[0];
                tb_alamat.Text = nama[1];
                tb_notelp.Text = nama[2];
            }
        }

        private void bt_prev_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                count--;
                string[] nama = lines[count].Split(';');
                tb_nama.Text = nama[0];
                tb_alamat.Text = nama[1];
                tb_notelp.Text = nama[2];
            }
        }

        private void bt_back_Click(object sender, EventArgs e)
        {
            bt_back.Visible = false;
            bt_lihat.Visible = true;
            bt_next.Visible = false;
            bt_prev.Visible = false;
            bt_simpan.Visible = true;
            tb_notelp.Enabled = true;
            tb_alamat.Enabled = true;
            tb_nama.Enabled = true;
            tb_alamat.Clear();
            tb_nama.Clear();
            tb_notelp.Clear();
        }
    }
}
