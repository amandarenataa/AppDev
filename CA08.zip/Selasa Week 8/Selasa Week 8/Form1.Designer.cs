﻿namespace Selasa_Week_8
{
    partial class F1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_bacaFile = new System.Windows.Forms.Button();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_Alamat = new System.Windows.Forms.Label();
            this.lb_notelp = new System.Windows.Forms.Label();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_alamat = new System.Windows.Forms.TextBox();
            this.tb_notelp = new System.Windows.Forms.TextBox();
            this.bt_simpan = new System.Windows.Forms.Button();
            this.bt_lihat = new System.Windows.Forms.Button();
            this.bt_pilihfile = new System.Windows.Forms.Button();
            this.bt_prev = new System.Windows.Forms.Button();
            this.bt_next = new System.Windows.Forms.Button();
            this.bt_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_bacaFile
            // 
            this.bt_bacaFile.Location = new System.Drawing.Point(2309, 1024);
            this.bt_bacaFile.Name = "bt_bacaFile";
            this.bt_bacaFile.Size = new System.Drawing.Size(171, 58);
            this.bt_bacaFile.TabIndex = 0;
            this.bt_bacaFile.Text = "Baca File";
            this.bt_bacaFile.UseVisualStyleBackColor = true;
            this.bt_bacaFile.Click += new System.EventHandler(this.bt_bacaFile_Click);
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(409, 122);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(68, 25);
            this.lb_nama.TabIndex = 1;
            this.lb_nama.Text = "Nama";
            // 
            // lb_Alamat
            // 
            this.lb_Alamat.AutoSize = true;
            this.lb_Alamat.Location = new System.Drawing.Point(399, 169);
            this.lb_Alamat.Name = "lb_Alamat";
            this.lb_Alamat.Size = new System.Drawing.Size(78, 25);
            this.lb_Alamat.TabIndex = 2;
            this.lb_Alamat.Text = "Alamat";
            // 
            // lb_notelp
            // 
            this.lb_notelp.AutoSize = true;
            this.lb_notelp.Location = new System.Drawing.Point(390, 217);
            this.lb_notelp.Name = "lb_notelp";
            this.lb_notelp.Size = new System.Drawing.Size(87, 25);
            this.lb_notelp.TabIndex = 3;
            this.lb_notelp.Text = "No Telp";
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(501, 119);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(476, 31);
            this.tb_nama.TabIndex = 4;
            // 
            // tb_alamat
            // 
            this.tb_alamat.Location = new System.Drawing.Point(501, 166);
            this.tb_alamat.Name = "tb_alamat";
            this.tb_alamat.Size = new System.Drawing.Size(476, 31);
            this.tb_alamat.TabIndex = 5;
            // 
            // tb_notelp
            // 
            this.tb_notelp.Location = new System.Drawing.Point(501, 217);
            this.tb_notelp.Name = "tb_notelp";
            this.tb_notelp.Size = new System.Drawing.Size(476, 31);
            this.tb_notelp.TabIndex = 6;
            // 
            // bt_simpan
            // 
            this.bt_simpan.Location = new System.Drawing.Point(501, 278);
            this.bt_simpan.Name = "bt_simpan";
            this.bt_simpan.Size = new System.Drawing.Size(118, 45);
            this.bt_simpan.TabIndex = 7;
            this.bt_simpan.Text = "Simpan";
            this.bt_simpan.UseVisualStyleBackColor = true;
            this.bt_simpan.Click += new System.EventHandler(this.bt_simpan_Click);
            // 
            // bt_lihat
            // 
            this.bt_lihat.Location = new System.Drawing.Point(625, 278);
            this.bt_lihat.Name = "bt_lihat";
            this.bt_lihat.Size = new System.Drawing.Size(118, 45);
            this.bt_lihat.TabIndex = 8;
            this.bt_lihat.Text = "Lihat";
            this.bt_lihat.UseVisualStyleBackColor = true;
            this.bt_lihat.Click += new System.EventHandler(this.bt_lihat_Click);
            // 
            // bt_pilihfile
            // 
            this.bt_pilihfile.Location = new System.Drawing.Point(1221, 112);
            this.bt_pilihfile.Name = "bt_pilihfile";
            this.bt_pilihfile.Size = new System.Drawing.Size(118, 45);
            this.bt_pilihfile.TabIndex = 9;
            this.bt_pilihfile.Text = "File";
            this.bt_pilihfile.UseVisualStyleBackColor = true;
            this.bt_pilihfile.Click += new System.EventHandler(this.bt_pilihfile_Click);
            // 
            // bt_prev
            // 
            this.bt_prev.Location = new System.Drawing.Point(501, 278);
            this.bt_prev.Name = "bt_prev";
            this.bt_prev.Size = new System.Drawing.Size(118, 45);
            this.bt_prev.TabIndex = 10;
            this.bt_prev.Text = "Prev";
            this.bt_prev.UseVisualStyleBackColor = true;
            this.bt_prev.Visible = false;
            this.bt_prev.Click += new System.EventHandler(this.bt_prev_Click);
            // 
            // bt_next
            // 
            this.bt_next.Location = new System.Drawing.Point(625, 278);
            this.bt_next.Name = "bt_next";
            this.bt_next.Size = new System.Drawing.Size(118, 45);
            this.bt_next.TabIndex = 11;
            this.bt_next.Text = "Next";
            this.bt_next.UseVisualStyleBackColor = true;
            this.bt_next.Visible = false;
            this.bt_next.Click += new System.EventHandler(this.bt_next_Click);
            // 
            // bt_back
            // 
            this.bt_back.Location = new System.Drawing.Point(749, 278);
            this.bt_back.Name = "bt_back";
            this.bt_back.Size = new System.Drawing.Size(118, 45);
            this.bt_back.TabIndex = 12;
            this.bt_back.Text = "Back";
            this.bt_back.UseVisualStyleBackColor = true;
            this.bt_back.Visible = false;
            this.bt_back.Click += new System.EventHandler(this.bt_back_Click);
            // 
            // F1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2505, 1105);
            this.Controls.Add(this.bt_back);
            this.Controls.Add(this.bt_next);
            this.Controls.Add(this.bt_prev);
            this.Controls.Add(this.bt_pilihfile);
            this.Controls.Add(this.bt_lihat);
            this.Controls.Add(this.bt_simpan);
            this.Controls.Add(this.tb_notelp);
            this.Controls.Add(this.tb_alamat);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.lb_notelp);
            this.Controls.Add(this.lb_Alamat);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.bt_bacaFile);
            this.Name = "F1";
            this.Text = "F1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_bacaFile;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_Alamat;
        private System.Windows.Forms.Label lb_notelp;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_alamat;
        private System.Windows.Forms.TextBox tb_notelp;
        private System.Windows.Forms.Button bt_simpan;
        private System.Windows.Forms.Button bt_lihat;
        private System.Windows.Forms.Button bt_pilihfile;
        private System.Windows.Forms.Button bt_prev;
        private System.Windows.Forms.Button bt_next;
        private System.Windows.Forms.Button bt_back;
    }
}

