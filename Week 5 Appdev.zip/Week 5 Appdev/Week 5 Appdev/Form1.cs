﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_5_Appdev
{
    public partial class Form1 : Form
    {
        List<Team> teams;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            teams = new List<Team>();
            List<Player> players = new List<Player>
            {
                new Player("Nayeon", "GK", "01"),
                new Player ("Jeongyeon","DF","02"),
                new Player("Jihyo","FW","03")
            };
            teams.Add(new Team("Big3", "South Korea", "Seoul", players));
            players = new List<Player>
            {
                new Player("Momo", "GK", "01"),
                new Player ("Sana","DF","02"),
                new Player("Mina","FW","03")
            };
            teams.Add(new Team("Misamo", "Japan", "Osaka", players));
            players = new List<Player>
            {
                new Player("Dahyun", "GK", "01"),
                new Player ("Chaeyeong","DF","02"),
                new Player("Tzuyu","FW","04")
            };
            teams.Add(new Team("School Meal Club", "Taiwan", "Taipei", players));
        }

        private void bt_Show_Click(object sender, EventArgs e)
        { 
            foreach ( Team t in teams)
            {
                t.addPlayer(new Player("Somi", "DF", "03"));
                List<Player> players = t.getPlayerList();
                string playerout = "";
                foreach( Player p in players)
                {
                    playerout += p.getPlayerName() + " " + p.getPlayerNumber() + ", ";
                }
                string output = t.getTeamName() + " is a " + t.getTeamCountry() + " team with " 
                    + playerout ;
                MessageBox.Show(output);
            }
        }
    }
}
