﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Week_5_Appdev
{
    internal class Team
    {
        // private = tidak bisa diakses diluar class itu sendiri
        private string TeamName;
        private string TeamCountry;
        private string TeamCity;
        private List<Player> PlayerList;
        public string phoneNumber;
        private string privatePhoneNumber;

        //Constructor
        public Team(string teamName, string teamCountry, string teamCity, List<Player> playerList)
        {
            TeamName = teamName;
            TeamCountry = teamCountry;
            TeamCity = teamCity;
            PlayerList = playerList;
        }

        // Getter 
        public string getTeamName() {  return TeamName; }
        public string getTeamCountry() { return TeamCountry;}
        public string getTeamCity() { return TeamCity;}
        public List<Player> getPlayerList() { return PlayerList;}

        // Setter 
        public void setTeamName(string _teamName) {  TeamName = _teamName; }
        public void setTeamCountry(string _teamCountry) {  TeamCountry = _teamCountry; }
        public void setTeamCity(string _teamCity) {  TeamCity = _teamCity; }
        public void setTeamPlayer(List<Player> _playerList) {  PlayerList = _playerList; }
        public void setPrivatePhone(string _phone)
        {
            if (_phone.Contains("A"))
            {
                MessageBox.Show("Error");
            }
            else
            {
                privatePhoneNumber = _phone;
            }
        }
        public void addPlayer(Player player)
        {
            bool kembar = false;
            foreach (Player p in PlayerList)
            {
                if (p.getPlayerNumber() == player.getPlayerNumber())
                {
                    kembar = true;
                    break;
                }
            }
            if (kembar)
            {
                MessageBox.Show("Ada Player dengan nomor sama");
            }
            else
            {
                PlayerList.Add(player);
            }
        }
    }
}
