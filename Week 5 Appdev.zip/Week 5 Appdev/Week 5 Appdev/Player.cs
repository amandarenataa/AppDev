﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_5_Appdev
{
    internal class Player
    {
        private string playerName;
        private string playerNumber;
        private string playerPos;

        //Constructor == dipanggil setiap classnya dibuat
        public Player(string _playerName, string _playerPos, string _playerNumber )
        {
            playerName = _playerName;
            playerNumber = _playerNumber;
            playerPos = _playerPos;
        }
        //Getter == return value dari sebuah attribute
        public string getPlayerName() { return playerName; }
        public string getPlayerNumber() {  return playerNumber; }
        public string getPlayerPos() {  return playerPos; }

        //Setter == set value dari sebuah attribute
        public void setPlayerName(string playerName) {  this.playerName = playerName; }
        public void setPlayerNumber(string playerNumber) {  this.playerNumber = playerNumber; }
        public void setPlayerPos(string playerPos) {  this.playerPos = playerPos; }
    }
}
