﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA10_AppDev
{
    public partial class F1 : Form
    {
        MySqlConnection connection; // membantu untuk membuat connection ke dalam mysqlnya, menyimpan user my sql untuk connect
        MySqlCommand command; // menjalankan query yang kita tulis di database
        MySqlCommand command2;
        MySqlCommand command3;
        MySqlDataAdapter adapter; // menampung hasil dari query

        DataTable Players;
        DataTable Team;
        DataTable Nationality;
        public F1()
        {
            InitializeComponent();
        }
        int count;
        int rowke;
        private void F1_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=192.168.88.201;uid=student;pwd=isbmantap;database=premier_league;");
            connection.Open();
            connection.Close();

            string QueryPlayers = "select * from Player";
            command = new MySqlCommand(QueryPlayers, connection);
            Players = new DataTable();
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(Players);

            string QueryTeam = "select * from Team";
            command = new MySqlCommand(QueryTeam, connection);
            Team = new DataTable();
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(Team);

            string QueryNationality = "select * from Nationality";
            command = new MySqlCommand(QueryNationality, connection);
            Nationality = new DataTable();
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(Nationality);

            count = 0;
            row();

            foreach (DataRow row in Team.Rows)
            {
                cb_team.Items.Add(row["team_name"]);
            }

        }

        public void row()
        {
            rowke = 0;
            foreach (DataRow row in Players.Rows)
            {
                if (count == rowke)
                {
                    tb_playerID.Text = row["player_id"].ToString();
                    tb_playerName.Text = row["player_name"].ToString();
                    DateTime bday = Convert.ToDateTime(row["birthdate"]);
                    dtp_bday.Value = bday;
                    foreach (DataRow row2 in Nationality.Rows)
                    {
                        if (row["nationality_id"].ToString() == row2["nationality_id"].ToString())
                        {
                            tb_nationality.Text = row2["nation"].ToString();
                        }
                    }
                    cb_team.Text = row["team_id"].ToString();
                    nud_teamNumber.Value = Convert.ToInt16(row["team_number"]);
                }
                rowke++;
            }
        }

        private void bt_kirikiri_Click(object sender, EventArgs e)
        {
            count = 0;
            row();
        }

        private void bt_kiri_Click(object sender, EventArgs e)
        {
            if (count == 0)
            {

            }
            else
            {
                count--;
                row();
            }
        }

        private void bt_kanan_Click(object sender, EventArgs e)
        {
            if (count == Players.Rows.Count)
            {

            }
            else
            {
                count++;
                row();
            }
        }

        private void bt_kanankanan_Click(object sender, EventArgs e)
        {
            count = Players.Rows.Count;
            row();
        }
    }
}
