﻿namespace CA10_AppDev
{
    partial class F1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_kirikiri = new System.Windows.Forms.Button();
            this.lb_playerID = new System.Windows.Forms.Label();
            this.tb_playerID = new System.Windows.Forms.TextBox();
            this.bt_kiri = new System.Windows.Forms.Button();
            this.bt_kanankanan = new System.Windows.Forms.Button();
            this.bt_kanan = new System.Windows.Forms.Button();
            this.nud_teamNumber = new System.Windows.Forms.NumericUpDown();
            this.tb_playerName = new System.Windows.Forms.TextBox();
            this.lb_playerName = new System.Windows.Forms.Label();
            this.lb_bday = new System.Windows.Forms.Label();
            this.dtp_bday = new System.Windows.Forms.DateTimePicker();
            this.tb_nationality = new System.Windows.Forms.TextBox();
            this.lb_nationality = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.lb_teamNumber = new System.Windows.Forms.Label();
            this.bt_save = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nud_teamNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_kirikiri
            // 
            this.bt_kirikiri.Location = new System.Drawing.Point(541, 158);
            this.bt_kirikiri.Name = "bt_kirikiri";
            this.bt_kirikiri.Size = new System.Drawing.Size(152, 120);
            this.bt_kirikiri.TabIndex = 0;
            this.bt_kirikiri.Text = "<<";
            this.bt_kirikiri.UseVisualStyleBackColor = true;
            this.bt_kirikiri.Click += new System.EventHandler(this.bt_kirikiri_Click);
            // 
            // lb_playerID
            // 
            this.lb_playerID.AutoSize = true;
            this.lb_playerID.Location = new System.Drawing.Point(594, 345);
            this.lb_playerID.Name = "lb_playerID";
            this.lb_playerID.Size = new System.Drawing.Size(99, 25);
            this.lb_playerID.TabIndex = 1;
            this.lb_playerID.Text = "Player ID";
            // 
            // tb_playerID
            // 
            this.tb_playerID.Location = new System.Drawing.Point(717, 345);
            this.tb_playerID.Name = "tb_playerID";
            this.tb_playerID.Size = new System.Drawing.Size(242, 31);
            this.tb_playerID.TabIndex = 2;
            // 
            // bt_kiri
            // 
            this.bt_kiri.Location = new System.Drawing.Point(717, 158);
            this.bt_kiri.Name = "bt_kiri";
            this.bt_kiri.Size = new System.Drawing.Size(152, 120);
            this.bt_kiri.TabIndex = 3;
            this.bt_kiri.Text = "<";
            this.bt_kiri.UseVisualStyleBackColor = true;
            this.bt_kiri.Click += new System.EventHandler(this.bt_kiri_Click);
            // 
            // bt_kanankanan
            // 
            this.bt_kanankanan.Location = new System.Drawing.Point(1070, 158);
            this.bt_kanankanan.Name = "bt_kanankanan";
            this.bt_kanankanan.Size = new System.Drawing.Size(152, 120);
            this.bt_kanankanan.TabIndex = 5;
            this.bt_kanankanan.Text = ">>";
            this.bt_kanankanan.UseVisualStyleBackColor = true;
            this.bt_kanankanan.Click += new System.EventHandler(this.bt_kanankanan_Click);
            // 
            // bt_kanan
            // 
            this.bt_kanan.Location = new System.Drawing.Point(894, 158);
            this.bt_kanan.Name = "bt_kanan";
            this.bt_kanan.Size = new System.Drawing.Size(152, 120);
            this.bt_kanan.TabIndex = 4;
            this.bt_kanan.Text = ">";
            this.bt_kanan.UseVisualStyleBackColor = true;
            this.bt_kanan.Click += new System.EventHandler(this.bt_kanan_Click);
            // 
            // nud_teamNumber
            // 
            this.nud_teamNumber.Location = new System.Drawing.Point(717, 634);
            this.nud_teamNumber.Name = "nud_teamNumber";
            this.nud_teamNumber.Size = new System.Drawing.Size(242, 31);
            this.nud_teamNumber.TabIndex = 6;
            // 
            // tb_playerName
            // 
            this.tb_playerName.Location = new System.Drawing.Point(717, 401);
            this.tb_playerName.Name = "tb_playerName";
            this.tb_playerName.Size = new System.Drawing.Size(242, 31);
            this.tb_playerName.TabIndex = 8;
            // 
            // lb_playerName
            // 
            this.lb_playerName.AutoSize = true;
            this.lb_playerName.Location = new System.Drawing.Point(558, 401);
            this.lb_playerName.Name = "lb_playerName";
            this.lb_playerName.Size = new System.Drawing.Size(135, 25);
            this.lb_playerName.TabIndex = 7;
            this.lb_playerName.Text = "Player Name";
            // 
            // lb_bday
            // 
            this.lb_bday.AutoSize = true;
            this.lb_bday.Location = new System.Drawing.Point(594, 458);
            this.lb_bday.Name = "lb_bday";
            this.lb_bday.Size = new System.Drawing.Size(98, 25);
            this.lb_bday.TabIndex = 9;
            this.lb_bday.Text = "Birthdate";
            // 
            // dtp_bday
            // 
            this.dtp_bday.Location = new System.Drawing.Point(717, 458);
            this.dtp_bday.Name = "dtp_bday";
            this.dtp_bday.Size = new System.Drawing.Size(385, 31);
            this.dtp_bday.TabIndex = 10;
            // 
            // tb_nationality
            // 
            this.tb_nationality.Location = new System.Drawing.Point(717, 519);
            this.tb_nationality.Name = "tb_nationality";
            this.tb_nationality.Size = new System.Drawing.Size(242, 31);
            this.tb_nationality.TabIndex = 12;
            // 
            // lb_nationality
            // 
            this.lb_nationality.AutoSize = true;
            this.lb_nationality.Location = new System.Drawing.Point(580, 519);
            this.lb_nationality.Name = "lb_nationality";
            this.lb_nationality.Size = new System.Drawing.Size(113, 25);
            this.lb_nationality.TabIndex = 11;
            this.lb_nationality.Text = "Nationality";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(626, 579);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(66, 25);
            this.lb_team.TabIndex = 13;
            this.lb_team.Text = "Team";
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(717, 579);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(242, 33);
            this.cb_team.TabIndex = 14;
            // 
            // lb_teamNumber
            // 
            this.lb_teamNumber.AutoSize = true;
            this.lb_teamNumber.Location = new System.Drawing.Point(546, 634);
            this.lb_teamNumber.Name = "lb_teamNumber";
            this.lb_teamNumber.Size = new System.Drawing.Size(147, 25);
            this.lb_teamNumber.TabIndex = 15;
            this.lb_teamNumber.Text = "Team Number";
            // 
            // bt_save
            // 
            this.bt_save.Location = new System.Drawing.Point(806, 732);
            this.bt_save.Name = "bt_save";
            this.bt_save.Size = new System.Drawing.Size(183, 46);
            this.bt_save.TabIndex = 16;
            this.bt_save.Text = "Save";
            this.bt_save.UseVisualStyleBackColor = true;
            // 
            // F1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2987, 1246);
            this.Controls.Add(this.bt_save);
            this.Controls.Add(this.lb_teamNumber);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.tb_nationality);
            this.Controls.Add(this.lb_nationality);
            this.Controls.Add(this.dtp_bday);
            this.Controls.Add(this.lb_bday);
            this.Controls.Add(this.tb_playerName);
            this.Controls.Add(this.lb_playerName);
            this.Controls.Add(this.nud_teamNumber);
            this.Controls.Add(this.bt_kanankanan);
            this.Controls.Add(this.bt_kanan);
            this.Controls.Add(this.bt_kiri);
            this.Controls.Add(this.tb_playerID);
            this.Controls.Add(this.lb_playerID);
            this.Controls.Add(this.bt_kirikiri);
            this.Name = "F1";
            this.Text = "CA10";
            this.Load += new System.EventHandler(this.F1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud_teamNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_kirikiri;
        private System.Windows.Forms.Label lb_playerID;
        private System.Windows.Forms.TextBox tb_playerID;
        private System.Windows.Forms.Button bt_kiri;
        private System.Windows.Forms.Button bt_kanankanan;
        private System.Windows.Forms.Button bt_kanan;
        private System.Windows.Forms.NumericUpDown nud_teamNumber;
        private System.Windows.Forms.TextBox tb_playerName;
        private System.Windows.Forms.Label lb_playerName;
        private System.Windows.Forms.Label lb_bday;
        private System.Windows.Forms.DateTimePicker dtp_bday;
        private System.Windows.Forms.TextBox tb_nationality;
        private System.Windows.Forms.Label lb_nationality;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Label lb_teamNumber;
        private System.Windows.Forms.Button bt_save;
    }
}

