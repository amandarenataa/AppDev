﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA_week_12
{
    public partial class F1 : Form
    {
        public F1()
        {
            InitializeComponent();
        }
        MySqlCommand cmd;
        MySqlConnection conn;
        MySqlDataAdapter adapter;
        DataTable data;
        
        private void F1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league;");
            conn.Open();
            conn.Close();

            // no 1
            //string query = "select team.team_name as 'Nama Team', count(dmatch.type) as 'Jumlah Goal' from team join dmatch on dmatch.team_id = team.team_id where dmatch.type = 'GO' group by 1 order by 2 desc;";

            // no 2
            //string query = "select team.team_name as 'Nama Team', count(dmatch.type) as 'Goal Penalty' from team join dmatch on dmatch.team_id = team.team_id where dmatch.type = 'GP' group by 1 order by 2 desc;";

            // no 3
            //string query = "select dmatch.minute as 'Minute', count(dmatch.type) as 'Jumlah Gol' from team left join dmatch on dmatch.team_id = team.team_id where dmatch.type = 'GO' or dmatch.type = 'GP' group by 1 order by 2 desc;";

            // no 4
            //string query = "select nationality.nation as 'Nationality', count(player.nationality_id) as 'Jumlah Pemain' from nationality join player on nationality.nationality_id = player.nationality_id group by 1 having count(player.nationality_id) < 4 order by 2 desc;";

            // no 5
            string query = "select player.player_name as 'Nama Pemain', count(dmatch.player_id) as 'Jumlah Gol' from player join dmatch on dmatch.player_id = player.player_id  where dmatch.type = 'GO' and player.team_number < 6 group by 1  order by 2 desc;";
            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);

            data = new DataTable();
            adapter.Fill(data);

            dgv_data.DataSource = data;

        }
    }
}
