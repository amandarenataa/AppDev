﻿namespace CA_Week_6
{
    partial class CA_06
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_input = new System.Windows.Forms.Panel();
            this.lb_input = new System.Windows.Forms.Label();
            this.tx_input = new System.Windows.Forms.TextBox();
            this.lb_katakata = new System.Windows.Forms.Label();
            this.bt_inputDone = new System.Windows.Forms.Button();
            this.p_Score = new System.Windows.Forms.Panel();
            this.lb_Blue = new System.Windows.Forms.Label();
            this.lb_Red = new System.Windows.Forms.Label();
            this.lb_scoreB = new System.Windows.Forms.Label();
            this.lb_scoreR = new System.Windows.Forms.Label();
            this.panel_input.SuspendLayout();
            this.p_Score.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_input
            // 
            this.panel_input.Controls.Add(this.bt_inputDone);
            this.panel_input.Controls.Add(this.lb_katakata);
            this.panel_input.Controls.Add(this.tx_input);
            this.panel_input.Controls.Add(this.lb_input);
            this.panel_input.Location = new System.Drawing.Point(47, 93);
            this.panel_input.Name = "panel_input";
            this.panel_input.Size = new System.Drawing.Size(1298, 647);
            this.panel_input.TabIndex = 0;
            // 
            // lb_input
            // 
            this.lb_input.AutoSize = true;
            this.lb_input.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_input.Location = new System.Drawing.Point(374, 297);
            this.lb_input.Name = "lb_input";
            this.lb_input.Size = new System.Drawing.Size(92, 31);
            this.lb_input.TabIndex = 0;
            this.lb_input.Text = "Input : ";
            // 
            // tx_input
            // 
            this.tx_input.Location = new System.Drawing.Point(484, 298);
            this.tx_input.Name = "tx_input";
            this.tx_input.Size = new System.Drawing.Size(331, 31);
            this.tx_input.TabIndex = 1;
            this.tx_input.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tx_input_KeyPress);
            // 
            // lb_katakata
            // 
            this.lb_katakata.AutoSize = true;
            this.lb_katakata.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_katakata.Location = new System.Drawing.Point(269, 196);
            this.lb_katakata.Name = "lb_katakata";
            this.lb_katakata.Size = new System.Drawing.Size(687, 31);
            this.lb_katakata.TabIndex = 2;
            this.lb_katakata.Text = "INPUT KAMU MAU ANGKA BRP UNTUK UKURAN BOX";
            // 
            // bt_inputDone
            // 
            this.bt_inputDone.Location = new System.Drawing.Point(552, 373);
            this.bt_inputDone.Name = "bt_inputDone";
            this.bt_inputDone.Size = new System.Drawing.Size(169, 57);
            this.bt_inputDone.TabIndex = 3;
            this.bt_inputDone.Text = "Done";
            this.bt_inputDone.UseVisualStyleBackColor = true;
            this.bt_inputDone.Click += new System.EventHandler(this.bt_inputDone_Click);
            // 
            // p_Score
            // 
            this.p_Score.Controls.Add(this.lb_scoreR);
            this.p_Score.Controls.Add(this.lb_scoreB);
            this.p_Score.Controls.Add(this.lb_Red);
            this.p_Score.Controls.Add(this.lb_Blue);
            this.p_Score.Location = new System.Drawing.Point(924, 90);
            this.p_Score.Name = "p_Score";
            this.p_Score.Size = new System.Drawing.Size(541, 347);
            this.p_Score.TabIndex = 1;
            // 
            // lb_Blue
            // 
            this.lb_Blue.AutoSize = true;
            this.lb_Blue.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Blue.Location = new System.Drawing.Point(106, 91);
            this.lb_Blue.Name = "lb_Blue";
            this.lb_Blue.Size = new System.Drawing.Size(66, 31);
            this.lb_Blue.TabIndex = 0;
            this.lb_Blue.Text = "Blue";
            // 
            // lb_Red
            // 
            this.lb_Red.AutoSize = true;
            this.lb_Red.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Red.Location = new System.Drawing.Point(354, 91);
            this.lb_Red.Name = "lb_Red";
            this.lb_Red.Size = new System.Drawing.Size(58, 31);
            this.lb_Red.TabIndex = 1;
            this.lb_Red.Text = "Red";
            // 
            // lb_scoreB
            // 
            this.lb_scoreB.AutoSize = true;
            this.lb_scoreB.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_scoreB.Location = new System.Drawing.Point(125, 219);
            this.lb_scoreB.Name = "lb_scoreB";
            this.lb_scoreB.Size = new System.Drawing.Size(28, 31);
            this.lb_scoreB.TabIndex = 2;
            this.lb_scoreB.Text = "0";
            // 
            // lb_scoreR
            // 
            this.lb_scoreR.AutoSize = true;
            this.lb_scoreR.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_scoreR.Location = new System.Drawing.Point(367, 219);
            this.lb_scoreR.Name = "lb_scoreR";
            this.lb_scoreR.Size = new System.Drawing.Size(28, 31);
            this.lb_scoreR.TabIndex = 3;
            this.lb_scoreR.Text = "0";
            // 
            // CA_06
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1685, 879);
            this.Controls.Add(this.p_Score);
            this.Controls.Add(this.panel_input);
            this.Name = "CA_06";
            this.Text = "CA06";
            this.Load += new System.EventHandler(this.CA_06_Load);
            this.panel_input.ResumeLayout(false);
            this.panel_input.PerformLayout();
            this.p_Score.ResumeLayout(false);
            this.p_Score.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_input;
        private System.Windows.Forms.Label lb_katakata;
        private System.Windows.Forms.TextBox tx_input;
        private System.Windows.Forms.Label lb_input;
        private System.Windows.Forms.Button bt_inputDone;
        private System.Windows.Forms.Panel p_Score;
        private System.Windows.Forms.Label lb_scoreR;
        private System.Windows.Forms.Label lb_scoreB;
        private System.Windows.Forms.Label lb_Red;
        private System.Windows.Forms.Label lb_Blue;
    }
}

