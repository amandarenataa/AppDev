﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Week_6
{
    public partial class CA_06 : Form
    {
        private int N;
        List<Button> buttons;
        string[,] buttonsKu;
        public Button button;
        public int brpKali;
        public int ScoreR;
        public int ScoreB;
        public CA_06()
        {
            InitializeComponent();
        }

        private void CA_06_Load(object sender, EventArgs e)
        {
            panel_input.Visible = true;
            p_Score.Visible = false;
        }

        private void bt_inputDone_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tx_input.Text) < 2 || Convert.ToInt32(tx_input.Text) % 2 == 0 || Convert.ToInt32(tx_input.Text) > 9)
            {
                MessageBox.Show("Error ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tx_input.Clear();
            }
            else
            {
                /*
                N = Convert.ToInt32(tx_input.Text);
                panel_input.Visible = false;
                p_Score.Visible = true;
                buttons = new List<Button>();
                int locationX = 50;
                int locationY = 50;
                buttonsKu = new string[N, N];
                for (int i = 0; i < N; i++)
                {
                    for (int j = 0; j < N; j++)
                    {
                        button = new Button();
                        button.Size = new Size(50, 50);
                        button.Location = new Point(locationX, locationY);
                        button.Tag = $"{i},{j}";
                        button.Click += new EventHandler(ClickButton);
                        buttons.Add(button);
                        locationX += 50;
                        buttonsKu[i, j] = "N";
                    }
                    locationY += 50;
                    locationX = 50;
                }
                foreach (Button button in buttons)
                {
                    this.Controls.Add(button);
                }
                */
                N = Convert.ToInt32(tx_input.Text);
                panel_input.Visible = false;
                p_Score.Visible = true;
                buttons = new List<Button>();
                int locationX = 50;
                int locationY = 50;
                int counter = 1;
                for (int i = 0; i < N; i++)
                {
                    for (int j = 0; j < N; j++)
                    {
                        button = new Button();
                        button.Size = new Size(50, 50);
                        button.Location = new Point(locationX, locationY);
                        button.Tag = counter.ToString();
                        button.Click += new EventHandler(ClickButton);
                        buttons.Add(button);
                        locationX += 50;
                        counter++;
                    }
                    locationY += 50;
                    locationX = 50;
                }
                foreach (Button button in buttons)
                {
                    this.Controls.Add(button);
                }
            }
        }
        public void ClickButton(object sender, EventArgs e)
        {
            /*
            Button click = (Button)sender;
            brpKali++;
            if (brpKali % 2  == 1)
            {
                click.BackColor = Color.Red;
                int i = Convert.ToInt16(button.Tag.ToString().Substring(0,1));
                int j = Convert.ToInt16(button.Tag.ToString().Substring(2,1));
                buttonsKu[i,j] = "R";
                if (buttonsKu[i - 1, j] == "B")
                {
                    buttonsKu[i- 1, j] = "R";
                    click.BackColor = Color.Red;
                }
                if (buttonsKu[i, j - 1] == "B")
                {
                    buttonsKu[i, j- 1] = "R";
                    click.BackColor = Color.Red;
                }
                if (buttonsKu[i + 1, j] == "B")
                {
                    buttonsKu[i+1, j] = "R";
                    click.BackColor = Color.Red;
                }
                if (buttonsKu[i , j + 1] == "B")
                {
                    buttonsKu[i, j+1] = "R";
                    click.BackColor = Color.Red;
                }

            }
            else
            {
                click.BackColor = Color.Blue; 
                int i = Convert.ToInt16(button.Tag.ToString().Substring(0, 1));
                int j = Convert.ToInt16(button.Tag.ToString().Substring(2, 1));
                buttonsKu[i, j] = "B";
            }

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (buttonsKu[i, j] == "R")
                    {
                        ScoreR++;
                    }
                    else if (buttonsKu[i, j] == "B")
                    {
                        ScoreB++;
                    }
                }
            }
            lb_scoreB.Text = ScoreB.ToString();
            lb_scoreR.Text = ScoreR.ToString();
            */

            int scoreR = 0; int scoreB = 0;

            Button btn = (Button)sender;

            if (btn.BackColor == Color.Red)
            {
                btn.BackColor = Color.Blue;
            }
            else if (btn.BackColor == Color.Blue)
            {
                btn.BackColor = Color.Red;
            }
            else 
            { 
                btn.BackColor = Color.Red; 
            }

            int cek1 = Convert.ToInt32(btn.Tag) - 1;
            int cek2 = Convert.ToInt32(btn.Tag) + 1;
            int cek3 = Convert.ToInt32(btn.Tag) - N;
            int cek4 = Convert.ToInt32(btn.Tag) + N;

            foreach (Button btns in buttons)
            {
                if (Convert.ToInt32(btn.Tag)%N == 0)
                {
                    cek2 = 0;
                }
                if (Convert.ToInt32(btn.Tag)%N == 1)
                {
                    cek1 = 0;
                }
                if (btns.Tag.ToString() == cek1.ToString() || btns.Tag.ToString() == cek2.ToString() || btns.Tag.ToString() == cek3.ToString() || btns.Tag.ToString() == cek4.ToString())
                {
                    if (btns.BackColor == Color.Red)
                    {
                        btns.BackColor = Color.Blue;
                    }
                    else if (btns.BackColor == Color.Blue)
                    {
                        btns.BackColor= Color.Red;
                    }
                }
            }

            foreach (Button btns in buttons)
            {
                if (btns.BackColor == Color.Red)
                {
                    scoreR++;
                }
                else if (btns.BackColor == Color.Blue)
                {
                    scoreB++;
                }
            }
            lb_scoreB.Text = scoreB.ToString();
            lb_scoreR.Text = scoreR.ToString();

            if (scoreB == (N*N))
            {
                MessageBox.Show("Blue Won");
            }
            else if (scoreR == (N*N))
            {
                MessageBox.Show("Red Won");
            }
        }

        private void tx_input_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
        }
    }
}
