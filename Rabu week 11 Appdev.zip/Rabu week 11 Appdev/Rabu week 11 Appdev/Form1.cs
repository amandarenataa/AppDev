﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Rabu_week_11_Appdev
{
    public partial class F1 : Form
    {
        public F1()
        {
            InitializeComponent();
        }
        MySqlConnection connection;
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable Data;
        private void F1_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            connection.Open();
            connection.Close();

            //select match.match_id, match.match_date, team.team_name as 'Team Home', t2.team_name as 'Team Away' from `match` join team on match.team_home = team.team_id join team t2 on match.team_away = t2.team_id
            string query = "select team.team_id, team.team_name, team.home_stadium, team.capacity, team.city, manager.manager_name as manager_name, m2.manager_name as assistant_manager_name, player.player_name as captain_name from team join manager on manager.manager_id = team.manager_id join manager m2 on m2.manager_id = team.assmanager_id join player on player.player_id = team.captain_id";
            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);
            Data = new DataTable(); 
            adapter.Fill(Data);
            dgv_data.DataSource = Data;
            
        }
    }
}
