﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minesweeper
{
    public partial class F1 : Form
    {
        List<Button> buttons;
        public Button btn2;
        public F1()
        {
            InitializeComponent();
        }
        Random random = new Random();
        List<string> boms = new List<string>();
        private void F1_Load(object sender, EventArgs e)
        {
            int locationY = 50;
            int locationX = 50;
            buttons = new List<Button>();
            int bom = 0;
            int count = 10;
            for (int i =  1; i < 11; i++ )// untuk bomnya dirandomdi button apa
            {
                bom = random.Next(10, 80);                
                boms.Add(bom.ToString());
            }
            for (int j = 1; j < 9; j++) // untuk ngeprint buttonnya
            {
                for (int i = 1; i < 11; i++)
                {
                    btn2 = new Button();
                    btn2.Text = $"{count}";
                    btn2.Tag =  $"{count}" ;
                    btn2.Size = new Size(50, 50);
                    btn2.Location = new Point(locationX, locationY);
                    locationX += 50;
                    btn2.BackColor = Color.LightGreen;
                    btn2.ForeColor = Color.Green;
                    buttons.Add(btn2);
                    this.Controls.Add(btn2);
                    count++;
                }
                locationX = 50;
                locationY += 60;
            }
            foreach (Button button in buttons) //untuk button bisa diclick
            {
                button.Click += new EventHandler(btnClick);
            }
            int bawah = 0;
            int atas = 0;
            int kanan = 0;
            int kiri = 0;
            foreach (string b in boms)
            {
                int bo = Convert.ToInt32(b);
                if (bo < 19 && bo > 11)
                {
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    kanan = Convert.ToInt32(bo + 1); 
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 11)
                {
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 19 )
                {
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());

                }
                else if (bo < 29 && bo > 21)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 21)
                { 
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 29)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());

                }
                else if (bo < 39 && bo > 31)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 31)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 39)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());

                }
                else if (bo < 49 && bo > 41)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 41)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 49)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());

                }
                else if (bo < 59 && bo > 51)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 51)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 59)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());

                }
                else if (bo < 69 && bo > 61)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 61)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 69)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                }
                else if (bo < 79 && bo > 71)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 71)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 79)
                {
                    atas = Convert.ToInt32(bo - 10);
                    bawah = Convert.ToInt32(bo + 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(bawah.ToString());
                    deketBom.Add(kiri.ToString());

                }
                else if (bo < 89 && bo > 80)
                {
                    atas = Convert.ToInt32(bo - 10);
                    kanan = Convert.ToInt32(bo + 1);
                    kiri = Convert.ToInt32(bo - 1); 
                    deketBom.Add(atas.ToString());
                    deketBom.Add(kiri.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 80)
                {
                    atas = Convert.ToInt32(bo - 10);
                    kanan = Convert.ToInt32(bo + 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(kanan.ToString());

                }
                else if (bo == 89)
                {
                    atas = Convert.ToInt32(bo - 10);
                    kiri = Convert.ToInt32(bo - 1);
                    deketBom.Add(atas.ToString());
                    deketBom.Add(kiri.ToString());
                }
            }
        }
        List<string> deketBom = new List<string>();
        public void btnClick(object sender, EventArgs e) // nich yang muncul
        {
            Button sebuahbutton = (Button)sender;
            if (boms.Contains(sebuahbutton.Tag))
            {
                MessageBox.Show("YOU LOST");
            }
            else
            {
                sebuahbutton.BackColor = Color.Beige;
                sebuahbutton.Text = "";
                foreach (Button button in buttons)
                {
                    if (deketBom.Contains(button.Tag.ToString()))
                    {
                        button.Text = "1";
                        button.BackColor = Color.Beige;
                    }
                    else if (!boms.Contains(button.Tag.ToString()))
                    {
                        button.Text = "";
                        button.BackColor = Color.Beige;
                    }
                    else
                    {
                        button.BackColor = Color.Red;
                    }
                }
            }
        }
    }
}
