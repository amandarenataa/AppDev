﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_6_Rabu
{
    public partial class Form2 : Form
    {
        public string balasan;
        Form1 form1; // buat kirim ke form 1
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(Form _sender) // buat kirim ke form 1
        {
           InitializeComponent();
            form1 = (Form1)_sender;
        }
        
        private void bt_check_Click(object sender, EventArgs e)
        {
            MessageBox.Show(balasan);
        }
        public void setLabel (string _text) // nerima dari form 1
        {
            lb_fromF1.Text = _text;
            balasan = _text;
        }
        private void bt_random_Click(object sender, EventArgs e) 
        {
            Random random = new Random();
            int angka = random.Next(1,50);
            form1.setAngkaRandom(angka);
        }
        private void bt_add_Click(object sender, EventArgs e)
        {
            string id = tb_ID.Text;
            string nama = tb_nama.Text;
            string harga = tb_harga.Text;
            form1.AddProduct(id, nama, harga);
            tb_harga.Clear();
            tb_ID.Clear();
            tb_nama.Clear();
            this.Close();
        }
    }
}
