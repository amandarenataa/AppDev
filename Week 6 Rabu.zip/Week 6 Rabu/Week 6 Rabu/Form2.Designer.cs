﻿namespace Week_6_Rabu
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_check = new System.Windows.Forms.Button();
            this.lb_fromF1 = new System.Windows.Forms.Label();
            this.bt_random = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.bt_add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_check
            // 
            this.bt_check.Location = new System.Drawing.Point(92, 242);
            this.bt_check.Name = "bt_check";
            this.bt_check.Size = new System.Drawing.Size(537, 286);
            this.bt_check.TabIndex = 2;
            this.bt_check.Text = "Check";
            this.bt_check.UseVisualStyleBackColor = true;
            this.bt_check.Click += new System.EventHandler(this.bt_check_Click);
            // 
            // lb_fromF1
            // 
            this.lb_fromF1.AutoSize = true;
            this.lb_fromF1.Location = new System.Drawing.Point(219, 79);
            this.lb_fromF1.Name = "lb_fromF1";
            this.lb_fromF1.Size = new System.Drawing.Size(46, 25);
            this.lb_fromF1.TabIndex = 3;
            this.lb_fromF1.Text = "HAI";
            // 
            // bt_random
            // 
            this.bt_random.Location = new System.Drawing.Point(427, 79);
            this.bt_random.Name = "bt_random";
            this.bt_random.Size = new System.Drawing.Size(202, 94);
            this.bt_random.TabIndex = 4;
            this.bt_random.Text = "Random";
            this.bt_random.UseVisualStyleBackColor = true;
            this.bt_random.Click += new System.EventHandler(this.bt_random_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1354, 328);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "ID Produk:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1318, 373);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nama Produk:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1390, 420);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Harga:";
            // 
            // tb_ID
            // 
            this.tb_ID.Location = new System.Drawing.Point(1472, 325);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(178, 31);
            this.tb_ID.TabIndex = 8;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(1472, 420);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(178, 31);
            this.tb_harga.TabIndex = 9;
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(1472, 373);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(178, 31);
            this.tb_nama.TabIndex = 10;
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(1472, 489);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(115, 63);
            this.bt_add.TabIndex = 11;
            this.bt_add.Text = "Add";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2925, 1593);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_ID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_random);
            this.Controls.Add(this.lb_fromF1);
            this.Controls.Add(this.bt_check);
            this.Name = "Form2";
            this.Text = "v";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bt_check;
        private System.Windows.Forms.Label lb_fromF1;
        private System.Windows.Forms.Button bt_random;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_ID;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.Button bt_add;
    }
}