﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_6_Rabu
{
    public partial class Form3 : Form
    {
        DataTable dt3;
        Form1 form1;
        public Form3()
        {
            InitializeComponent();
        }
        public Form3 (Form _sender)
        {
            InitializeComponent();
            form1 = (Form1) _sender;
        }
        public void datatable(DataTable _form1)
        {
            dt3 = _form1;
            foreach (DataRow row in dt3.Rows)
            {
                if (!cb_produk.Items.Contains(row["Nama"].ToString()))
                {
                    cb_produk.Items.Add(row["Nama"].ToString());
                }
            }
        }
        public int index;
        private void cb_produk_SelectedIndexChanged(object sender, EventArgs e)
        {
            index = cb_produk.SelectedIndex;
            int count = 0;
            foreach (DataRow row in dt3.Rows)
            {
                if (count == index)
                {
                    tb_ID.Text = row["ID"].ToString();
                    tb_harga.Text = row["Harga"].ToString();
                }
                count++;
            }
        }

        private void bt_remove_Click(object sender, EventArgs e)
        {
            form1.RemoveProduct(index);
            tb_harga.Clear();
            tb_ID.Clear();
            cb_produk.SelectedItem = null;
            this.Close();
        }
    }
}
