﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_6_Rabu
{
    public partial class Form1 : Form
    {
        Form2 form2; // buat form 2
        Form3 form3;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }
        private void bt_sendtoF2_Click(object sender, EventArgs e )// kasih ke form 2
        {
            form2.setLabel(tb_sendtoF2.Text);
            tb_sendtoF2.Clear();
        }
        public void setAngkaRandom(int _angka)
        {
            lb_angkaRandom.Text = "Angka Random: " + _angka;
        }
        private void bt_openform2_Click(object sender, EventArgs e)
        {
            form2 = new Form2(this);
            //form.ShowDialog(); //form pertama g bisa dipindah" ( jadi form pertama di pause dulu )
            form2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Nama");
            dt.Columns.Add("Harga");
            dt.Rows.Add("001", "Nasi", "10000");
            dt.Rows.Add("002", "Mie", "20000");
            dt.Rows.Add("003", "Pasta", "30000");
            dgv_makanan.DataSource = dt;
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            form2 = new Form2(this);
            form2.Show();
        }
        public void AddProduct(string _id, string _nama, string _harga)
        {
            dt.Rows.Add(_id, _nama, _harga);
        }

        private void bt_remove_Click(object sender, EventArgs e)
        {
            form3 = new Form3(this);
            form3.Show();
            form3.datatable(dt);
        }
        public void RemoveProduct(int _index)
        {
            dt.Rows.RemoveAt(_index);
        }
    }
}
