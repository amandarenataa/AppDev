﻿namespace Week_6_Rabu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_openform2 = new System.Windows.Forms.Button();
            this.tb_sendtoF2 = new System.Windows.Forms.TextBox();
            this.bt_sendtoF2 = new System.Windows.Forms.Button();
            this.lb_angkaRandom = new System.Windows.Forms.Label();
            this.dgv_makanan = new System.Windows.Forms.DataGridView();
            this.bt_add = new System.Windows.Forms.Button();
            this.bt_remove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_makanan)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_openform2
            // 
            this.bt_openform2.Location = new System.Drawing.Point(48, 88);
            this.bt_openform2.Name = "bt_openform2";
            this.bt_openform2.Size = new System.Drawing.Size(250, 128);
            this.bt_openform2.TabIndex = 0;
            this.bt_openform2.Text = "Open";
            this.bt_openform2.UseVisualStyleBackColor = true;
            this.bt_openform2.Click += new System.EventHandler(this.bt_openform2_Click);
            // 
            // tb_sendtoF2
            // 
            this.tb_sendtoF2.Location = new System.Drawing.Point(683, 185);
            this.tb_sendtoF2.Name = "tb_sendtoF2";
            this.tb_sendtoF2.Size = new System.Drawing.Size(225, 31);
            this.tb_sendtoF2.TabIndex = 1;
            // 
            // bt_sendtoF2
            // 
            this.bt_sendtoF2.Location = new System.Drawing.Point(736, 232);
            this.bt_sendtoF2.Name = "bt_sendtoF2";
            this.bt_sendtoF2.Size = new System.Drawing.Size(110, 50);
            this.bt_sendtoF2.TabIndex = 2;
            this.bt_sendtoF2.Text = "Send";
            this.bt_sendtoF2.UseVisualStyleBackColor = true;
            this.bt_sendtoF2.Click += new System.EventHandler(this.bt_sendtoF2_Click);
            // 
            // lb_angkaRandom
            // 
            this.lb_angkaRandom.AutoSize = true;
            this.lb_angkaRandom.Location = new System.Drawing.Point(137, 366);
            this.lb_angkaRandom.Name = "lb_angkaRandom";
            this.lb_angkaRandom.Size = new System.Drawing.Size(159, 25);
            this.lb_angkaRandom.TabIndex = 3;
            this.lb_angkaRandom.Text = "Angka Random";
            // 
            // dgv_makanan
            // 
            this.dgv_makanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_makanan.Location = new System.Drawing.Point(1345, 353);
            this.dgv_makanan.Name = "dgv_makanan";
            this.dgv_makanan.RowHeadersWidth = 82;
            this.dgv_makanan.RowTemplate.Height = 33;
            this.dgv_makanan.Size = new System.Drawing.Size(1025, 371);
            this.dgv_makanan.TabIndex = 4;
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(1345, 753);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(163, 56);
            this.bt_add.TabIndex = 5;
            this.bt_add.Text = "Add";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // bt_remove
            // 
            this.bt_remove.Location = new System.Drawing.Point(1543, 753);
            this.bt_remove.Name = "bt_remove";
            this.bt_remove.Size = new System.Drawing.Size(163, 56);
            this.bt_remove.TabIndex = 6;
            this.bt_remove.Text = "Remove";
            this.bt_remove.UseVisualStyleBackColor = true;
            this.bt_remove.Click += new System.EventHandler(this.bt_remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(3126, 1539);
            this.Controls.Add(this.bt_remove);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.dgv_makanan);
            this.Controls.Add(this.lb_angkaRandom);
            this.Controls.Add(this.bt_sendtoF2);
            this.Controls.Add(this.tb_sendtoF2);
            this.Controls.Add(this.bt_openform2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_makanan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_openform2;
        private System.Windows.Forms.TextBox tb_sendtoF2;
        private System.Windows.Forms.Button bt_sendtoF2;
        private System.Windows.Forms.Label lb_angkaRandom;
        private System.Windows.Forms.DataGridView dgv_makanan;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.Button bt_remove;
    }
}

