﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_total = new System.Windows.Forms.Button();
            this.btn_bye = new System.Windows.Forms.Button();
            this.tbox_angka1 = new System.Windows.Forms.TextBox();
            this.tbox_angka2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_total
            // 
            this.btn_total.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_total.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_total.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_total.Location = new System.Drawing.Point(143, 148);
            this.btn_total.Name = "btn_total";
            this.btn_total.Size = new System.Drawing.Size(136, 67);
            this.btn_total.TabIndex = 0;
            this.btn_total.Text = "Cek";
            this.btn_total.UseVisualStyleBackColor = false;
            this.btn_total.Click += new System.EventHandler(this.btn_total_Click_1);
            // 
            // btn_bye
            // 
            this.btn_bye.Location = new System.Drawing.Point(509, 119);
            this.btn_bye.Name = "btn_bye";
            this.btn_bye.Size = new System.Drawing.Size(75, 23);
            this.btn_bye.TabIndex = 1;
            this.btn_bye.Text = "bye";
            this.btn_bye.UseVisualStyleBackColor = true;
            this.btn_bye.Click += new System.EventHandler(this.btn_bye_Click);
            // 
            // tbox_angka1
            // 
            this.tbox_angka1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tbox_angka1.Location = new System.Drawing.Point(154, 119);
            this.tbox_angka1.Name = "tbox_angka1";
            this.tbox_angka1.Size = new System.Drawing.Size(110, 20);
            this.tbox_angka1.TabIndex = 2;
            this.tbox_angka1.TextChanged += new System.EventHandler(this.tbox_angka1_TextChanged);
            // 
            // tbox_angka2
            // 
            this.tbox_angka2.Location = new System.Drawing.Point(465, 172);
            this.tbox_angka2.Name = "tbox_angka2";
            this.tbox_angka2.Size = new System.Drawing.Size(110, 20);
            this.tbox_angka2.TabIndex = 3;
            this.tbox_angka2.TextChanged += new System.EventHandler(this.tbox_angka2_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tbox_angka2);
            this.Controls.Add(this.tbox_angka1);
            this.Controls.Add(this.btn_bye);
            this.Controls.Add(this.btn_total);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_total;
        private System.Windows.Forms.Button btn_bye;
        private System.Windows.Forms.TextBox tbox_angka1;
        private System.Windows.Forms.TextBox tbox_angka2;
    }
}

