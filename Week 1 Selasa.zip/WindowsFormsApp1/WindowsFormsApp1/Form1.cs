﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tbox_angka1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void tbox_angka2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_bye_Click(object sender, EventArgs e)
        {

        }

        private void btn_total_Click_1(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(tbox_angka1.Text);

            if (num > 0)
            {
                int cek = 0;
                for (int i = 1; i <= num; i++)
                {
                    if (num % i == 0)
                    {
                        cek++;
                    }
                }
                if (cek == 2)
                {
                    MessageBox.Show("Angka Prima");
                }
                else
                {
                    MessageBox.Show("Angka Bukan Prima");
                }
            }
        }
    }
}
