﻿namespace CA_Appdev_week_4
{
    partial class bt_nama1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_nama1 = new System.Windows.Forms.Label();
            this.tb_nama1 = new System.Windows.Forms.TextBox();
            this.bt_input1 = new System.Windows.Forms.Button();
            this.list_nama1 = new System.Windows.Forms.ListBox();
            this.bt_clear1 = new System.Windows.Forms.Button();
            this.bt_clear2 = new System.Windows.Forms.Button();
            this.list_nama2 = new System.Windows.Forms.ListBox();
            this.bt_input2 = new System.Windows.Forms.Button();
            this.tb_nama2 = new System.Windows.Forms.TextBox();
            this.lb_nama2 = new System.Windows.Forms.Label();
            this.bt_Spindahkanan = new System.Windows.Forms.Button();
            this.bt_pindahkanan = new System.Windows.Forms.Button();
            this.bt_Spindahkiri = new System.Windows.Forms.Button();
            this.bt_pindahkiri = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_nama1
            // 
            this.lb_nama1.AutoSize = true;
            this.lb_nama1.Location = new System.Drawing.Point(217, 92);
            this.lb_nama1.Name = "lb_nama1";
            this.lb_nama1.Size = new System.Drawing.Size(68, 25);
            this.lb_nama1.TabIndex = 0;
            this.lb_nama1.Text = "Nama";
            // 
            // tb_nama1
            // 
            this.tb_nama1.Location = new System.Drawing.Point(169, 120);
            this.tb_nama1.Name = "tb_nama1";
            this.tb_nama1.Size = new System.Drawing.Size(169, 31);
            this.tb_nama1.TabIndex = 1;
            // 
            // bt_input1
            // 
            this.bt_input1.Location = new System.Drawing.Point(197, 168);
            this.bt_input1.Name = "bt_input1";
            this.bt_input1.Size = new System.Drawing.Size(112, 42);
            this.bt_input1.TabIndex = 2;
            this.bt_input1.Text = "Input";
            this.bt_input1.UseVisualStyleBackColor = true;
            this.bt_input1.Click += new System.EventHandler(this.bt_input1_Click);
            // 
            // list_nama1
            // 
            this.list_nama1.FormattingEnabled = true;
            this.list_nama1.ItemHeight = 25;
            this.list_nama1.Location = new System.Drawing.Point(169, 231);
            this.list_nama1.Name = "list_nama1";
            this.list_nama1.Size = new System.Drawing.Size(179, 204);
            this.list_nama1.TabIndex = 3;
            // 
            // bt_clear1
            // 
            this.bt_clear1.Location = new System.Drawing.Point(252, 467);
            this.bt_clear1.Name = "bt_clear1";
            this.bt_clear1.Size = new System.Drawing.Size(96, 39);
            this.bt_clear1.TabIndex = 4;
            this.bt_clear1.Text = "Clear";
            this.bt_clear1.UseVisualStyleBackColor = true;
            this.bt_clear1.Click += new System.EventHandler(this.bt_clear1_Click);
            // 
            // bt_clear2
            // 
            this.bt_clear2.Location = new System.Drawing.Point(588, 467);
            this.bt_clear2.Name = "bt_clear2";
            this.bt_clear2.Size = new System.Drawing.Size(96, 39);
            this.bt_clear2.TabIndex = 9;
            this.bt_clear2.Text = "Clear";
            this.bt_clear2.UseVisualStyleBackColor = true;
            this.bt_clear2.Click += new System.EventHandler(this.bt_clear2_Click);
            // 
            // list_nama2
            // 
            this.list_nama2.FormattingEnabled = true;
            this.list_nama2.ItemHeight = 25;
            this.list_nama2.Location = new System.Drawing.Point(505, 231);
            this.list_nama2.Name = "list_nama2";
            this.list_nama2.Size = new System.Drawing.Size(179, 204);
            this.list_nama2.TabIndex = 8;
            // 
            // bt_input2
            // 
            this.bt_input2.Location = new System.Drawing.Point(533, 168);
            this.bt_input2.Name = "bt_input2";
            this.bt_input2.Size = new System.Drawing.Size(112, 42);
            this.bt_input2.TabIndex = 7;
            this.bt_input2.Text = "Input";
            this.bt_input2.UseVisualStyleBackColor = true;
            this.bt_input2.Click += new System.EventHandler(this.bt_input2_Click);
            // 
            // tb_nama2
            // 
            this.tb_nama2.Location = new System.Drawing.Point(505, 120);
            this.tb_nama2.Name = "tb_nama2";
            this.tb_nama2.Size = new System.Drawing.Size(169, 31);
            this.tb_nama2.TabIndex = 6;
            // 
            // lb_nama2
            // 
            this.lb_nama2.AutoSize = true;
            this.lb_nama2.Location = new System.Drawing.Point(553, 92);
            this.lb_nama2.Name = "lb_nama2";
            this.lb_nama2.Size = new System.Drawing.Size(68, 25);
            this.lb_nama2.TabIndex = 5;
            this.lb_nama2.Text = "Nama";
            // 
            // bt_Spindahkanan
            // 
            this.bt_Spindahkanan.Location = new System.Drawing.Point(381, 219);
            this.bt_Spindahkanan.Name = "bt_Spindahkanan";
            this.bt_Spindahkanan.Size = new System.Drawing.Size(93, 39);
            this.bt_Spindahkanan.TabIndex = 10;
            this.bt_Spindahkanan.Text = ">>";
            this.bt_Spindahkanan.UseVisualStyleBackColor = true;
            this.bt_Spindahkanan.Click += new System.EventHandler(this.bt_Spindahkanan_Click);
            // 
            // bt_pindahkanan
            // 
            this.bt_pindahkanan.Location = new System.Drawing.Point(381, 282);
            this.bt_pindahkanan.Name = "bt_pindahkanan";
            this.bt_pindahkanan.Size = new System.Drawing.Size(93, 39);
            this.bt_pindahkanan.TabIndex = 11;
            this.bt_pindahkanan.Text = ">";
            this.bt_pindahkanan.UseVisualStyleBackColor = true;
            this.bt_pindahkanan.Click += new System.EventHandler(this.bt_pindahkanan_Click);
            // 
            // bt_Spindahkiri
            // 
            this.bt_Spindahkiri.Location = new System.Drawing.Point(381, 409);
            this.bt_Spindahkiri.Name = "bt_Spindahkiri";
            this.bt_Spindahkiri.Size = new System.Drawing.Size(93, 39);
            this.bt_Spindahkiri.TabIndex = 13;
            this.bt_Spindahkiri.Text = "<<";
            this.bt_Spindahkiri.UseVisualStyleBackColor = true;
            this.bt_Spindahkiri.Click += new System.EventHandler(this.bt_Spindahkiri_Click);
            // 
            // bt_pindahkiri
            // 
            this.bt_pindahkiri.Location = new System.Drawing.Point(381, 346);
            this.bt_pindahkiri.Name = "bt_pindahkiri";
            this.bt_pindahkiri.Size = new System.Drawing.Size(93, 39);
            this.bt_pindahkiri.TabIndex = 12;
            this.bt_pindahkiri.Text = "<";
            this.bt_pindahkiri.UseVisualStyleBackColor = true;
            this.bt_pindahkiri.Click += new System.EventHandler(this.bt_pindahkiri_Click);
            // 
            // bt_nama1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1580, 863);
            this.Controls.Add(this.bt_Spindahkiri);
            this.Controls.Add(this.bt_pindahkiri);
            this.Controls.Add(this.bt_pindahkanan);
            this.Controls.Add(this.bt_Spindahkanan);
            this.Controls.Add(this.bt_clear2);
            this.Controls.Add(this.list_nama2);
            this.Controls.Add(this.bt_input2);
            this.Controls.Add(this.tb_nama2);
            this.Controls.Add(this.lb_nama2);
            this.Controls.Add(this.bt_clear1);
            this.Controls.Add(this.list_nama1);
            this.Controls.Add(this.bt_input1);
            this.Controls.Add(this.tb_nama1);
            this.Controls.Add(this.lb_nama1);
            this.Name = "bt_nama1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_nama1;
        private System.Windows.Forms.TextBox tb_nama1;
        private System.Windows.Forms.Button bt_input1;
        private System.Windows.Forms.ListBox list_nama1;
        private System.Windows.Forms.Button bt_clear1;
        private System.Windows.Forms.Button bt_clear2;
        private System.Windows.Forms.ListBox list_nama2;
        private System.Windows.Forms.Button bt_input2;
        private System.Windows.Forms.TextBox tb_nama2;
        private System.Windows.Forms.Label lb_nama2;
        private System.Windows.Forms.Button bt_Spindahkanan;
        private System.Windows.Forms.Button bt_pindahkanan;
        private System.Windows.Forms.Button bt_Spindahkiri;
        private System.Windows.Forms.Button bt_pindahkiri;
    }
}

