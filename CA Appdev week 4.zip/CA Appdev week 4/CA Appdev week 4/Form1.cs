﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Appdev_week_4
{
    public partial class bt_nama1 : Form
    {
        public List<string> NamaList1 = new List<string>();
        public List<string> NamaList2 = new List<string>();
        public bt_nama1()
        {
            InitializeComponent();
        }
        private void bt_input1_Click(object sender, EventArgs e)
        {
            if (NamaList1.Contains(tb_nama1.Text) || NamaList2.Contains(tb_nama1.Text))
            {
                MessageBox.Show("sudah ada nama di list");
                tb_nama1.Clear();
            }
            else
            {
                list_nama1.Items.Add(tb_nama1.Text);
                NamaList1.Add(tb_nama1.Text);
                tb_nama1.Clear();
            }
        }
        private void bt_input2_Click(object sender, EventArgs e)
        {
            if (NamaList1.Contains(tb_nama2.Text) || NamaList2.Contains(tb_nama2.Text))
            {
                MessageBox.Show("sudah ada nama di list");
                tb_nama2.Clear();
            }
            else
            {
                list_nama2.Items.Add(tb_nama2.Text);
                NamaList2.Add(tb_nama2.Text);
                tb_nama2.Clear();
            }
        }
        private void bt_clear1_Click(object sender, EventArgs e)
        {
            list_nama1.Items.Clear();
            NamaList1.Clear();
        }
        private void bt_clear2_Click(object sender, EventArgs e)
        {
            list_nama2.Items.Clear();
            NamaList2.Clear();
        }
        private void bt_Spindahkanan_Click(object sender, EventArgs e)
        {
            foreach (string s in NamaList1 )
            {
                NamaList2.Add(s);
                list_nama2.Items.Add(s);
            }
            list_nama1.Items.Clear();
            NamaList1.Clear();
        }
        private void bt_Spindahkiri_Click(object sender, EventArgs e)
        {
            foreach (string s in NamaList2)
            {
                NamaList1.Add(s);
                list_nama1.Items.Add(s);
            }
            list_nama2.Items.Clear();
            NamaList2.Clear();
        }
        private void bt_pindahkanan_Click(object sender, EventArgs e)
        {
            NamaList2.Add(list_nama1.SelectedItem.ToString());
            list_nama2.Items.Add(list_nama1.SelectedItem.ToString());
            NamaList1.Remove(list_nama1.SelectedItem.ToString());
            list_nama1.Items.Remove(list_nama1.SelectedItem.ToString());
        }
        private void bt_pindahkiri_Click(object sender, EventArgs e)
        {
            NamaList1.Add(list_nama2.SelectedItem.ToString());
            list_nama1.Items.Add(list_nama2.SelectedItem.ToString());
            NamaList2.Remove(list_nama2.SelectedItem.ToString());
            list_nama2.Items.Remove(list_nama2.SelectedItem.ToString());
        }
    }
}
