﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;

namespace CA11_AppDev
{
    // AMANDA RENATA GO - 0706022310010
    public partial class F1 : Form
    {
        public F1()
        {
            InitializeComponent();
        }
        MySqlConnection connection;
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable match = new DataTable();
        DataTable dmatch = new DataTable();
        DataTable team = new DataTable();
        DataTable player = new DataTable();
        DataTable DGV = new DataTable();
        List<string> matchID = new List<string>();
        string home;
        string away;

        private void F1_Load(object sender, EventArgs e)
        {
            tb_database.Text = "premier_league";
            tb_password.Text = "isbmantap";
            tb_server.Text = "localhost";
            tb_user.Text = "root";


            dgv_match.DataSource = DGV;
            DGV.Columns.Add("minute");
            DGV.Columns.Add("team_name");
            DGV.Columns.Add("player_name");
            DGV.Columns.Add("type");
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            if (tb_database.Text != "premier_league" || tb_password.Text != "isbmantap" || tb_server.Text != "localhost" || tb_user.Text != "root")
            {
                MessageBox.Show("Wrong Input");
            }
            else
            {
                connection = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league;");
                connection.Open();
                connection.Close();

                string sqlQuery = "select * from `match`";
                command = new MySqlCommand(sqlQuery, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(match);

                sqlQuery = "select * from dmatch";
                command = new MySqlCommand(sqlQuery, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dmatch);

                sqlQuery = "select * from team";
                command = new MySqlCommand(sqlQuery, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(team);

                sqlQuery = "select * from player";
                command = new MySqlCommand(sqlQuery, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(player);

                cb_home.Items.Clear();
                cb_away.Items.Clear();
                foreach (DataRow row in team.Rows)
                {
                    cb_home.Items.Add(row[1]);
                    cb_away.Items.Add(row[1]);
                }
                cb_away.SelectedIndex = 0;
                cb_home.SelectedIndex = 0;
                home = cb_home.SelectedItem.ToString();
                away = cb_away.SelectedItem.ToString();
            }
        }
        string homeName;
        string awayName;
        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            home = cb_home.SelectedItem.ToString();
            foreach(DataRow row in team.Rows)
            {
                if (row[1].ToString() == home)
                {
                    homeName = row[0].ToString();
                }
            }
            if (home != away)
            {
                //munculinData();
                muncul();
            }            
        }
        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            away = cb_away.SelectedItem.ToString();
            foreach (DataRow row in team.Rows)
            {
                if (row[1].ToString() == away)
                {
                    awayName = row[0].ToString();
                }
            }
            if (home != away)
            {
                //munculinData();
                muncul();
            }

        }

        DataTable dgvv = new DataTable();
        public void muncul()
        {
            string query = $"select match_id from `match` where team_home = '{homeName}' and team_away = '{awayName}'";
            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dgvv);
            //MessageBox.Show(dgvv.Rows.Count.ToString());

            foreach (DataRow row in dgvv.Rows)
            {
                matchID.Add(row[0].ToString());
            }

            //MessageBox.Show(matchID.Count.ToString());

            if (matchID.Count == 0)
            {

            }
            else
            {
                tb_matchID.Text = matchID[0];

                foreach (DataRow row in match.Rows)
                {
                    if (row["match_id"].ToString() == matchID[0])
                    {
                        DateTime date = Convert.ToDateTime(row["match_date"]);
                        dtp_dateMatch.Value = date;
                    }
                }

                DGV.Rows.Clear();

                int index = 0;
                foreach (DataRow row in dmatch.Rows)
                {
                    if (row["match_id"].ToString() == matchID[index])
                    {
                        foreach (DataRow row2 in team.Rows)
                        {
                            if (row[2].ToString()== row2[0].ToString())
                            {
                                foreach (DataRow row3 in player.Rows)
                                {
                                    if (row[3].ToString()== row3[0].ToString())
                                    {

                                        DGV.Rows.Add(row[1], row2[1], row3[2], row[4]);
                                    }
                                }
                            }
                        }
                        if (index < matchID.Count-1)
                        {
                            index++;
                        }
                    }
                }
            }

        }

        public void munculinData ()
        {
            foreach (DataRow row in match.Rows)
            {
                if (row["team_away"].ToString() == awayName)
                {
                    if (row["team_home"].ToString() == homeName)
                    {
                        matchID.Add(row["match_id"].ToString());
                    }
                }
            }

            MessageBox.Show(matchID.Count.ToString());

            if (matchID.Count == 0)
            {

            }
            else
            {
                tb_matchID.Text = matchID[0];

                foreach (DataRow row in match.Rows)
                {
                    if (row["match_id"].ToString() == matchID[0])
                    {
                        DateTime date = Convert.ToDateTime(row["match_date"]);
                        dtp_dateMatch.Value = date;
                    }
                }

                DGV.Rows.Clear();

                int index = 0;
                foreach (DataRow row in dmatch.Rows)
                {
                    if (row["match_id"].ToString() == matchID[index])
                    {
                        DGV.Rows.Add(row);
                        index++;
                    }
                }
            }
        }

    }
}
