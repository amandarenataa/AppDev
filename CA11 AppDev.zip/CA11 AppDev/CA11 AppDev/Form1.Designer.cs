﻿namespace CA11_AppDev
{
    partial class F1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_server = new System.Windows.Forms.Label();
            this.lb_user = new System.Windows.Forms.Label();
            this.lb_database = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.tb_server = new System.Windows.Forms.TextBox();
            this.tb_user = new System.Windows.Forms.TextBox();
            this.tb_database = new System.Windows.Forms.TextBox();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.lb_matchID = new System.Windows.Forms.Label();
            this.lb_home = new System.Windows.Forms.Label();
            this.cb_home = new System.Windows.Forms.ComboBox();
            this.cb_away = new System.Windows.Forms.ComboBox();
            this.lb_away = new System.Windows.Forms.Label();
            this.dgv_match = new System.Windows.Forms.DataGridView();
            this.dtp_dateMatch = new System.Windows.Forms.DateTimePicker();
            this.lb_matchdate = new System.Windows.Forms.Label();
            this.bt_login = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_server
            // 
            this.lb_server.AutoSize = true;
            this.lb_server.Location = new System.Drawing.Point(66, 74);
            this.lb_server.Name = "lb_server";
            this.lb_server.Size = new System.Drawing.Size(75, 25);
            this.lb_server.TabIndex = 0;
            this.lb_server.Text = "Server";
            // 
            // lb_user
            // 
            this.lb_user.AutoSize = true;
            this.lb_user.Location = new System.Drawing.Point(84, 126);
            this.lb_user.Name = "lb_user";
            this.lb_user.Size = new System.Drawing.Size(57, 25);
            this.lb_user.TabIndex = 1;
            this.lb_user.Text = "User";
            // 
            // lb_database
            // 
            this.lb_database.AutoSize = true;
            this.lb_database.Location = new System.Drawing.Point(37, 235);
            this.lb_database.Name = "lb_database";
            this.lb_database.Size = new System.Drawing.Size(104, 25);
            this.lb_database.TabIndex = 3;
            this.lb_database.Text = "Database";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(35, 182);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(106, 25);
            this.lb_password.TabIndex = 2;
            this.lb_password.Text = "Password";
            // 
            // tb_server
            // 
            this.tb_server.Location = new System.Drawing.Point(158, 68);
            this.tb_server.Name = "tb_server";
            this.tb_server.Size = new System.Drawing.Size(189, 31);
            this.tb_server.TabIndex = 4;
            // 
            // tb_user
            // 
            this.tb_user.Location = new System.Drawing.Point(158, 126);
            this.tb_user.Name = "tb_user";
            this.tb_user.Size = new System.Drawing.Size(189, 31);
            this.tb_user.TabIndex = 5;
            // 
            // tb_database
            // 
            this.tb_database.Location = new System.Drawing.Point(158, 240);
            this.tb_database.Name = "tb_database";
            this.tb_database.Size = new System.Drawing.Size(189, 31);
            this.tb_database.TabIndex = 7;
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(158, 182);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(189, 31);
            this.tb_password.TabIndex = 6;
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(635, 68);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(189, 31);
            this.tb_matchID.TabIndex = 9;
            // 
            // lb_matchID
            // 
            this.lb_matchID.AutoSize = true;
            this.lb_matchID.Location = new System.Drawing.Point(532, 74);
            this.lb_matchID.Name = "lb_matchID";
            this.lb_matchID.Size = new System.Drawing.Size(97, 25);
            this.lb_matchID.TabIndex = 8;
            this.lb_matchID.Text = "Match ID";
            // 
            // lb_home
            // 
            this.lb_home.AutoSize = true;
            this.lb_home.Location = new System.Drawing.Point(501, 132);
            this.lb_home.Name = "lb_home";
            this.lb_home.Size = new System.Drawing.Size(128, 25);
            this.lb_home.TabIndex = 10;
            this.lb_home.Text = "Team Home";
            // 
            // cb_home
            // 
            this.cb_home.FormattingEnabled = true;
            this.cb_home.Location = new System.Drawing.Point(635, 123);
            this.cb_home.Name = "cb_home";
            this.cb_home.Size = new System.Drawing.Size(189, 33);
            this.cb_home.TabIndex = 11;
            this.cb_home.SelectedIndexChanged += new System.EventHandler(this.cb_home_SelectedIndexChanged);
            // 
            // cb_away
            // 
            this.cb_away.FormattingEnabled = true;
            this.cb_away.Location = new System.Drawing.Point(1199, 132);
            this.cb_away.Name = "cb_away";
            this.cb_away.Size = new System.Drawing.Size(189, 33);
            this.cb_away.TabIndex = 13;
            this.cb_away.SelectedIndexChanged += new System.EventHandler(this.cb_away_SelectedIndexChanged);
            // 
            // lb_away
            // 
            this.lb_away.AutoSize = true;
            this.lb_away.Location = new System.Drawing.Point(1065, 141);
            this.lb_away.Name = "lb_away";
            this.lb_away.Size = new System.Drawing.Size(124, 25);
            this.lb_away.TabIndex = 12;
            this.lb_away.Text = "Team Away";
            // 
            // dgv_match
            // 
            this.dgv_match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_match.Location = new System.Drawing.Point(511, 244);
            this.dgv_match.Name = "dgv_match";
            this.dgv_match.RowHeadersWidth = 82;
            this.dgv_match.RowTemplate.Height = 33;
            this.dgv_match.Size = new System.Drawing.Size(774, 448);
            this.dgv_match.TabIndex = 14;
            // 
            // dtp_dateMatch
            // 
            this.dtp_dateMatch.Location = new System.Drawing.Point(1199, 66);
            this.dtp_dateMatch.Name = "dtp_dateMatch";
            this.dtp_dateMatch.Size = new System.Drawing.Size(410, 31);
            this.dtp_dateMatch.TabIndex = 15;
            // 
            // lb_matchdate
            // 
            this.lb_matchdate.AutoSize = true;
            this.lb_matchdate.Location = new System.Drawing.Point(1065, 74);
            this.lb_matchdate.Name = "lb_matchdate";
            this.lb_matchdate.Size = new System.Drawing.Size(122, 25);
            this.lb_matchdate.TabIndex = 16;
            this.lb_matchdate.Text = "Match Date";
            // 
            // bt_login
            // 
            this.bt_login.Location = new System.Drawing.Point(116, 319);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(112, 37);
            this.bt_login.TabIndex = 17;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // F1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1910, 1008);
            this.Controls.Add(this.bt_login);
            this.Controls.Add(this.lb_matchdate);
            this.Controls.Add(this.dtp_dateMatch);
            this.Controls.Add(this.dgv_match);
            this.Controls.Add(this.cb_away);
            this.Controls.Add(this.lb_away);
            this.Controls.Add(this.cb_home);
            this.Controls.Add(this.lb_home);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.lb_matchID);
            this.Controls.Add(this.tb_database);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.tb_user);
            this.Controls.Add(this.tb_server);
            this.Controls.Add(this.lb_database);
            this.Controls.Add(this.lb_password);
            this.Controls.Add(this.lb_user);
            this.Controls.Add(this.lb_server);
            this.Name = "F1";
            this.Text = "F1";
            this.Load += new System.EventHandler(this.F1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_server;
        private System.Windows.Forms.Label lb_user;
        private System.Windows.Forms.Label lb_database;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.TextBox tb_server;
        private System.Windows.Forms.TextBox tb_user;
        private System.Windows.Forms.TextBox tb_database;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.Label lb_matchID;
        private System.Windows.Forms.Label lb_home;
        private System.Windows.Forms.ComboBox cb_home;
        private System.Windows.Forms.ComboBox cb_away;
        private System.Windows.Forms.Label lb_away;
        private System.Windows.Forms.DataGridView dgv_match;
        private System.Windows.Forms.DateTimePicker dtp_dateMatch;
        private System.Windows.Forms.Label lb_matchdate;
        private System.Windows.Forms.Button bt_login;
    }
}

