﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Week_9
{
    public partial class F2_Main : Form
    {
        DataTable User;
        F1_Login F1;
        F3_Add F3;
        public F2_Main()
        {
            InitializeComponent();
        }
        public F2_Main(Form _sender)
        {
            InitializeComponent();
            F1 = (F1_Login)_sender;
        }
        public void DatadrF1(DataTable _user, string _username)
        {
            User = _user;
            tss_labelUser.Text = _username;
            
        }

        private void ms_add_Click(object sender, EventArgs e)
        {
            F3 = new F3_Add(this);
            F3.MdiParent = this;
            F3.Show();
            F3.Data(User);
        }

        public void DatadrF3(DataTable _user)
        {
            User = _user;
        }

        private void ms_logout_Click(object sender, EventArgs e)
        {
            F1.DatadrF2(User);
            this.Close();
            F1.Show();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            tss_labelTime.Text = DateTime.Now.ToString();
        }
    }
}
