﻿namespace CA_Week_9
{
    partial class F3_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.lb_password = new System.Windows.Forms.Label();
            this.lb_username = new System.Windows.Forms.Label();
            this.tb_confirmPass = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_addUser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(376, 205);
            this.tb_password.Name = "tb_password";
            this.tb_password.PasswordChar = '*';
            this.tb_password.Size = new System.Drawing.Size(187, 31);
            this.tb_password.TabIndex = 7;
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(376, 156);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(187, 31);
            this.tb_username.TabIndex = 6;
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(221, 208);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(106, 25);
            this.lb_password.TabIndex = 5;
            this.lb_password.Text = "Password";
            // 
            // lb_username
            // 
            this.lb_username.AutoSize = true;
            this.lb_username.Location = new System.Drawing.Point(217, 156);
            this.lb_username.Name = "lb_username";
            this.lb_username.Size = new System.Drawing.Size(110, 25);
            this.lb_username.TabIndex = 4;
            this.lb_username.Text = "Username";
            // 
            // tb_confirmPass
            // 
            this.tb_confirmPass.Location = new System.Drawing.Point(376, 256);
            this.tb_confirmPass.Name = "tb_confirmPass";
            this.tb_confirmPass.PasswordChar = '*';
            this.tb_confirmPass.Size = new System.Drawing.Size(187, 31);
            this.tb_confirmPass.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(141, 256);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "Confirm Password";
            // 
            // bt_addUser
            // 
            this.bt_addUser.Location = new System.Drawing.Point(305, 319);
            this.bt_addUser.Name = "bt_addUser";
            this.bt_addUser.Size = new System.Drawing.Size(131, 58);
            this.bt_addUser.TabIndex = 10;
            this.bt_addUser.Text = "Add User";
            this.bt_addUser.UseVisualStyleBackColor = true;
            this.bt_addUser.Click += new System.EventHandler(this.bt_addUser_Click);
            // 
            // F3_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 521);
            this.Controls.Add(this.bt_addUser);
            this.Controls.Add(this.tb_confirmPass);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.tb_username);
            this.Controls.Add(this.lb_password);
            this.Controls.Add(this.lb_username);
            this.Name = "F3_Add";
            this.Text = "Add User";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.Label lb_username;
        private System.Windows.Forms.TextBox tb_confirmPass;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_addUser;
    }
}