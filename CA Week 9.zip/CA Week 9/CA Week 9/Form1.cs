﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Week_9
{
    public partial class F1_Login : Form
    {
        DataTable user;
        F2_Main F2;
        public F1_Login()
        {
            InitializeComponent();
        }

        private void F1_Login_Load(object sender, EventArgs e)
        {
            user = new DataTable();
            user.Columns.Add("Username");
            user.Columns.Add("Password");
            user.Rows.Add("admin", "admin");
        }
        int count;

        private void btn_login_Click(object sender, EventArgs e)
        {
            bool ada = false;
            foreach (DataRow row in user.Rows)
            {
                if (row["Username"].ToString() == tb_username.Text)
                {
                    if (row["Password"].ToString() == tb_password.Text)
                    {
                        ada = true;
                    }
                }
            }
            if (ada == true)
            {
                F2 = new F2_Main(this);
                F2.Show();
                F2.DatadrF1(user, tb_username.Text);
                tb_password.Clear();
                tb_username.Clear();
                this.Hide();
            }
            else
            {
                MessageBox.Show("User / password not found");
            }
        }
        public void DatadrF2(DataTable _user)
        {
            user = _user;
        }
    }
}
