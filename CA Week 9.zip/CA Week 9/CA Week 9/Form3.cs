﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Week_9
{
    public partial class F3_Add : Form
    {
        DataTable User;
        F2_Main F2;
        public F3_Add()
        {
            InitializeComponent();
        }
        public F3_Add(Form _sender)
        {
            InitializeComponent();
            F2 = (F2_Main) _sender;
        }
        public void Data(DataTable _user)
        {
            User = _user;
        }

        private void bt_addUser_Click(object sender, EventArgs e)
        {
            bool tdkberhasil = false;
            if (tb_password.Text != tb_confirmPass.Text)
            {
                MessageBox.Show("Password don't Match");
            }
            else
            {
                foreach (DataRow row in User.Rows)
                {
                    if (row["Username"].ToString() == tb_username.Text)
                    {
                        MessageBox.Show("Username already listed");
                        tb_username.Clear();
                        tb_password.Clear();
                        tb_confirmPass.Clear();
                        tdkberhasil = true;
                    }
                }
                if (tdkberhasil == false)
                {
                    MessageBox.Show("User added");
                    User.Rows.Add(tb_username.Text, tb_password.Text);
                    tb_username.Clear();
                    tb_password.Clear();
                    tb_confirmPass.Clear();
                    F2.DatadrF3(User);
                }
            }
        }
    }
}
