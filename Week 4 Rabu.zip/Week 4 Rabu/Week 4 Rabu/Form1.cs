﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_4_Rabu
{
    public partial class panel : Form
    {
        DataTable dt;
        public panel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("hai", "caption", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.OK)
            {
                button1.Visible = false;
            }
            if (dr == DialogResult.Cancel)
            {
                MessageBox.Show("we");
            }
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            int angka = Convert.ToInt32(tb_Angka.Text);
            int count = 0;
            bool prima = false;
            for (int i = 1; i <= angka; i++)
            {
                if (angka % i == 0)
                {
                    count++;
                }
            }
            if (count == 2)
            {
                prima = true;
            }
            DialogResult hasil = MessageBox.Show("Apakah ini Prima", "pinter atau tidak kamu?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (hasil == DialogResult.Yes && prima == true || hasil == DialogResult.No && prima == false)
            {
                MessageBox.Show("PINTER");
            }
            else
            {
                MessageBox.Show("kurang pinter :)");
            }
        }

        private void label_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("NIM");
            dt.Columns.Add("Name");
            dt.Columns.Add("Prodi");
            dt.Rows.Add("10010", "Amanda", "ISB");
            dt.Rows.Add("10011", "Feylin", "ISB");
            dt.Rows.Add("10012", "Icel", "ISB");
            dataGridView1.DataSource = dt;

        }
        private void bt_add_Click(object sender, EventArgs e)
        {
            bool ok =  false;
            //cara 1
            foreach (DataGridViewRow datarow in dataGridView1.Rows)
            {
                if (datarow.Cells[0].Value.ToString() == tb_nim.Text)
                {
                    ok = true;
                    tb_nim.Clear();
                }
            }
            // cara 2
            foreach (DataRow data in dt.Rows)
            {
                if (data["NIM"].ToString() == tb_nim.Text)
                {
                    ok = true;
                    tb_nim.Clear();
                }
            }


            if (ok == true)
            {
                MessageBox.Show("Nim sudah terdaftar");
            }
            else 
            {
                dt.Rows.Add(tb_nim.Text, tb_nama.Text, tb_prodi.Text);
                tb_nama.Clear();
                tb_prodi.Clear();
                tb_nim.Clear();
            }
        }

        private void bt_checkhihi_Click(object sender, EventArgs e)
        {
            DataGridViewRow daata = dataGridView1.CurrentRow;
            MessageBox.Show("NIM: " + daata.Cells[0].Value.ToString() + ". Nama: " + daata.Cells[1].Value.ToString() + ". Prodi: " + daata.Cells[2].Value.ToString());
        }

        private void bt_Delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow daata = dataGridView1.CurrentRow;
            dataGridView1.Rows.RemoveAt(daata.Index);
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            //cara 1
            daata = dataGridView1.CurrentRow;
            //cara 2
            rowke = dataGridView1.CurrentRow.Index;

            tb_nim.Enabled = false;
            tb_nim.Text = daata.Cells[0].Value.ToString();
            tb_nama.Text = daata.Cells[1].Value.ToString();
            tb_prodi.Text = daata.Cells[2].Value.ToString();
            bt_update.Enabled = true;
            bt_add.Enabled = false;

            rowke = dataGridView1.CurrentRow.Index;
        }
        public int rowke;
        public DataGridViewRow daata;
        private void bt_update_Click(object sender, EventArgs e)
        {
            //cara 2
            dt.Rows[rowke][1] = tb_nama.Text;
            dt.Rows[rowke][2] = tb_prodi.Text;

            //cara 3
            dataGridView1.Rows[rowke].Cells[1].Value = tb_nama.Text;
            dataGridView1.Rows[rowke].Cells[2].Value = tb_prodi.Text;

            //cara 1
            daata.Cells[1].Value = tb_nama.Text;
            daata.Cells[2].Value = tb_prodi.Text;

            tb_nim.Enabled = true;
            bt_update.Enabled = false;
            bt_add.Enabled = true;
            tb_nama.Clear();
            tb_prodi.Clear();
            tb_nim.Clear();
        }
    }
}
