﻿namespace Week_4_Rabu
{
    partial class panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btn_check = new System.Windows.Forms.Button();
            this.lb_Angka = new System.Windows.Forms.Label();
            this.tb_Angka = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tb_nim = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_prodi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bt_add = new System.Windows.Forms.Button();
            this.bt_checkhihi = new System.Windows.Forms.Button();
            this.bt_Delete = new System.Windows.Forms.Button();
            this.bt_update = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(73, 71);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(174, 68);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(73, 425);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(198, 98);
            this.btn_check.TabIndex = 1;
            this.btn_check.Text = "Check";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click);
            // 
            // lb_Angka
            // 
            this.lb_Angka.AutoSize = true;
            this.lb_Angka.Location = new System.Drawing.Point(126, 289);
            this.lb_Angka.Name = "lb_Angka";
            this.lb_Angka.Size = new System.Drawing.Size(73, 25);
            this.lb_Angka.TabIndex = 2;
            this.lb_Angka.Text = "Angka";
            // 
            // tb_Angka
            // 
            this.tb_Angka.Location = new System.Drawing.Point(54, 344);
            this.tb_Angka.Name = "tb_Angka";
            this.tb_Angka.Size = new System.Drawing.Size(227, 31);
            this.tb_Angka.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(415, 170);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(835, 266);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // tb_nim
            // 
            this.tb_nim.Location = new System.Drawing.Point(1477, 194);
            this.tb_nim.Name = "tb_nim";
            this.tb_nim.Size = new System.Drawing.Size(227, 31);
            this.tb_nim.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1352, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "NIM";
            // 
            // tb_nama
            // 
            this.tb_nama.Location = new System.Drawing.Point(1477, 248);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(227, 31);
            this.tb_nama.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1352, 251);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "NAMA";
            // 
            // tb_prodi
            // 
            this.tb_prodi.Location = new System.Drawing.Point(1477, 307);
            this.tb_prodi.Name = "tb_prodi";
            this.tb_prodi.Size = new System.Drawing.Size(227, 31);
            this.tb_prodi.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1352, 310);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 25);
            this.label3.TabIndex = 9;
            this.label3.Text = "PRODI";
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(1377, 388);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(106, 48);
            this.bt_add.TabIndex = 11;
            this.bt_add.Text = "Add";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // bt_checkhihi
            // 
            this.bt_checkhihi.Location = new System.Drawing.Point(415, 453);
            this.bt_checkhihi.Name = "bt_checkhihi";
            this.bt_checkhihi.Size = new System.Drawing.Size(118, 42);
            this.bt_checkhihi.TabIndex = 12;
            this.bt_checkhihi.Text = "Check";
            this.bt_checkhihi.UseVisualStyleBackColor = true;
            this.bt_checkhihi.Click += new System.EventHandler(this.bt_checkhihi_Click);
            // 
            // bt_Delete
            // 
            this.bt_Delete.Location = new System.Drawing.Point(586, 453);
            this.bt_Delete.Name = "bt_Delete";
            this.bt_Delete.Size = new System.Drawing.Size(118, 42);
            this.bt_Delete.TabIndex = 13;
            this.bt_Delete.Text = "Delete";
            this.bt_Delete.UseVisualStyleBackColor = true;
            this.bt_Delete.Click += new System.EventHandler(this.bt_Delete_Click);
            // 
            // bt_update
            // 
            this.bt_update.Enabled = false;
            this.bt_update.Location = new System.Drawing.Point(1530, 388);
            this.bt_update.Name = "bt_update";
            this.bt_update.Size = new System.Drawing.Size(106, 48);
            this.bt_update.TabIndex = 14;
            this.bt_update.Text = "Update";
            this.bt_update.UseVisualStyleBackColor = true;
            this.bt_update.Click += new System.EventHandler(this.bt_update_Click);
            // 
            // panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2250, 886);
            this.Controls.Add(this.bt_update);
            this.Controls.Add(this.bt_Delete);
            this.Controls.Add(this.bt_checkhihi);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.tb_prodi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_nim);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tb_Angka);
            this.Controls.Add(this.lb_Angka);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.button1);
            this.Name = "panel";
            this.Text = "form1";
            this.Load += new System.EventHandler(this.label_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.Label lb_Angka;
        private System.Windows.Forms.TextBox tb_Angka;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tb_nim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_prodi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bt_add;
        private System.Windows.Forms.Button bt_checkhihi;
        private System.Windows.Forms.Button bt_Delete;
        private System.Windows.Forms.Button bt_update;
    }
}

