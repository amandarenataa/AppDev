﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA11
{
    public partial class CA11 : Form
    {
        DataTable isiDGV = new DataTable();
        string teamhome = string.Empty;
        string teamaway = string.Empty;

        string teamHome2 = string.Empty;
        string teamaway2 = string.Empty;
        public CA11()
        {
            InitializeComponent();
            tb_server.Text = "localhost";
            tb_username.Text = "student";
            tb_password.Text = "isbmantap";
            tb_database.Text = "premier_league";

            
            isiDGV.Columns.Add("minute");
            isiDGV.Columns.Add("team_name");
            isiDGV.Columns.Add("player_name");
            isiDGV.Columns.Add("type");

            //isiDGV.Columns.Add("")
        }

        MySqlConnection connection;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;

        DataTable dtTeam = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtMatch = new DataTable();
        DataTable dtDMatch = new DataTable();

        private void btn_login_Click(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server=localhost;uid=student;pwd=isbmantap;database=premier_league");
            connection.Open();
            //MessageBox.Show("open");
            connection.Close();

            string queryTeam = "select * from team"; // diambil dari data Team
            cmd = new MySqlCommand(queryTeam, connection);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtTeam);

            foreach (DataRow row in dtTeam.Rows) // isi combo box team away
            {
                cb_teamAway.Items.Add(row[1]);
            }

            foreach (DataRow row in dtTeam.Rows) // combo box team home
            {
                cb_teamHome.Items.Add(row[1]);
            }

            cb_teamAway.SelectedItem = "Arsenal";
            cb_teamHome.SelectedItem = "Arsenal";

            string queryMatch = "select * from `match`";
            cmd = new MySqlCommand(queryMatch, connection);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtMatch);

            string queryDMatch = "select * from dmatch";
            cmd = new MySqlCommand(queryDMatch, connection);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDMatch);

            string queryPlayer = "select * from player";
            cmd = new MySqlCommand(queryPlayer, connection);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtPlayer);

        }

       
        
        
        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*string queryTeamHome = "select dmatch.minute, team.team_name, player.player_name, dmatch.type " +
                "from dmatch, team, player";
            cmd = new MySqlCommand(queryTeamHome, connection);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(isiDGV);
            //adapter.Fill(dtMatch);
            //adapter.Fill(dtTeam);
            isiDGV.Rows.Add(adapter);

            dgv_data.DataSource = isiDGV; */

            teamhome = cb_teamHome.SelectedItem.ToString();
            foreach (DataRow dr in dtTeam.Rows)
            {
                if (teamhome == dr["team_name"].ToString())
                {
                    teamHome2 = dr["team_id"].ToString();
                    break;

                }
            }
            dataDGV(teamHome2, teamaway2);


        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*string queryTeamAway = "select dmatch.minute, team.team_name, player.player_name, dmatch.type " +
                "from dmatch, team, player";
            cmd = new MySqlCommand(queryTeamAway, connection);
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDMatch);
            isiDGV.Rows.Add(queryTeamAway);

            dgv_data.DataSource = isiDGV; */

            teamaway = cb_teamAway.SelectedItem.ToString();
            foreach (DataRow dr in dtTeam.Rows)
            {
                if (teamaway == dr["team_name"].ToString())
                {
                    teamaway2 = dr["team_id"].ToString();
                    break;

                }
            }
            dataDGV(teamHome2, teamaway2);
        }

        private void dataDGV(string teamhome, string teamaway)
        {
            isiDGV.Rows.Clear();
            if (teamhome != null || teamaway != null)
            {
                foreach (DataRow row in dtMatch.Rows)
                {
                    if (row["team_home"].ToString() == teamhome && row["team_away"].ToString() == teamaway)
                    {
                        tb_matchid.Text = row["match_id"].ToString();
                        dtp_matchdate.Value = Convert.ToDateTime(row["match_date"]);

                        foreach (DataRow rows in dtDMatch.Rows)
                        {
                            string nama = "";
                            foreach (DataRow dataRow in dtPlayer.Rows)
                            {
                                if (rows["player_id"].ToString() == dataRow["player_id"].ToString())
                                {
                                    nama = dataRow["player_name"].ToString();
                                    break;
                                }
                            }
                            //MessageBox.Show(nama);

                            string teamName = "";
                            foreach (DataRow row2 in dtTeam.Rows)
                            {
                                if (row2["team_id"].ToString() == rows["team_id"].ToString() )
                                {
                                    teamName = row2["team_name"].ToString();
                                }

                                
                            }
                            if (rows["match_id"].ToString() == tb_matchid.Text)
                            {
                               
                                isiDGV.Rows.Add(rows["minute"], teamName, nama, rows["type"]);
                            }
                        }

                    }
                }
            }
            dgv_data.DataSource = isiDGV;
            
        }
        // sherin - 013
        
    }
}
