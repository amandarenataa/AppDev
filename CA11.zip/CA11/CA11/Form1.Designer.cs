﻿namespace CA11
{
    partial class CA11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_server = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_server = new System.Windows.Forms.TextBox();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.tb_database = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.label_matchID = new System.Windows.Forms.Label();
            this.lbl_teamhome = new System.Windows.Forms.Label();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dtp_matchdate = new System.Windows.Forms.DateTimePicker();
            this.dgv_data = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // label_server
            // 
            this.label_server.AutoSize = true;
            this.label_server.Location = new System.Drawing.Point(77, 64);
            this.label_server.Name = "label_server";
            this.label_server.Size = new System.Drawing.Size(72, 25);
            this.label_server.TabIndex = 0;
            this.label_server.Text = "server";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "database";
            // 
            // tb_server
            // 
            this.tb_server.Location = new System.Drawing.Point(196, 64);
            this.tb_server.Name = "tb_server";
            this.tb_server.Size = new System.Drawing.Size(218, 31);
            this.tb_server.TabIndex = 4;
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(196, 125);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(218, 31);
            this.tb_username.TabIndex = 5;
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(196, 194);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(218, 31);
            this.tb_password.TabIndex = 6;
            // 
            // tb_database
            // 
            this.tb_database.Location = new System.Drawing.Point(196, 255);
            this.tb_database.Name = "tb_database";
            this.tb_database.Size = new System.Drawing.Size(218, 31);
            this.tb_database.TabIndex = 7;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(196, 333);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(133, 39);
            this.btn_login.TabIndex = 8;
            this.btn_login.Text = "login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // label_matchID
            // 
            this.label_matchID.AutoSize = true;
            this.label_matchID.Location = new System.Drawing.Point(511, 64);
            this.label_matchID.Name = "label_matchID";
            this.label_matchID.Size = new System.Drawing.Size(97, 25);
            this.label_matchID.TabIndex = 9;
            this.label_matchID.Text = "Match ID";
            // 
            // lbl_teamhome
            // 
            this.lbl_teamhome.AutoSize = true;
            this.lbl_teamhome.Location = new System.Drawing.Point(511, 128);
            this.lbl_teamhome.Name = "lbl_teamhome";
            this.lbl_teamhome.Size = new System.Drawing.Size(118, 25);
            this.lbl_teamhome.TabIndex = 10;
            this.lbl_teamhome.Text = "team home";
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(674, 120);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(184, 33);
            this.cb_teamHome.TabIndex = 11;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(1142, 120);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(184, 33);
            this.cb_teamAway.TabIndex = 13;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(989, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 25);
            this.label7.TabIndex = 12;
            this.label7.Text = "team away";
            // 
            // tb_matchid
            // 
            this.tb_matchid.Enabled = false;
            this.tb_matchid.Location = new System.Drawing.Point(682, 58);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(176, 31);
            this.tb_matchid.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(989, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 25);
            this.label8.TabIndex = 15;
            this.label8.Text = "match date";
            // 
            // dtp_matchdate
            // 
            this.dtp_matchdate.Location = new System.Drawing.Point(1142, 53);
            this.dtp_matchdate.Name = "dtp_matchdate";
            this.dtp_matchdate.Size = new System.Drawing.Size(445, 31);
            this.dtp_matchdate.TabIndex = 16;
            // 
            // dgv_data
            // 
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(521, 236);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 82;
            this.dgv_data.RowTemplate.Height = 33;
            this.dgv_data.Size = new System.Drawing.Size(1008, 427);
            this.dgv_data.TabIndex = 17;
            // 
            // CA11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1703, 820);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.dtp_matchdate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tb_matchid);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.lbl_teamhome);
            this.Controls.Add(this.label_matchID);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.tb_database);
            this.Controls.Add(this.tb_password);
            this.Controls.Add(this.tb_username);
            this.Controls.Add(this.tb_server);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_server);
            this.Name = "CA11";
            this.Text = "CA11";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_server;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_server;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.TextBox tb_database;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label label_matchID;
        private System.Windows.Forms.Label lbl_teamhome;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtp_matchdate;
        private System.Windows.Forms.DataGridView dgv_data;
    }
}

