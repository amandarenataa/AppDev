﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_5_Rabu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Button> buttons;
        public Button btn2;
        public int awal;
        public int akhir;
        private void Form1_Load(object sender, EventArgs e)
        {
            /*
            Button btn = new Button();
            btn.Text = "OK";
            btn.Size = new Size(50, 50);
            btn.Location = new Point(50,50);
            btn.BackColor = Color.Gray;
            btn.ForeColor = Color.Beige;
            this.Controls.Add(btn); // iki paten harus kek gini buat munculin button e
            */
        }

        private void bt_create_Click(object sender, EventArgs e)
        {
            if (buttons == null)
            {
                int location = 50;
                buttons = new List<Button>();
                for (int i = 1; i <= Convert.ToInt16(tb_addbrp.Text); i++)
                {
                    btn2 = new Button();
                    btn2.Text = "Button " + i;
                    btn2.Tag = "Button ke - " + i;
                    btn2.Size = new Size(100, 50);
                    btn2.Location = new Point(100, location);
                    location += 50;
                    btn2.BackColor = Color.Gray;
                    btn2.ForeColor = Color.Beige;
                    buttons.Add(btn2);
                }
                foreach (Button button in buttons)
                {
                    this.Controls.Add(button);
                }
            }
            else
            {
                awal = buttons.Count;
                akhir = Convert.ToInt16(tb_addbrp.Text);
                if (awal < akhir)
                {
                    //MessageBox.Show("Nambah");
                    int location = 50;
                    buttons = new List<Button>();
                    for (int i = 1; i <= Convert.ToInt16(tb_addbrp.Text); i++)
                    {
                        btn2 = new Button();
                        btn2.Text = "Button " + i;
                        btn2.Tag = "Button ke - " + i;
                        btn2.Size = new Size(100, 50);
                        btn2.Location = new Point(100, location);
                        location += 50;
                        btn2.BackColor = Color.Gray;
                        btn2.ForeColor = Color.Beige;
                        buttons.Add(btn2);
                    }
                    foreach (Button button in buttons)
                    {
                        this.Controls.Add(button);
                    }
                }
                else
                {
                    //MessageBox.Show("Delete");
                    int ygDidelete = awal - akhir;
                    //MessageBox.Show(ygDidelete.ToString());
                    for (int i = 0; i < ygDidelete; i++)
                    {
                        this.Controls.Remove(buttons[akhir + i]);
                        //MessageBox.Show(i.ToString());
                    }
                }
            }
            foreach (Button button in buttons)
            {
                button.Click += new EventHandler(btnClick); // agar pas di click isa muncul sesuatu, agar button bisa di click
            }
            tb_addbrp.Clear();
        }

        private void bt_remove_Click(object sender, EventArgs e)
        {
            int kebrp = Convert.ToInt16(tb_removebrp.Text) - 1;
            this.Controls.Remove(buttons[kebrp]); // buat remove button tersebut
        }

        public void btnClick(object sender, EventArgs e)
        {
            Button sebuahbutton = (Button)sender;
            sebuahbutton.Text = tb_change.Text;
            MessageBox.Show(sebuahbutton.Tag.ToString());
        }
    }
}
