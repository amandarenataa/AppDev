﻿namespace Week_5_Rabu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_addbrp = new System.Windows.Forms.TextBox();
            this.bt_create = new System.Windows.Forms.Button();
            this.bt_remove = new System.Windows.Forms.Button();
            this.tb_removebrp = new System.Windows.Forms.TextBox();
            this.tb_change = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tb_addbrp
            // 
            this.tb_addbrp.Location = new System.Drawing.Point(1196, 291);
            this.tb_addbrp.Name = "tb_addbrp";
            this.tb_addbrp.Size = new System.Drawing.Size(154, 31);
            this.tb_addbrp.TabIndex = 0;
            // 
            // bt_create
            // 
            this.bt_create.Location = new System.Drawing.Point(1226, 350);
            this.bt_create.Name = "bt_create";
            this.bt_create.Size = new System.Drawing.Size(108, 52);
            this.bt_create.TabIndex = 1;
            this.bt_create.Text = "Create";
            this.bt_create.UseVisualStyleBackColor = true;
            this.bt_create.Click += new System.EventHandler(this.bt_create_Click);
            // 
            // bt_remove
            // 
            this.bt_remove.Location = new System.Drawing.Point(1423, 350);
            this.bt_remove.Name = "bt_remove";
            this.bt_remove.Size = new System.Drawing.Size(124, 52);
            this.bt_remove.TabIndex = 3;
            this.bt_remove.Text = "Remove";
            this.bt_remove.UseVisualStyleBackColor = true;
            this.bt_remove.Click += new System.EventHandler(this.bt_remove_Click);
            // 
            // tb_removebrp
            // 
            this.tb_removebrp.Location = new System.Drawing.Point(1403, 291);
            this.tb_removebrp.Name = "tb_removebrp";
            this.tb_removebrp.Size = new System.Drawing.Size(154, 31);
            this.tb_removebrp.TabIndex = 2;
            // 
            // tb_change
            // 
            this.tb_change.Location = new System.Drawing.Point(1196, 502);
            this.tb_change.Name = "tb_change";
            this.tb_change.Size = new System.Drawing.Size(154, 31);
            this.tb_change.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2054, 975);
            this.Controls.Add(this.tb_change);
            this.Controls.Add(this.bt_remove);
            this.Controls.Add(this.tb_removebrp);
            this.Controls.Add(this.bt_create);
            this.Controls.Add(this.tb_addbrp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_addbrp;
        private System.Windows.Forms.Button bt_create;
        private System.Windows.Forms.Button bt_remove;
        private System.Windows.Forms.TextBox tb_removebrp;
        private System.Windows.Forms.TextBox tb_change;
    }
}

