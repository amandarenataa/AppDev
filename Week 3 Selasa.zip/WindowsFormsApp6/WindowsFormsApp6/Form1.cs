﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public string Name;
        public int Age;
        public string Gender;
        public  List<string> Hobbies = new List<string>();
        public string hobbies = " ";
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            string nama = tb_Name.Text;
            int count = 0;
            foreach (char c in nama)
            {
                if (char.IsNumber(c))
                {
                    count++;
                }
            }
            if (count == 0)
            {
                Name = nama;
            }
            string age = tb_Age.Text;
            int count2 = 0;
            foreach (char c in age)
            {
                if (c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9' || c == '0')
                {
                    count2++;
                }
            }
            if (count2 == tb_Age.TextLength)
            {
                Age = Convert.ToInt32(tb_Age.Text);
            }
            if (rb_Female.Checked)
            {
                Gender = "Female";
            }
            else if (rb_Male.Checked)
            {
                Gender = "Male";
            }
            if (rb_Black.Checked)
            {
                BackColor = Color.Black;
            }
            else if (rb_Blue.Checked)
            {
                BackColor = Color.Blue;
            }
            else if (rb_Red.Checked)
            {
                BackColor = Color.Red;
            }
            if (cb_Reading.Checked) 
            {
                hobbies = "Reading";
                Hobbies.Add(hobbies);
            }
            if (cb_TV.Checked)
            {
                hobbies = "Watching TV";
                Hobbies.Add(hobbies);
            }
            if (cb_Sports.Checked)
            {
                hobbies = "Playing Sports";
                Hobbies.Add(hobbies);
            }
            int count3 = 0;
            if (cb_others.Checked)
            {
                string oho = tb_Other.Text;
                foreach (char c in oho)
                {
                    if (char.IsNumber(c))
                    {
                        count3++;
                    }
                }
                if (count3 == 0)
                {
                    hobbies = tb_Other.Text;
                    Hobbies.Add(hobbies);
                }
            }
            if (count > 0)
            {
                MessageBox.Show("Your name should not have numbers");
                bt_Clear.Visible = true;
                Hobbies.Clear();
            }
            else if (count2 != tb_Age.TextLength)
            {
                MessageBox.Show("Your age should only be numbers");
                bt_Clear.Visible = true;
                Hobbies.Clear();
            }
            else if (count3 > 0)
            {
                MessageBox.Show("your other hobby is invalid");
                bt_Clear.Visible = true;
                Hobbies.Clear();
            }
            else
            {
                string hoby = "";
                int counter = 1;
                foreach (string s in Hobbies)
                {
                    if (Hobbies.Count > 1 && counter != Hobbies.Count) 
                    {
                        counter += 1;
                        hoby += s + ",";
                    }
                    else
                    {
                        hoby += s;
                    }
                }
                MessageBox.Show($"Name: {Name} Age: {Age} Gender: {Gender} Hobbies: {hoby}");
                bt_Clear.Visible = true;

            }
        }

        private void bt_Clear_Click(object sender, EventArgs e)
        {
            Hobbies.Clear();
            BackColor = Color.White;
            tb_Name.Clear();
            tb_Age.Clear();
            tb_Other.Clear();
            rb_Black.Checked = false;
            rb_Blue.Checked = false;
            rb_Red.Checked = false;
            rb_Female.Checked = false;
            rb_Male.Checked = false;
            cb_Reading.Checked = false;
            cb_Sports.Checked = false;
            cb_TV.Checked = false;
            cb_others.Checked = false;
            bt_Clear.Visible = false;
        }
    }
}