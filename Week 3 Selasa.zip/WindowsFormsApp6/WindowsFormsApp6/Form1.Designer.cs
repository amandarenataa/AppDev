﻿namespace WindowsFormsApp6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Name = new System.Windows.Forms.Label();
            this.lb_Age = new System.Windows.Forms.Label();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Age = new System.Windows.Forms.TextBox();
            this.panel_gender = new System.Windows.Forms.Panel();
            this.rb_Male = new System.Windows.Forms.RadioButton();
            this.rb_Female = new System.Windows.Forms.RadioButton();
            this.lb_gender = new System.Windows.Forms.Label();
            this.panel_Color = new System.Windows.Forms.Panel();
            this.rb_Black = new System.Windows.Forms.RadioButton();
            this.rb_Red = new System.Windows.Forms.RadioButton();
            this.rb_Blue = new System.Windows.Forms.RadioButton();
            this.lb_FavColor = new System.Windows.Forms.Label();
            this.panel_hobbies = new System.Windows.Forms.Panel();
            this.cb_Sports = new System.Windows.Forms.CheckBox();
            this.cb_TV = new System.Windows.Forms.CheckBox();
            this.cb_Reading = new System.Windows.Forms.CheckBox();
            this.tb_Other = new System.Windows.Forms.TextBox();
            this.lb_Hobbies = new System.Windows.Forms.Label();
            this.btn_Submit = new System.Windows.Forms.Button();
            this.bt_Clear = new System.Windows.Forms.Button();
            this.cb_others = new System.Windows.Forms.CheckBox();
            this.panel_gender.SuspendLayout();
            this.panel_Color.SuspendLayout();
            this.panel_hobbies.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_Name
            // 
            this.lb_Name.AutoSize = true;
            this.lb_Name.Location = new System.Drawing.Point(81, 174);
            this.lb_Name.Name = "lb_Name";
            this.lb_Name.Size = new System.Drawing.Size(35, 13);
            this.lb_Name.TabIndex = 0;
            this.lb_Name.Text = "Name";
            // 
            // lb_Age
            // 
            this.lb_Age.AutoSize = true;
            this.lb_Age.Location = new System.Drawing.Point(81, 197);
            this.lb_Age.Name = "lb_Age";
            this.lb_Age.Size = new System.Drawing.Size(26, 13);
            this.lb_Age.TabIndex = 1;
            this.lb_Age.Text = "Age";
            // 
            // tb_Name
            // 
            this.tb_Name.Location = new System.Drawing.Point(122, 171);
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(100, 20);
            this.tb_Name.TabIndex = 2;
            // 
            // tb_Age
            // 
            this.tb_Age.Location = new System.Drawing.Point(122, 197);
            this.tb_Age.Name = "tb_Age";
            this.tb_Age.Size = new System.Drawing.Size(100, 20);
            this.tb_Age.TabIndex = 3;
            // 
            // panel_gender
            // 
            this.panel_gender.Controls.Add(this.rb_Male);
            this.panel_gender.Controls.Add(this.rb_Female);
            this.panel_gender.Controls.Add(this.lb_gender);
            this.panel_gender.Location = new System.Drawing.Point(300, 116);
            this.panel_gender.Name = "panel_gender";
            this.panel_gender.Size = new System.Drawing.Size(188, 71);
            this.panel_gender.TabIndex = 4;
            // 
            // rb_Male
            // 
            this.rb_Male.AutoSize = true;
            this.rb_Male.Location = new System.Drawing.Point(56, 36);
            this.rb_Male.Name = "rb_Male";
            this.rb_Male.Size = new System.Drawing.Size(48, 17);
            this.rb_Male.TabIndex = 7;
            this.rb_Male.TabStop = true;
            this.rb_Male.Text = "Male";
            this.rb_Male.UseVisualStyleBackColor = true;
            // 
            // rb_Female
            // 
            this.rb_Female.AutoSize = true;
            this.rb_Female.Location = new System.Drawing.Point(56, 13);
            this.rb_Female.Name = "rb_Female";
            this.rb_Female.Size = new System.Drawing.Size(59, 17);
            this.rb_Female.TabIndex = 6;
            this.rb_Female.TabStop = true;
            this.rb_Female.Text = "Female";
            this.rb_Female.UseVisualStyleBackColor = true;
            // 
            // lb_gender
            // 
            this.lb_gender.AutoSize = true;
            this.lb_gender.Location = new System.Drawing.Point(5, 13);
            this.lb_gender.Name = "lb_gender";
            this.lb_gender.Size = new System.Drawing.Size(42, 13);
            this.lb_gender.TabIndex = 5;
            this.lb_gender.Text = "Gender";
            // 
            // panel_Color
            // 
            this.panel_Color.Controls.Add(this.rb_Black);
            this.panel_Color.Controls.Add(this.rb_Red);
            this.panel_Color.Controls.Add(this.rb_Blue);
            this.panel_Color.Controls.Add(this.lb_FavColor);
            this.panel_Color.Location = new System.Drawing.Point(300, 220);
            this.panel_Color.Name = "panel_Color";
            this.panel_Color.Size = new System.Drawing.Size(188, 88);
            this.panel_Color.TabIndex = 8;
            // 
            // rb_Black
            // 
            this.rb_Black.AutoSize = true;
            this.rb_Black.Location = new System.Drawing.Point(56, 59);
            this.rb_Black.Name = "rb_Black";
            this.rb_Black.Size = new System.Drawing.Size(52, 17);
            this.rb_Black.TabIndex = 8;
            this.rb_Black.TabStop = true;
            this.rb_Black.Text = "Black";
            this.rb_Black.UseVisualStyleBackColor = true;
            // 
            // rb_Red
            // 
            this.rb_Red.AutoSize = true;
            this.rb_Red.Location = new System.Drawing.Point(56, 36);
            this.rb_Red.Name = "rb_Red";
            this.rb_Red.Size = new System.Drawing.Size(45, 17);
            this.rb_Red.TabIndex = 7;
            this.rb_Red.TabStop = true;
            this.rb_Red.Text = "Red";
            this.rb_Red.UseVisualStyleBackColor = true;
            // 
            // rb_Blue
            // 
            this.rb_Blue.AutoSize = true;
            this.rb_Blue.Location = new System.Drawing.Point(56, 13);
            this.rb_Blue.Name = "rb_Blue";
            this.rb_Blue.Size = new System.Drawing.Size(46, 17);
            this.rb_Blue.TabIndex = 6;
            this.rb_Blue.TabStop = true;
            this.rb_Blue.Text = "Blue";
            this.rb_Blue.UseVisualStyleBackColor = true;
            // 
            // lb_FavColor
            // 
            this.lb_FavColor.AutoSize = true;
            this.lb_FavColor.Location = new System.Drawing.Point(5, 13);
            this.lb_FavColor.Name = "lb_FavColor";
            this.lb_FavColor.Size = new System.Drawing.Size(52, 13);
            this.lb_FavColor.TabIndex = 5;
            this.lb_FavColor.Text = "Fav Color";
            // 
            // panel_hobbies
            // 
            this.panel_hobbies.Controls.Add(this.cb_others);
            this.panel_hobbies.Controls.Add(this.cb_Sports);
            this.panel_hobbies.Controls.Add(this.cb_TV);
            this.panel_hobbies.Controls.Add(this.cb_Reading);
            this.panel_hobbies.Controls.Add(this.tb_Other);
            this.panel_hobbies.Controls.Add(this.lb_Hobbies);
            this.panel_hobbies.Location = new System.Drawing.Point(565, 138);
            this.panel_hobbies.Name = "panel_hobbies";
            this.panel_hobbies.Size = new System.Drawing.Size(188, 135);
            this.panel_hobbies.TabIndex = 9;
            // 
            // cb_Sports
            // 
            this.cb_Sports.AutoSize = true;
            this.cb_Sports.Location = new System.Drawing.Point(57, 58);
            this.cb_Sports.Name = "cb_Sports";
            this.cb_Sports.Size = new System.Drawing.Size(93, 17);
            this.cb_Sports.TabIndex = 13;
            this.cb_Sports.Text = "Playing Sports";
            this.cb_Sports.UseVisualStyleBackColor = true;
            // 
            // cb_TV
            // 
            this.cb_TV.AutoSize = true;
            this.cb_TV.Location = new System.Drawing.Point(57, 36);
            this.cb_TV.Name = "cb_TV";
            this.cb_TV.Size = new System.Drawing.Size(89, 17);
            this.cb_TV.TabIndex = 12;
            this.cb_TV.Text = "Watching TV";
            this.cb_TV.UseVisualStyleBackColor = true;
            // 
            // cb_Reading
            // 
            this.cb_Reading.AutoSize = true;
            this.cb_Reading.Location = new System.Drawing.Point(57, 13);
            this.cb_Reading.Name = "cb_Reading";
            this.cb_Reading.Size = new System.Drawing.Size(66, 17);
            this.cb_Reading.TabIndex = 11;
            this.cb_Reading.Text = "Reading";
            this.cb_Reading.UseVisualStyleBackColor = true;
            // 
            // tb_Other
            // 
            this.tb_Other.Location = new System.Drawing.Point(57, 105);
            this.tb_Other.Name = "tb_Other";
            this.tb_Other.Size = new System.Drawing.Size(100, 20);
            this.tb_Other.TabIndex = 10;
            // 
            // lb_Hobbies
            // 
            this.lb_Hobbies.AutoSize = true;
            this.lb_Hobbies.Location = new System.Drawing.Point(5, 13);
            this.lb_Hobbies.Name = "lb_Hobbies";
            this.lb_Hobbies.Size = new System.Drawing.Size(46, 13);
            this.lb_Hobbies.TabIndex = 5;
            this.lb_Hobbies.Text = "Hobbies";
            // 
            // btn_Submit
            // 
            this.btn_Submit.Location = new System.Drawing.Point(300, 380);
            this.btn_Submit.Name = "btn_Submit";
            this.btn_Submit.Size = new System.Drawing.Size(75, 23);
            this.btn_Submit.TabIndex = 10;
            this.btn_Submit.Text = "Submit";
            this.btn_Submit.UseVisualStyleBackColor = true;
            this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
            // 
            // bt_Clear
            // 
            this.bt_Clear.Location = new System.Drawing.Point(413, 380);
            this.bt_Clear.Name = "bt_Clear";
            this.bt_Clear.Size = new System.Drawing.Size(75, 23);
            this.bt_Clear.TabIndex = 11;
            this.bt_Clear.Text = "Clear";
            this.bt_Clear.UseVisualStyleBackColor = true;
            this.bt_Clear.Visible = false;
            this.bt_Clear.Click += new System.EventHandler(this.bt_Clear_Click);
            // 
            // cb_others
            // 
            this.cb_others.AutoSize = true;
            this.cb_others.Location = new System.Drawing.Point(57, 82);
            this.cb_others.Name = "cb_others";
            this.cb_others.Size = new System.Drawing.Size(57, 17);
            this.cb_others.TabIndex = 14;
            this.cb_others.Text = "Others";
            this.cb_others.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt_Clear);
            this.Controls.Add(this.btn_Submit);
            this.Controls.Add(this.panel_hobbies);
            this.Controls.Add(this.panel_Color);
            this.Controls.Add(this.panel_gender);
            this.Controls.Add(this.tb_Age);
            this.Controls.Add(this.tb_Name);
            this.Controls.Add(this.lb_Age);
            this.Controls.Add(this.lb_Name);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_gender.ResumeLayout(false);
            this.panel_gender.PerformLayout();
            this.panel_Color.ResumeLayout(false);
            this.panel_Color.PerformLayout();
            this.panel_hobbies.ResumeLayout(false);
            this.panel_hobbies.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Name;
        private System.Windows.Forms.Label lb_Age;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Age;
        private System.Windows.Forms.Panel panel_gender;
        private System.Windows.Forms.Label lb_gender;
        private System.Windows.Forms.RadioButton rb_Male;
        private System.Windows.Forms.RadioButton rb_Female;
        private System.Windows.Forms.Panel panel_Color;
        private System.Windows.Forms.RadioButton rb_Black;
        private System.Windows.Forms.RadioButton rb_Red;
        private System.Windows.Forms.RadioButton rb_Blue;
        private System.Windows.Forms.Label lb_FavColor;
        private System.Windows.Forms.Panel panel_hobbies;
        private System.Windows.Forms.Label lb_Hobbies;
        private System.Windows.Forms.TextBox tb_Other;
        private System.Windows.Forms.Button btn_Submit;
        private System.Windows.Forms.CheckBox cb_Sports;
        private System.Windows.Forms.CheckBox cb_TV;
        private System.Windows.Forms.CheckBox cb_Reading;
        private System.Windows.Forms.Button bt_Clear;
        private System.Windows.Forms.CheckBox cb_others;
    }
}

