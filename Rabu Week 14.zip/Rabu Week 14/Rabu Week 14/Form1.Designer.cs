﻿namespace Rabu_Week_14
{
    partial class F1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_pemain = new System.Windows.Forms.Label();
            this.lb_minute = new System.Windows.Forms.Label();
            this.lb_type = new System.Windows.Forms.Label();
            this.dgv_data = new System.Windows.Forms.DataGridView();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_pemain = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.bt_add = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(157, 63);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(83, 25);
            this.lb_team.TabIndex = 0;
            this.lb_team.Text = "TEAM :";
            // 
            // lb_pemain
            // 
            this.lb_pemain.AutoSize = true;
            this.lb_pemain.Location = new System.Drawing.Point(157, 108);
            this.lb_pemain.Name = "lb_pemain";
            this.lb_pemain.Size = new System.Drawing.Size(104, 25);
            this.lb_pemain.TabIndex = 1;
            this.lb_pemain.Text = "PEMAIN :";
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(157, 158);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(104, 25);
            this.lb_minute.TabIndex = 2;
            this.lb_minute.Text = "MINUTE :";
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(157, 204);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(80, 25);
            this.lb_type.TabIndex = 3;
            this.lb_type.Text = "TYPE :";
            // 
            // dgv_data
            // 
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(162, 270);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 82;
            this.dgv_data.RowTemplate.Height = 33;
            this.dgv_data.Size = new System.Drawing.Size(1050, 438);
            this.dgv_data.TabIndex = 4;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(280, 68);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(306, 33);
            this.cb_team.TabIndex = 5;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_pemain
            // 
            this.cb_pemain.FormattingEnabled = true;
            this.cb_pemain.Location = new System.Drawing.Point(280, 108);
            this.cb_pemain.Name = "cb_pemain";
            this.cb_pemain.Size = new System.Drawing.Size(306, 33);
            this.cb_pemain.TabIndex = 6;
            this.cb_pemain.SelectedIndexChanged += new System.EventHandler(this.cb_pemain_SelectedIndexChanged);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(280, 201);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(306, 33);
            this.cb_type.TabIndex = 8;
            this.cb_type.SelectedIndexChanged += new System.EventHandler(this.cb_type_SelectedIndexChanged);
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(280, 155);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(306, 31);
            this.tb_minute.TabIndex = 9;
            // 
            // bt_add
            // 
            this.bt_add.Location = new System.Drawing.Point(646, 193);
            this.bt_add.Name = "bt_add";
            this.bt_add.Size = new System.Drawing.Size(145, 41);
            this.bt_add.TabIndex = 10;
            this.bt_add.Text = "ADD";
            this.bt_add.UseVisualStyleBackColor = true;
            this.bt_add.Click += new System.EventHandler(this.bt_add_Click);
            // 
            // F1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1711, 784);
            this.Controls.Add(this.bt_add);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_pemain);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.lb_pemain);
            this.Controls.Add(this.lb_team);
            this.Name = "F1";
            this.Text = "F1";
            this.Load += new System.EventHandler(this.F1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_pemain;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.DataGridView dgv_data;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_pemain;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Button bt_add;
    }
}

