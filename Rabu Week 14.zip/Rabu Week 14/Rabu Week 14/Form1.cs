﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Rabu_Week_14
{
    public partial class F1 : Form
    {
        public F1()
        {
            InitializeComponent();
        }
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        string sql;
        DataTable dtDataTeam;
        DataTable dtDataPlayer;
        DataTable dtType;
        DataTable dtShow;
        private void F1_Load(object sender, EventArgs e)
        {
            dtShow = new DataTable();
            dtShow.Columns.Add("Minute");
            dtShow.Columns.Add("Team ID");
            dtShow.Columns.Add("Player ID");
            dtShow.Columns.Add("Type");

            dgv_data.DataSource = dtShow;

            conn = new MySqlConnection("server=localhost;uid=student;pwd=isbmantap;database=premier_league");
            conn.Open();
            conn.Close();
            sql = "select * from team";
            cmd = new MySqlCommand(sql, conn);
            dtDataTeam = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDataTeam);

            // cara 1 untuk cb_team 
            //foreach (DataRow dr in dtDataTeam.Rows)
            //{
            //    cb_team.Items.Add(dr[1].ToString());
            //}

            // cara 2 untuk cb_team 
            cb_team.DataSource = dtDataTeam;
            cb_team.ValueMember = "team_id";
            cb_team.DisplayMember = "team_name";

            dtType = new DataTable();
            dtType.Columns.Add("Display");
            dtType.Columns.Add("Value");
            dtType.Rows.Add("Own Goal","GW");
            dtType.Rows.Add("Goal", "GO");
            dtType.Rows.Add("Penalty Goal", "GP");
            dtType.Rows.Add("Yellow Card", "CY");
            dtType.Rows.Add("Red Card", "CR");

            cb_type.DataSource = dtType;
            cb_type.DisplayMember = "Display";
            cb_type.ValueMember = "Value";
        }
        string TeamID;
        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {

            //cara 1 untuk cb_team 
            //string TeamTerpilih = cb_team.SelectedItem.ToString();
            //foreach (DataRow dr in dtDataTeam.Rows)
            //{
            //    if (dr[1].ToString() == TeamTerpilih)
            //    {
            //        TeamID = dr[0].ToString();
            //    }
            //}

            // cara 2 untuk cb_team 
            TeamID = cb_team.SelectedValue.ToString();


            sql = $"select * from player where team_id = '{TeamID}'";
            cmd = new MySqlCommand(sql, conn);
            dtDataPlayer = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDataPlayer);
            //dgv_data.DataSource = dtDataPlayer;

            cb_pemain.DataSource = dtDataPlayer;
            cb_pemain.DisplayMember = "player_name";
            cb_pemain.ValueMember = "player_id";
        }
        DataTable dtDMatch;
        string PlayerID;
        private void cb_pemain_SelectedIndexChanged(object sender, EventArgs e)
        {
            PlayerID = cb_pemain.SelectedValue.ToString();

            sql = $"select * from dmatch where player_id = '{PlayerID}'";
            cmd= new MySqlCommand(sql, conn);
            dtDMatch = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDMatch);
            //dgv_data.DataSource = dtDMatch;
            
        }

        private void bt_add_Click(object sender, EventArgs e)
        {
            dtShow.Rows.Add(tb_minute.Text,TeamID,PlayerID,Type);
        }
        string Type;
        private void cb_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            Type = cb_type.SelectedValue.ToString();
        }
    }
}
