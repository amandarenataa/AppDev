﻿namespace CA_Week_7
{
    partial class F_AddTeam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_teamName = new System.Windows.Forms.Label();
            this.tb_TeamName = new System.Windows.Forms.TextBox();
            this.bt_addTeam = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_teamName
            // 
            this.lb_teamName.AutoSize = true;
            this.lb_teamName.Location = new System.Drawing.Point(374, 113);
            this.lb_teamName.Name = "lb_teamName";
            this.lb_teamName.Size = new System.Drawing.Size(128, 25);
            this.lb_teamName.TabIndex = 0;
            this.lb_teamName.Text = "Team Name";
            // 
            // tb_TeamName
            // 
            this.tb_TeamName.Location = new System.Drawing.Point(269, 184);
            this.tb_TeamName.Name = "tb_TeamName";
            this.tb_TeamName.Size = new System.Drawing.Size(316, 31);
            this.tb_TeamName.TabIndex = 10;
            // 
            // bt_addTeam
            // 
            this.bt_addTeam.Location = new System.Drawing.Point(314, 255);
            this.bt_addTeam.Name = "bt_addTeam";
            this.bt_addTeam.Size = new System.Drawing.Size(217, 69);
            this.bt_addTeam.TabIndex = 9;
            this.bt_addTeam.Text = "Add Team";
            this.bt_addTeam.UseVisualStyleBackColor = true;
            this.bt_addTeam.Click += new System.EventHandler(this.bt_addTeam_Click);
            // 
            // F_AddTeam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1254, 745);
            this.Controls.Add(this.tb_TeamName);
            this.Controls.Add(this.bt_addTeam);
            this.Controls.Add(this.lb_teamName);
            this.Name = "F_AddTeam";
            this.Text = "Add Team";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_teamName;
        private System.Windows.Forms.TextBox tb_TeamName;
        private System.Windows.Forms.Button bt_addTeam;
    }
}