﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Week_7
{
    public partial class W07 : Form
    {
        F_AddTeam form2;
        DataTable dt;
        List<string> Team;
        public W07()
        {
            InitializeComponent();
        }

        private void W07_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("Date");
            dt.Columns.Add("Home Team");
            dt.Columns.Add("Home Score");
            dt.Columns.Add("Away Score");
            dt.Columns.Add("Away Team");
            dgv_formMatch.DataSource = dt;

            Team = new List<string>() { "Nayeon", "Jeongyeon", "Momo", "Sana", "Jihyo", "Mina", "Dahyun", "Chaeyoung", "Tzuyu" };
            foreach (string team in Team)
            {
                cb_HomeTeam.Items.Add(team);
                cb_AwayTeam.Items.Add(team);
            }
        }

        private void bt_addMatch_Click(object sender, EventArgs e)
        {
            string date = dtp_dateMatch.Value.ToString();
            if ( cb_AwayTeam.Text == "" || cb_HomeTeam.Text == "" || tb_scoreAway.Text == "" || tb_ScoreHome.Text == "" )
            {
                MessageBox.Show("Please Fill All The Information.");
            }
            else
            {
                int scoreH = Convert.ToInt16(tb_ScoreHome.Text);
                int scoreA = Convert.ToInt16(tb_scoreAway.Text);
                if (scoreH > 999 || scoreA > 999)
                {
                    MessageBox.Show("Score can Not be more than 3 digits");
                }
                else
                {
                    dt.Rows.Add(date, cb_HomeTeam.Text, tb_ScoreHome.Text, tb_ScoreHome.Text, cb_AwayTeam.Text);
                    cb_AwayTeam.SelectedItem = null;
                    cb_HomeTeam.SelectedItem = null;
                    tb_scoreAway.Clear();
                    tb_ScoreHome.Clear();
                }
            }
        }

        private void cb_HomeTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_AwayTeam.SelectedItem != null )
            {
                cb_HomeTeam.Items.Clear();
                string awayTeam = cb_AwayTeam.Text;
                foreach (string team in Team)
                {
                    if (team != awayTeam)
                    {
                        cb_HomeTeam.Items.Add(team);
                    }
                }
            }
            else if (cb_HomeTeam.SelectedItem != null)
            {
                cb_AwayTeam.Items.Clear();
                string homeTeam = cb_HomeTeam.Text;
                foreach (string team in Team)
                {
                    if (team != homeTeam)
                    {
                        cb_AwayTeam.Items.Add(team);
                    }
                }
            }
            else
            {
                foreach (string team in Team)
                {
                    cb_HomeTeam.Items.Add(team);
                    cb_AwayTeam.Items.Add(team);
                }
            }
        }

        private void cb_AwayTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            if (cb_HomeTeam.SelectedItem != null)
            {
                cb_HomeTeam.Items.Clear();
                string homeTeam = cb_HomeTeam.Text;
                foreach (string team in Team)
                {
                    if (team != homeTeam)
                    {
                        cb_AwayTeam.Items.Add(team);
                        //cb_HomeTeam.Items.Add(team);
                    }
                }
            }
            else if (cb_AwayTeam.SelectedItem != null)
            {
                cb_AwayTeam.Items.Clear();
                string awayTeam = cb_AwayTeam.Text;
                foreach (string team in Team)
                {
                    if (team != awayTeam)
                    {
                        cb_HomeTeam.Items.Add(team);
                        //cb_AwayTeam.Items.Add(team);
                    }
                }
            }
            else
            {
                foreach (string team in Team)
                {
                    cb_HomeTeam.Items.Add(team);
                    cb_AwayTeam.Items.Add(team);
                }
            }
            */
            if (cb_AwayTeam.SelectedItem != null)
            {
                cb_HomeTeam.Items.Clear();
                string awayTeam = cb_AwayTeam.Text;
                foreach (string team in Team)
                {
                    if (team != awayTeam)
                    {
                        cb_HomeTeam.Items.Add(team);
                    }
                }
            }
            else if (cb_HomeTeam.SelectedItem != null)
            {
                cb_AwayTeam.Items.Clear();
                string homeTeam = cb_HomeTeam.Text;
                foreach (string team in Team)
                {
                    if (team != homeTeam)
                    {
                        cb_AwayTeam.Items.Add(team);
                    }
                }
            }
            else
            {
                foreach (string team in Team)
                {
                    cb_HomeTeam.Items.Add(team);
                    cb_AwayTeam.Items.Add(team);
                }
            }
        }

        private void tb_ScoreHome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
        }

        private void tb_scoreAway_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
        }

        private void bt_addTeam_Click(object sender, EventArgs e)
        {
            form2 = new F_AddTeam(this); 
            form2.Show();
            form2.List(Team);
            
        }
        public void listform1(List<string> Teams)
        {
            Team.Clear();
            foreach (string team in Teams)
            {
                Team.Add(team);
            }
            cb_AwayTeam.Items.Clear();
            cb_HomeTeam.Items.Clear();
            foreach (string team in Team)
            {
                cb_HomeTeam.Items.Add(team);
                cb_AwayTeam.Items.Add(team);
            }
        }

        private void bt_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow dr = dgv_formMatch.CurrentRow;
            dgv_formMatch.Rows.Remove(dr);
        }
    }
}
