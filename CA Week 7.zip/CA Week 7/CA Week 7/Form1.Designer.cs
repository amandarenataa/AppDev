﻿namespace CA_Week_7
{
    partial class W07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_formMatch = new System.Windows.Forms.DataGridView();
            this.bt_delete = new System.Windows.Forms.Button();
            this.bt_addMatch = new System.Windows.Forms.Button();
            this.bt_addTeam = new System.Windows.Forms.Button();
            this.dtp_dateMatch = new System.Windows.Forms.DateTimePicker();
            this.cb_HomeTeam = new System.Windows.Forms.ComboBox();
            this.cb_AwayTeam = new System.Windows.Forms.ComboBox();
            this.tb_ScoreHome = new System.Windows.Forms.TextBox();
            this.tb_scoreAway = new System.Windows.Forms.TextBox();
            this.lb_Vs = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_formMatch)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_formMatch
            // 
            this.dgv_formMatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_formMatch.Location = new System.Drawing.Point(541, 206);
            this.dgv_formMatch.Name = "dgv_formMatch";
            this.dgv_formMatch.RowHeadersWidth = 82;
            this.dgv_formMatch.RowTemplate.Height = 33;
            this.dgv_formMatch.Size = new System.Drawing.Size(1209, 446);
            this.dgv_formMatch.TabIndex = 0;
            // 
            // bt_delete
            // 
            this.bt_delete.Location = new System.Drawing.Point(541, 686);
            this.bt_delete.Name = "bt_delete";
            this.bt_delete.Size = new System.Drawing.Size(166, 69);
            this.bt_delete.TabIndex = 1;
            this.bt_delete.Text = "Delete";
            this.bt_delete.UseVisualStyleBackColor = true;
            this.bt_delete.Click += new System.EventHandler(this.bt_delete_Click);
            // 
            // bt_addMatch
            // 
            this.bt_addMatch.Location = new System.Drawing.Point(1054, 949);
            this.bt_addMatch.Name = "bt_addMatch";
            this.bt_addMatch.Size = new System.Drawing.Size(166, 69);
            this.bt_addMatch.TabIndex = 2;
            this.bt_addMatch.Text = "Add Match";
            this.bt_addMatch.UseVisualStyleBackColor = true;
            this.bt_addMatch.Click += new System.EventHandler(this.bt_addMatch_Click);
            // 
            // bt_addTeam
            // 
            this.bt_addTeam.Location = new System.Drawing.Point(1323, 949);
            this.bt_addTeam.Name = "bt_addTeam";
            this.bt_addTeam.Size = new System.Drawing.Size(166, 69);
            this.bt_addTeam.TabIndex = 3;
            this.bt_addTeam.Text = "Add Team";
            this.bt_addTeam.UseVisualStyleBackColor = true;
            this.bt_addTeam.Click += new System.EventHandler(this.bt_addTeam_Click);
            // 
            // dtp_dateMatch
            // 
            this.dtp_dateMatch.Location = new System.Drawing.Point(1029, 703);
            this.dtp_dateMatch.Name = "dtp_dateMatch";
            this.dtp_dateMatch.Size = new System.Drawing.Size(485, 31);
            this.dtp_dateMatch.TabIndex = 4;
            // 
            // cb_HomeTeam
            // 
            this.cb_HomeTeam.FormattingEnabled = true;
            this.cb_HomeTeam.Location = new System.Drawing.Point(1029, 774);
            this.cb_HomeTeam.Name = "cb_HomeTeam";
            this.cb_HomeTeam.Size = new System.Drawing.Size(191, 33);
            this.cb_HomeTeam.TabIndex = 5;
            this.cb_HomeTeam.SelectedIndexChanged += new System.EventHandler(this.cb_HomeTeam_SelectedIndexChanged);
            // 
            // cb_AwayTeam
            // 
            this.cb_AwayTeam.FormattingEnabled = true;
            this.cb_AwayTeam.Location = new System.Drawing.Point(1323, 774);
            this.cb_AwayTeam.Name = "cb_AwayTeam";
            this.cb_AwayTeam.Size = new System.Drawing.Size(191, 33);
            this.cb_AwayTeam.TabIndex = 6;
            this.cb_AwayTeam.SelectedIndexChanged += new System.EventHandler(this.cb_AwayTeam_SelectedIndexChanged);
            // 
            // tb_ScoreHome
            // 
            this.tb_ScoreHome.Location = new System.Drawing.Point(1029, 859);
            this.tb_ScoreHome.Name = "tb_ScoreHome";
            this.tb_ScoreHome.Size = new System.Drawing.Size(191, 31);
            this.tb_ScoreHome.TabIndex = 7;
            this.tb_ScoreHome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_ScoreHome_KeyPress);
            // 
            // tb_scoreAway
            // 
            this.tb_scoreAway.Location = new System.Drawing.Point(1323, 859);
            this.tb_scoreAway.Name = "tb_scoreAway";
            this.tb_scoreAway.Size = new System.Drawing.Size(191, 31);
            this.tb_scoreAway.TabIndex = 8;
            this.tb_scoreAway.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_scoreAway_KeyPress);
            // 
            // lb_Vs
            // 
            this.lb_Vs.AutoSize = true;
            this.lb_Vs.Location = new System.Drawing.Point(1258, 818);
            this.lb_Vs.Name = "lb_Vs";
            this.lb_Vs.Size = new System.Drawing.Size(34, 25);
            this.lb_Vs.TabIndex = 9;
            this.lb_Vs.Text = "vs";
            // 
            // W07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2482, 1164);
            this.Controls.Add(this.lb_Vs);
            this.Controls.Add(this.tb_scoreAway);
            this.Controls.Add(this.tb_ScoreHome);
            this.Controls.Add(this.cb_AwayTeam);
            this.Controls.Add(this.cb_HomeTeam);
            this.Controls.Add(this.dtp_dateMatch);
            this.Controls.Add(this.bt_addTeam);
            this.Controls.Add(this.bt_addMatch);
            this.Controls.Add(this.bt_delete);
            this.Controls.Add(this.dgv_formMatch);
            this.Name = "W07";
            this.Text = "W07";
            this.Load += new System.EventHandler(this.W07_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_formMatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_formMatch;
        private System.Windows.Forms.Button bt_delete;
        private System.Windows.Forms.Button bt_addMatch;
        private System.Windows.Forms.Button bt_addTeam;
        private System.Windows.Forms.DateTimePicker dtp_dateMatch;
        private System.Windows.Forms.ComboBox cb_HomeTeam;
        private System.Windows.Forms.ComboBox cb_AwayTeam;
        private System.Windows.Forms.TextBox tb_ScoreHome;
        private System.Windows.Forms.TextBox tb_scoreAway;
        private System.Windows.Forms.Label lb_Vs;
    }
}

