﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CA_Week_7
{
    public partial class F_AddTeam : Form
    {
        W07 form1;
        List<string> teamNames = new List<string>();
        public F_AddTeam()
        {
            InitializeComponent();
        }
        public F_AddTeam(Form _sender)
        {
            InitializeComponent();
            form1 = (W07) _sender;
        }
        public void List (List<string> Team)
        {
            foreach (string team in Team)
            {
                teamNames.Add(team);
            }
        }
        private void bt_addTeam_Click(object sender, EventArgs e)
        {
            if (teamNames.Contains(tb_TeamName.Text))
            {
                MessageBox.Show("Team Double");
            }
            else
            {
                teamNames.Add(tb_TeamName.Text);

                form1.listform1(teamNames);
                this.Close();
            }
        }
    }
}
