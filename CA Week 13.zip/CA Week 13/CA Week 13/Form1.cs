﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CA_Week_13
{
    public partial class F1 : Form
    {
        public F1()
        {
            InitializeComponent();
        }
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable data;
        string query;
        private void F1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            conn.Open();
            conn.Close();

            // soal 1 table team sama manager n nationality
            //query = "select manager.manager_name as `Nama Manager`, if(manager.working = 0,'Available',concat(team.team_name,concat(',',team.city))) as Kesanggupan from manager left join team on team.manager_id = manager.manager_id or team.assmanager_id = manager.manager_id";

            // soal 2 alamat = nama stadium + negara asal, pake tabel nationality n team
            //query = "select manager.manager_name as `Nama Manager`, if(team.home_stadium is null,concat('(',concat(nationality.nation,')')),concat('Stadium ',concat(concat(team.home_stadium,'('),concat(team.city,')')))) as Alamat from manager left join team on team.manager_id = manager.manager_id left join nationality on nationality.nationality_id = manager.nationality_id";

            // no 3 
            //query = "select team.team_name as `Team Name`, concat(concat(team.home_stadium,'('),concat(team.capacity,')')) as `Stadium and Capacity`, team.city as `City`, manager.manager_name as `Manager Name`, if(team.assmanager_id is null,'---',m.manager_name) as `Assistant Manager` from team left join manager on manager.manager_id = team.manager_id left join manager m on m.manager_id = team.assmanager_id";

            // no 4 team home vs team away
            //query = "select match.match_date as `Tanggal Pertandingan`, concat(concat(team.team_name, ' VS '),t.team_name) as Pertandingan, concat(match.goal_home, ' - ', match.goal_away) as `Hasil Akhir`, if(match.goal_home = match.goal_away,'Draw',if(match.goal_home < match.goal_away,concat(t.team_name, ' Win'),concat(team.team_name, ' Win'))) as Kesimpulan from `match` left join team on match.team_home = team.team_id left join team t on match.team_away = t.team_id ";

            // no 5 
            query = "select team.team_name as `Name Team`, if(team.assmanager_id is null,manager.manager_name,concat(manager.manager_name, ' & ', m.manager_name)) as `Manager & Asisten Manager`, player.player_name as `Nama Captain` from team left join manager on manager.manager_id = team.manager_id left join manager m on m.manager_id = team.assmanager_id left join player on player.player_id = team.captain_id";

            cmd = new MySqlCommand(query, conn);
            adapter = new MySqlDataAdapter(cmd);
            
            data = new DataTable();
            adapter.Fill(data);
            dgv_data.DataSource = data;
        }
    }
}
